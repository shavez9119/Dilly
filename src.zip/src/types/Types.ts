export interface buttonPropIF {
  _text: string;
  _bgColor: string;
  _color: string;
  _bColor?: string;
  _fontSize: number;
  _img_source?: string;
  _onPress: () => void;
}

export interface inputIF {
  _bColor: string;
  _bRadius: number;
  _placeHolder: string;
  _value: string;
  _lable: string;
  _height: number | undefined;
  _onChange: (value: string) => void;
  _maxLength: number | undefined;
  _editable: boolean | undefined;
}
