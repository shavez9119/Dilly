const appleIcon = require('../images/apple_icon.png');
const appleIconDark = require('../images/apple_icon_dark.png');
const arrowLeft = require('../images/arrow_left.png');
const arrowLeftDark = require('../images/arrow-left_dark.png');
const arrowRight = require('../images/arrow_right.png');
const calendarActive = require('../images/calendar_active.png');
const calendarNonActive = require('../images/calendar_non_active.png');
const calendar = require('../images/calendar.png');
const calendarDark = require('../images/calendar_dark.png');
const caretDown = require('../images/caret_down.png');
const caretDownDark = require('../images/caret_down_dark.png');
const caretUp = require('../images/caret_up.png');
const caretRight = require('../images/caret_right.png');
const clock = require('../images/clock.png');
const clockDark = require('../images/clock_dark.png');
const edit = require('../images/edit.png');
const editDark = require('../images/edit_dark.png');
const editBlack = require('../images/edit_black.png');
const eyeClose = require('../images/eye_close.png');
const eyeCloseDark = require('../images/eye_close_dark.png');
const eyeOpen = require('../images/eye_open.png');
const eyeOpenDark = require('../images/eye_open_dark.png');
const googleICon = require('../images/google_icon.png');
const homeActive = require('../images/home_active.png');
const homeNonActive = require('../images/home_non_active.png');
const moon = require('../images/moon.png');
const plusNonActive = require('../images/plus_non_active.png');
const profile = require('../images/profile.png');
const rewardSmall = require('../images/reward_small.png');
const rewardSmallDark = require('../images/reward_small_dark.png');
const settingActive = require('../images/setting_active.png');
const settingNonActive = require('../images/setting_non_active.png');
const splash = require('../images/splash_img.png');
const sunDark = require('../images/sun_dark.png');
const welcomeBg = require('../images/welcome_bg_img.png');
const welcomeBg2 = require('../images/welcome_bg_img2.png');
const welcomeBg3 = require('../images/welcome_bg_img3.png');
const welcomeBgDark = require('../images/welcome_bg_img_dark.png');
const welcomeBg2Dark = require('../images/welcome_bg_img2_dark.png');
const welcomeBg3Dark = require('../images/welcome_bg_img3_dark.png');
const profileBig = require('../images/profile_big.png');
const sunLite = require('../images/sun_lite.png');
const moonDark = require('../images/moon_dark.png');
const rewardBig = require('../images/reward_big.png');
const caretDownBig = require('../images/caret_down_big.png');
const check = require('../images/check.png');
const complete = require('../images/complete.png');
const cross = require('../images/cross.png');
const editSmall = require('../images/edit_small.png');
const notification = require('../images/notification.png');
const notificationDark = require('../images/notification_dark.png');
const redFleg = require('../images/red_flag.png');
const rewardVerySmall = require('../images/reward_very_small.png');
const search = require('../images/search.png');
const trash = require('../images/trash.png');
const caretUpBig = require('../images/caret_up_big.png');
const rectangleEmpty = require('../images/rectangle_empty.png');
const rectangleFill = require('../images/rectangle_fill.png');
const moreVertical = require('../images/more_vertical.png');
const smallEllips = require('../images/small_elips.png');
const plus = require('../images/plus.png');
const close = require('../images/close.png');
const closeDark = require('../images/close_dark.png');
const selectedIcon = require('../images/selected_icon.png');
const unSelectedIcon = require('../images/unselected_icon.png');
const unSelectedIconDark = require('../images/unselected_icon_dark.png');
const closeBig = require('../images/close_big.png');
const closeBigDark = require('../images/close_big_dark.png');
const placeHolder = require('../images/placeholder.png');
const profileSetting = require('../images/profile_setting.png');
const rewardBigWhite = require('../images/reward_big_white.png');
const rewardBigDark = require('../images/reward_big_dark.png');

export {
  appleIcon,
  arrowLeft,
  arrowRight,
  calendar,
  calendarActive,
  calendarNonActive,
  caretDown,
  caretRight,
  clock,
  edit,
  editBlack,
  eyeClose,
  eyeOpen,
  googleICon,
  homeActive,
  homeNonActive,
  moon,
  plusNonActive,
  profile,
  rewardSmall,
  settingActive,
  settingNonActive,
  splash,
  welcomeBg,
  welcomeBg2,
  welcomeBg3,
  sunDark,
  profileBig,
  sunLite,
  moonDark,
  rewardBig,
  caretDownBig,
  check,
  complete,
  cross,
  editSmall,
  notification,
  redFleg,
  rewardVerySmall,
  search,
  trash,
  caretUpBig,
  rectangleEmpty,
  rectangleFill,
  moreVertical,
  smallEllips,
  plus,
  close,
  selectedIcon,
  unSelectedIcon,
  closeBig,
  placeHolder,
  profileSetting,
  rewardBigWhite,
  welcomeBgDark,
  welcomeBg2Dark,
  welcomeBg3Dark,
  appleIconDark,
  arrowLeftDark,
  eyeCloseDark,
  eyeOpenDark,
  clockDark,
  rewardSmallDark,
  editDark,
  rewardBigDark,
  caretUp,
  caretDownDark,
  closeDark,
  unSelectedIconDark,
  calendarDark,
  closeBigDark,
  notificationDark,
};
