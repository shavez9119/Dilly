import {
  Dimensions,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useState} from 'react';
import Button from './Button';
import {COLORS, FONTFAMILY, FONTSIZE} from '../theme/Theme';
import {
  responsiveHeight,
  responsiveWidth,
} from 'react-native-responsive-dimensions';
import {RFPercentage} from 'react-native-responsive-fontsize';
import {rewardBig, rewardBigWhite, rewardSmall} from '../assets/images/Index';
import LottieView from 'lottie-react-native';

const CollectPoints = ({
  isCollectPointsOpen,
  setIsCollectPointsOpen,
}: {
  isCollectPointsOpen: boolean;
  setIsCollectPointsOpen: React.Dispatch<React.SetStateAction<boolean>>;
}) => {
  const [isLottieViewOpen, setIsLottieViewOpen] = useState(false);
  const [isCongratsOpen, setIsCongratsOpen] = useState(false);

  setTimeout(() => {
    if (isCollectPointsOpen && isLottieViewOpen) {
      setIsCongratsOpen(true);
      setIsLottieViewOpen(false);
      console.log('hello');
    }
    if (isCongratsOpen && !isLottieViewOpen) {
      setIsCongratsOpen(false);
      setIsCollectPointsOpen(false);
    }
  }, 2500);
  return (
    <>
      <View style={styles.add_start_time_con}>
        <View style={styles.container}>
          <View style={styles.pop_container}>
            <Text style={styles.pop_title_text}>
              Congratulations! You just earned some points.
            </Text>
            <View>
              <Text style={styles.small_text}>
                Keep up the good work. You earned some points for your
                completing tasks:{' '}
                <Text style={styles.link_text}>Wireframe - Onboarding</Text>.
              </Text>
            </View>
            <View style={styles.flex}>
              <Image source={rewardSmall} style={styles.reward_img} />
              <Text style={styles.points_text}>15 Points</Text>
            </View>

            <Button
              _onPress={() => {
                setIsLottieViewOpen(true);
              }}
              _text={'Collect Points'}
              _bgColor={COLORS.LIGHT_BLUE}
              _fontSize={FONTSIZE.FONT_SIZE_16}
              _color={COLORS.WHITE}
              _bColor={'transparent'}
            />
          </View>
        </View>
      </View>
      {isLottieViewOpen && (
        <View style={styles.lottie_view}>
          <LottieView
            source={require('../data/Animation - 1703247930734.json')}
            autoPlay
            loop
            style={styles.animation}
          />
        </View>
      )}

      {isCongratsOpen && (
        <View style={styles.congract_container}>
          <Text style={styles.congrats_text}>Congratulations!</Text>
          <View style={{marginBottom: '15%'}}></View>
          <Image source={rewardBigWhite} style={styles.reward_big_img} />
          <Text style={styles.congrats_text}>15 Points</Text>
          <Text style={styles.congrats_heading}>
            You just collected some points.
          </Text>
          <Text style={styles.congrats_sub_heading}>
            Keep up the good work. You earned some points for your completing
            tasks:{'\u00A0'}
            <Text style={styles.underline_text}>Wireframe - Onboarding.</Text>
          </Text>
        </View>
      )}
    </>
  );
};

export default CollectPoints;

const styles = StyleSheet.create({
  add_start_time_con: {
    position: 'absolute',
    backgroundColor: 'rgba(0,0,0,0.7)',
    height: responsiveHeight(100),
    width: responsiveWidth(100),
    justifyContent: 'center',
    alignItems: 'center',
  },

  container: {
    backgroundColor: COLORS.WHITE,
    borderRadius: responsiveHeight(1.5),
  },
  pop_container: {
    width: responsiveWidth(90),
    padding: responsiveHeight(2.7),
  },
  pop_title_text: {
    fontFamily: FONTFAMILY.BLACK,
    fontSize: RFPercentage(2.9),
    color: COLORS.BLACK,
    textAlign: 'center',
    width: '100%',
    zIndex: -23,
  },
  small_text: {
    marginVertical: '10%',
    fontSize: RFPercentage(1.7),
    fontFamily: FONTFAMILY.MEDIUM,
    color: COLORS.DARK_GREY,
    textAlign: 'center',
  },
  link_text: {
    fontSize: RFPercentage(1.7),
    fontFamily: FONTFAMILY.BOLD,
    color: COLORS.LIGHT_BLUE,
    textDecorationLine: 'underline',
  },
  flex: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: responsiveHeight(2.5),
    marginBottom: '10%',
  },
  reward_img: {
    resizeMode: 'cover',
    height: responsiveHeight(5.6),
    width: responsiveHeight(5.6),
  },
  points_text: {
    fontSize: RFPercentage(3.6),
    fontFamily: FONTFAMILY.BLACK,
    color: COLORS.LIGHT_BLUE,
  },

  lottie_view: {
    backgroundColor: COLORS.LIGHT_BLUE,
    height: '100%',
    top: 0,
  },
  animation: {
    height: '100%',
    width: '100%',
  },
  congract_container: {
    height: '100%',
    backgroundColor: COLORS.LIGHT_BLUE,
    alignItems: 'center',
    justifyContent: 'center',
  },
  congrats_text: {
    fontSize: RFPercentage(4.6),
    fontFamily: FONTFAMILY.BOLD,
    color: COLORS.WHITE,
    marginBottom: '6%',
  },
  reward_big_img: {
    aspectRatio: 1,
    resizeMode: 'contain',
    width: responsiveWidth(3),
    height: responsiveHeight(14),
    marginBottom: '7%',
  },
  congrats_heading: {
    fontFamily: FONTFAMILY.REGULAR,
    color: COLORS.WHITE,
    fontSize: RFPercentage(3),
    marginBottom: '6%',
  },
  congrats_sub_heading: {
    // fontSize: RFPercentage(1.5),
    fontFamily: FONTFAMILY.REGULAR,
    color: COLORS.WHITE,
    textAlign: 'center',
    paddingHorizontal: responsiveHeight(3.5),
    fontSize: RFPercentage(1.6),
  },
  underline_text: {
    textDecorationLine: 'underline',
    textDecorationColor: COLORS.WHITE,
  },
});
