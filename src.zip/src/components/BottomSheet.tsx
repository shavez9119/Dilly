import React, {useRef, useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  TouchableOpacity,
} from 'react-native';
import SimpleBottomSheet from 'react-native-simple-bottom-sheet';
import {COLORS, FONTFAMILY, FONTSIZE} from '../theme/Theme';

import {RFPercentage} from 'react-native-responsive-fontsize';
import Button from './Button';
import {useNavigation} from '@react-navigation/native';
import {responsiveHeight} from 'react-native-responsive-dimensions';
import {googleICon, appleIcon, appleIconDark} from '../assets/images/Index';
import CollectPoints from './CollectPoints';
import {selectTheme} from '../redux/slices/ThemeSlice';
import {useSelector} from 'react-redux';
const BottomSheet = ({
  setIsBottomSheetOpen,
}: {
  setIsBottomSheetOpen: React.Dispatch<React.SetStateAction<boolean>>;
}) => {
  const panelRef = useRef(null);
  const theme = useSelector(selectTheme);

  const navigation: any = useNavigation();
  const [isCollectPointsOpen, setIsCollectPointsOpen] = useState(false);

  const styles = StyleSheet.create({
    bottom_sheet_container: {
      height: '100%',
      position: 'absolute',
      bottom: 0,
      width: '100%',
      backgroundColor: 'rgba(0,0,0,0.7)',
    },
    bottom_sheet: {
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
      borderTopLeftRadius: 40,
      borderTopRightRadius: 40,
      padding: 20,
      height: responsiveHeight(100),
      zIndex: -1,
    },
    bottom_sheet_content: {
      bottom: 20,
    },
    bottom_sheet_title: {
      fontSize: RFPercentage(3.2),
      fontFamily: FONTFAMILY.BLACK,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    bottom_sheet_desc: {
      marginTop: 10,
      fontSize: RFPercentage(1.7),
      color: theme.dark ? COLORS.MEDIUM_GREY : COLORS.LIGHT_BLACK,
      fontFamily: FONTFAMILY.MEDIUM,
    },
    buttonContainer: {
      marginTop: 40,
    },
    buttons_gap: {
      marginVertical: 10,
    },
    or_container: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginVertical: 10,
    },
    left_view: {
      height: 1.6,
      width: '45%',
      backgroundColor: theme.dark ? COLORS.LIGHT_BLACK : COLORS.MEDIUM_GREY,
    },
    or_text: {
      color: theme.dark ? COLORS.LIGHT_BLACK : COLORS.MEDIUM_GREY,
      fontSize: RFPercentage(2),
      fontFamily: FONTFAMILY.MEDIUM,
    },
    right_view: {
      height: 1.6,
      width: '45%',
      backgroundColor: theme.dark ? COLORS.LIGHT_BLACK : COLORS.MEDIUM_GREY,
    },
  });
  return (
    <>
      <Pressable
        style={styles.bottom_sheet_container}
        ref={ref => (panelRef.current = ref)}
        onPress={() => {
          // panelRef.current.close();
          // panelRef.current?.close?.();
          setIsBottomSheetOpen(false);
        }}>
        <SimpleBottomSheet
          sliderMaxHeight={'65%'}
          onClose={() => {
            setIsBottomSheetOpen(false);
          }}
          lineStyle={{
            bottom: 20,
            width: 60,
            height: 6,
            borderRadius: 50,
            backgroundColor: COLORS.LIGHT_GREY,
          }}
          animationDuration={50}
          // ref={panelRef}
          ref={ref => (panelRef.current = ref)}
          wrapperStyle={styles.bottom_sheet}>
          <Pressable
            onPress={() => setIsBottomSheetOpen(true)}
            style={styles.bottom_sheet_content}>
            <Text
              style={styles.bottom_sheet_title}
              onPress={() => {
                navigation.navigate('BOTTOMNAVIGATION');
              }}>
              Get Started
            </Text>
            <Text
              style={styles.bottom_sheet_desc}
              onPress={() => {
                setIsCollectPointsOpen(!isCollectPointsOpen);
              }}>
              Let's get started by either creating a new account or logging in
              with an existing account.
            </Text>
            <View style={styles.buttonContainer}>
              <View style={styles.buttons_gap}>
                <Button
                  _onPress={() => navigation.navigate('CREATEACCOUNT')}
                  _text={'Create an Account'}
                  _bgColor={COLORS.LIGHT_BLUE}
                  _fontSize={FONTSIZE.FONT_SIZE_16}
                  _color={COLORS.WHITE}
                  _bColor={'transparent'}
                />
              </View>
              <View style={styles.buttons_gap}>
                <Button
                  _onPress={() => navigation.navigate('LOGIN')}
                  _text={'Login'}
                  _bgColor={theme.dark ? COLORS.DARK : COLORS.WHITE}
                  _fontSize={FONTSIZE.FONT_SIZE_16}
                  _color={theme.dark ? COLORS.WHITE : COLORS.BLACK}
                  _bColor={theme.dark ? COLORS.MEDIUM_GREY : COLORS.BLACK}
                />
              </View>
              <View style={styles.or_container}>
                <View style={styles.left_view}></View>
                <Text style={styles.or_text}>OR</Text>
                <View style={styles.right_view}></View>
              </View>
              <View style={styles.buttons_gap}>
                <Button
                  _onPress={() => setIsBottomSheetOpen(true)}
                  _text={'Continue with Google'}
                  _bgColor={theme.dark ? COLORS.DARK : COLORS.WHITE}
                  _fontSize={FONTSIZE.FONT_SIZE_16}
                  _color={theme.dark ? COLORS.WHITE : COLORS.BLACK}
                  _bColor={theme.dark ? COLORS.MEDIUM_GREY : COLORS.BLACK}
                  _img_source={googleICon}
                />
              </View>
              <View style={styles.buttons_gap}>
                <Button
                  _onPress={() => setIsBottomSheetOpen(true)}
                  _text={'Continue with Apple'}
                  _bgColor={theme.dark ? COLORS.DARK : COLORS.WHITE}
                  _fontSize={FONTSIZE.FONT_SIZE_16}
                  _color={theme.dark ? COLORS.WHITE : COLORS.BLACK}
                  _bColor={theme.dark ? COLORS.MEDIUM_GREY : COLORS.BLACK}
                  _img_source={theme.dark ? appleIconDark : appleIcon}
                />
              </View>
              <View
                style={{
                  height: responsiveHeight(20),
                }}></View>
            </View>
          </Pressable>
        </SimpleBottomSheet>
      </Pressable>
      {isCollectPointsOpen && (
        <CollectPoints
          setIsCollectPointsOpen={setIsCollectPointsOpen}
          isCollectPointsOpen={isCollectPointsOpen}
        />
      )}
    </>
  );
};

export default BottomSheet;
