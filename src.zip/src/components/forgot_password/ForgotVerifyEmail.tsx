import {
  StyleSheet,
  Text,
  View,
  Image,
  TextInput,
  Pressable,
  TouchableOpacity,
} from 'react-native';
import React, {useEffect, useRef, useState} from 'react';
import {COLORS, FONTFAMILY, FONTSIZE} from '../../theme/Theme';
import {RFPercentage} from 'react-native-responsive-fontsize';
import {arrowLeft, arrowLeftDark} from '../../assets/images/Index';
import {
  responsiveHeight,
  responsiveWidth,
} from 'react-native-responsive-dimensions';
import Button from '../../components/Button';
import {useDispatch, useSelector} from 'react-redux';
import {
  selectCreateAccount,
  setEmailEmpty,
} from '../../redux/slices/create_account_slice/CreateAccountSlices';
import {OtpInput} from 'react-native-otp-entry';
import {selectTheme} from '../../redux/slices/ThemeSlice';

const ForgotVerifyEmail = ({
  step,
  setStep,
}: {
  step: number;
  setStep: React.Dispatch<React.SetStateAction<number>>;
}) => {
  const dispatch = useDispatch();

  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const refs = useRef([...Array(6)].map(() => React.createRef()));
  const theme = useSelector(selectTheme);

  const [message, setMessage] = useState('');
  const [minutes, setMinutes] = useState(1);
  const [seconds, setSeconds] = useState(59);

  // TIMER WILL START AS USER SEE THIS SSCREEN
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (minutes === 0 && seconds === 0) {
      clearInterval(timer);
    } else {
      timer = setInterval(() => {
        if (seconds === 0) {
          setMinutes(prevMinutes => prevMinutes - 1);
          setSeconds(59);
        } else {
          setSeconds(prevSeconds => prevSeconds - 1);
        }
      }, 1000);
    }

    return () => {
      clearInterval(timer);
    };
  }, [minutes, seconds]);

  // RESTRICT SPECIAL CHARACTERS / BLANK SPACES
  const handleOtpChange = (index: number, value: string) => {
    const newOtp = [...otp];
    const numericValue = value.replace(/[^0-9]/g, '');
    newOtp[index] = numericValue;
    setOtp(newOtp);

    if (value !== '' && index < otp.length - 1 && /\d/.test(value)) {
      refs.current[index + 1]?.current?.focus();
    }
  };

  // SET OTP COUNTER VALUE TO INITITAL VALUE WHEN USER PRESSED 'RESEND OTP"
  const handleResendOTP = () => {
    setMinutes(1);
    setSeconds(59);
  };

  const handleKeyPress = (index: number, key: string) => {
    if (key === 'Backspace' && index > 0) {
      refs.current[index - 1]?.current?.focus();
    }
  };

  const validateOTP = () => {
    if (otp.join('') === '') {
      setMessage('Please enter OTP');
    } else if (otp.join('').length !== 6) {
      setMessage('Please enter Full OTP');
    } else {
      setMessage('');
      setStep(step + 1);
    }
  };

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
      paddingHorizontal: 23,
      paddingTop: responsiveHeight(7),
    },
    back_container: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    text: {
      textAlign: 'center',
      fontSize: RFPercentage(2),
      bottom: 20,
      fontFamily: FONTFAMILY.BLACK,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      marginTop: -13,
    },
    progress_outer: {
      marginTop: 10,
      height: responsiveHeight(1),
      borderRadius: 10,
      backgroundColor: theme.dark ? COLORS.LIGHT_BLACK : COLORS.LIGHT_GREY,
    },
    progress_inner: {
      position: 'absolute',
      backgroundColor: COLORS.LIGHT_BLUE,
      width: '28.4%',
      height: responsiveHeight(1),
      borderRadius: 10,
    },
    heading: {
      fontSize: RFPercentage(2.8),
      fontFamily: FONTFAMILY.BLACK,
      marginTop: 40,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    sub_heading: {
      fontSize: RFPercentage(1.5),
      marginTop: 10,
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.MEDIUM_GREY : COLORS.LIGHT_BLACK,
    },
    input_container: {
      marginTop: '8.5%',

      flexDirection: 'row',
      justifyContent: 'space-between',
    },

    text_deco: {
      textDecorationLine: 'underline',
    },

    input: {
      width: responsiveWidth(12.5),
      height: responsiveWidth(12.5),
      borderColor: COLORS.LIGHT_BLUE,
      borderWidth: 1,
      textAlign: 'center',
      fontSize: RFPercentage(2),
      marginRight: 10,
      borderRadius: 7,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    otp_text: {
      fontSize: RFPercentage(1.7),
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    timer_text: {
      fontSize: RFPercentage(1.7),
      fontFamily: FONTFAMILY.MEDIUM,
      color: COLORS.LIGHT_BLUE,
    },
    link_text: {
      color: COLORS.LIGHT_BLUE,
      textDecorationLine: 'underline',
    },
    link_text_fade: {
      color: COLORS.DARK_GREY,
      textDecorationLine: 'underline',
    },
    flex: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
    },

    valid_msg: {
      fontFamily: FONTFAMILY.MEDIUM,
      color: COLORS.RED,
      marginTop: '1%',
      fontSize: RFPercentage(1.5),
    },
    back_img: {
      aspectRatio: 1,
      resizeMode: 'cover',
      width: responsiveHeight(2),
      height: responsiveHeight(3.2),
    },
  });
  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={{
          position: 'absolute',
          top: 0,
          marginTop: responsiveHeight(1.6),
          padding: 10,
          left: 10,
          width: '15%',
          zIndex: 999,
        }}
        onPress={() => {
          setStep(step - 1);
        }}>
        <Image
          source={theme.dark ? arrowLeftDark : arrowLeft}
          style={styles.back_img}
        />
      </TouchableOpacity>
      <Text style={styles.text}>Create an Account</Text>

      <View style={styles.progress_outer}>
        <View style={styles.progress_inner}></View>
      </View>
      <View style={{height: responsiveHeight(13)}}>
        <Text style={styles.heading}>Verify your Email Address</Text>
        <Text style={styles.sub_heading}>
          We have sent an OTP to{' '}
          <Text style={styles.text_deco}>divyansh.bhatnagar@agicent.com</Text>
        </Text>
      </View>

      <View style={styles.input_container}>
        {otp.map((digit, index) => (
          <TextInput
            key={index}
            placeholderTextColor={COLORS.DARK_GREY}
            style={styles.input}
            value={digit}
            onChangeText={value => handleOtpChange(index, value)}
            onKeyPress={({nativeEvent: {key}}) => handleKeyPress(index, key)}
            keyboardType="numeric"
            maxLength={1}
            ref={refs.current[index]}
          />
        ))}
      </View>

      <View style={{marginTop: '6%'}}>
        <View style={styles.flex}>
          <Text style={styles.otp_text}>
            Didn’t get an OTP?{' '}
            {seconds === 0 ? (
              <Text
                style={styles.link_text}
                onPress={() => {
                  handleResendOTP();
                }}>
                Resend OTP
              </Text>
            ) : (
              <Text style={styles.link_text_fade}>Resend OTP</Text>
            )}
          </Text>
          {seconds !== 0 ? (
            <Text style={styles.timer_text}>
              {minutes < 10 ? `0${minutes}` : minutes}:
              {seconds < 10 ? `0${seconds}` : seconds}
            </Text>
          ) : null}
        </View>
      </View>
      <View style={{height: responsiveHeight(49.3), marginTop: '2%'}}>
        <Text style={styles.valid_msg}>{message}</Text>
      </View>
      <Button
        _onPress={() => {
          validateOTP();
        }}
        _text={'Verify'}
        _bgColor={COLORS.LIGHT_BLUE}
        _fontSize={FONTSIZE.FONT_SIZE_16}
        _color={COLORS.WHITE}
        _bColor={'transparent'}
      />
    </View>
  );
};

export default ForgotVerifyEmail;
