import {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  TextInput,
  Pressable,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {COLORS, FONTFAMILY, FONTSIZE} from '../../theme/Theme';
import {RFPercentage} from 'react-native-responsive-fontsize';

import {responsiveHeight} from 'react-native-responsive-dimensions';
import Button from '../Button';
import {useNavigation} from '@react-navigation/native';
import {arrowLeft, arrowLeftDark} from '../../assets/images/Index';
import {useSelector} from 'react-redux';
import {selectTheme} from '../../redux/slices/ThemeSlice';

import {
  selectEditProfile,
  setEditFNameInput,
  setEditLNameInput,
} from '../../redux/slices/settings/edit_profile_slices/EditProfileSlices';
const ForgotEmailAddress = ({
  step,
  setStep,
}: {
  step: number;
  setStep: React.Dispatch<React.SetStateAction<number>>;
}) => {
  const [emailInput, setEmailInput] = useState('');
  const theme = useSelector(selectTheme);
  const forgotPass = useSelector(selectEditProfile);

  const navigation = useNavigation();
  const [message, setMessage] = useState('');

  const validateEmail = () => {
    const emailRegex = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}$/;
    if (emailRegex.test(emailInput)) {
      setMessage('');
      setStep(step + 1);
    } else if (emailInput == '') {
      setMessage('Please enter email');
    } else {
      setMessage('Please enter valid email');
    }
  };

  const handleEmail = (value: string) => {
    let formattedText = value.replace(/\s+/, '');
    setEmailInput(formattedText);
  };

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
      paddingHorizontal: responsiveHeight(2.7),
      paddingTop: responsiveHeight(1.5),
    },
    back_container: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    text: {
      textAlign: 'center',
      fontSize: RFPercentage(2),
      bottom: 20,
      fontFamily: FONTFAMILY.BLACK,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      marginTop: -13,
    },
    heading: {
      fontSize: RFPercentage(2.8),
      fontFamily: FONTFAMILY.BLACK,
      marginTop: '3%',
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    sub_heading: {
      fontSize: RFPercentage(1.5),
      marginTop: 10,
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.MEDIUM_GREY : COLORS.LIGHT_BLACK,
    },
    input_style: {
      borderRadius: 10,
      borderColor: COLORS.LIGHT_BLUE,
      borderWidth: 1,
      paddingLeft: responsiveHeight(2),
      fontSize: RFPercentage(1.8),
      paddingVertical: responsiveHeight(1.3),
      fontFamily: FONTFAMILY.REGULAR,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    email_text: {
      marginBottom: 10,
      fontSize: RFPercentage(1.8),
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    parent_input_container: {
      height: responsiveHeight(62),
    },
    input_icon_con: {},
    icon_style: {
      position: 'absolute',
      right: 20,
      top: 14,
    },
    link_text: {
      color: COLORS.LIGHT_BLUE,
      fontFamily: FONTFAMILY.BOLD,
      textDecorationLine: 'underline',
      textAlign: 'right',
      marginTop: '2%',
    },
    bottom_text: {
      textAlign: 'center',
      marginTop: 14,
      fontSize: RFPercentage(1.5),
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    valid_msg: {
      fontFamily: FONTFAMILY.MEDIUM,
      color: COLORS.RED,
      marginLeft: '2%',
      marginTop: '1.2%',
      fontSize: RFPercentage(1.8),
    },
    back_img: {
      aspectRatio: 1,
      resizeMode: 'cover',
      width: responsiveHeight(2),
      height: responsiveHeight(3.2),
    },
  });
  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={{
          position: 'relative',
          top: 0,
          // marginTop: responsiveHeight(1.6),
          paddingVertical: 10,
          width: '15%',
          zIndex: 999,
        }}
        onPress={() => {
          navigation.goBack();
        }}>
        <Image
          source={theme.dark ? arrowLeftDark : arrowLeft}
          style={styles.back_img}
        />
      </TouchableOpacity>
      <Text style={styles.text}>Forgot Password</Text>
      <View
        style={{
          height: responsiveHeight(15),
        }}>
        <Text style={styles.heading}>What is your Email Address?</Text>
        <Text style={styles.sub_heading}>
          Please provide the email address you used to sign up.
        </Text>
      </View>

      <View style={styles.parent_input_container}>
        <View style={styles.input_container}>
          <Text style={styles.email_text}>Email Address</Text>
          <View style={styles.input_icon_con}>
            <TextInput
              placeholderTextColor={COLORS.DARK_GREY}
              style={styles.input_style}
              placeholder="Enter Email"
              value={emailInput}
              onChangeText={value => {
                // setEmailInput(value);
                handleEmail(value);
              }}
            />
          </View>
        </View>
        <Text style={styles.valid_msg}>{message}</Text>
      </View>
      <Button
        _onPress={() => {
          validateEmail();
        }}
        _text={'Continue'}
        _bgColor={COLORS.LIGHT_BLUE}
        _fontSize={FONTSIZE.FONT_SIZE_16}
        _color={COLORS.WHITE}
        _bColor={'transparent'}
      />
      <Text
        style={styles.bottom_text}
        onPress={() => {
          navigation.navigate('CREATEACCOUNT');
        }}>
        Don’t have an account?{' '}
        <Text style={styles.link_text}>Create an Account</Text>
      </Text>
    </View>
  );
};

export default ForgotEmailAddress;
