import {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  TextInput,
  Alert,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {COLORS, FONTFAMILY, FONTSIZE} from '../../theme/Theme';
import {RFPercentage} from 'react-native-responsive-fontsize';
import {
  arrowLeft,
  arrowLeftDark,
  eyeClose,
  eyeCloseDark,
  eyeOpen,
  eyeOpenDark,
} from '../../assets/images/Index';
import {
  responsiveHeight,
  responsiveWidth,
} from 'react-native-responsive-dimensions';
import Button from '../Button';
import {selectTheme} from '../../redux/slices/ThemeSlice';
import {useSelector} from 'react-redux';
const ResetPassword = ({
  step,
  setStep,
}: {
  step: number;
  setStep: React.Dispatch<React.SetStateAction<number>>;
}) => {
  const [isFirstEyeOpen, setIsFirstEyeOpen] = useState(true);
  const [isSecondEyeOpen, setIsSecondEyeOpen] = useState(true);
  const [passwordInput, setPasswordInput] = useState('');
  const [cPasswordInput, setCPasswordInput] = useState('');
  const theme = useSelector(selectTheme);

  const [passMessage, setPassMessage] = useState('');
  const [cPassMessage, setCPassMessage] = useState('');

  const validatePass = () => {
    if (passwordInput === '') {
      setPassMessage('Please enter password');
      setCPassMessage('');
    } else if (passwordInput.length <= 7) {
      setPassMessage('Please enter atleast 8 characters');
      setCPassMessage('');
    } else if (cPasswordInput === '') {
      setCPassMessage('Please enter confirm password');
      setPassMessage('');
    } else if (cPasswordInput === '' && passwordInput.length >= 7) {
      setCPassMessage('Please enter confirm password');
      setPassMessage('');
    } else if (
      passwordInput !== cPasswordInput &&
      passwordInput !== '' &&
      cPasswordInput !== ''
    ) {
      setCPassMessage('Password and Confirm Password must be same');
      setPassMessage('');
    } else {
      setPassMessage('');
      setCPassMessage('');
      Alert.alert('Success');
    }
  };

  const handlePass = (value: string) => {
    setPasswordInput(value.slice(0, 12));
  };
  const handleCPass = (value: string) => {
    setCPasswordInput(value.slice(0, 12));
  };

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
      paddingHorizontal: responsiveHeight(2.7),
      paddingTop: responsiveHeight(1.5),
    },
    back_container: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    text: {
      textAlign: 'center',
      fontSize: RFPercentage(2.2),
      bottom: 20,
      fontFamily: FONTFAMILY.BLACK,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      marginTop: -13,
    },
    heading: {
      fontSize: RFPercentage(2.8),
      fontFamily: FONTFAMILY.BLACK,
      marginTop: '4%',
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    sub_heading: {
      fontSize: RFPercentage(1.5),
      marginTop: 10,
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.MEDIUM_GREY : COLORS.LIGHT_BLACK,
    },
    input_container1: {
      marginTop: '7%',
    },
    input_container: {
      marginTop: '1%',
    },
    input_style: {
      borderRadius: 10,
      borderColor: COLORS.LIGHT_BLUE,
      borderWidth: 1,
      paddingLeft: 20,
      fontSize: RFPercentage(2),
      paddingVertical: responsiveHeight(1.3),
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    email_text: {
      marginBottom: 10,
      fontSize: RFPercentage(1.8),
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    parent_input_container: {
      height: responsiveHeight(67),
    },
    input_icon_con: {},
    icon_style: {
      position: 'absolute',
      right: responsiveWidth(4),
      top: responsiveHeight(1.5),
    },
    input_img_style: {
      aspectRatio: 1,
      resizeMode: 'contain',
      height: responsiveHeight(2.7),
      width: responsiveWidth(2.7),
    },
    valid_msg: {
      fontFamily: FONTFAMILY.MEDIUM,
      color: COLORS.RED,
      marginTop: '1%',
      fontSize: RFPercentage(1.8),
    },
    back_img: {
      aspectRatio: 1,
      resizeMode: 'cover',
      width: responsiveHeight(2),
      height: responsiveHeight(3.2),
    },
  });
  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={{
          position: 'relative',
          top: 0,
          paddingVertical: 10,
          width: '15%',
          zIndex: 999,
        }}
        onPress={() => {
          setStep(step - 1);
        }}>
        <Image
          source={theme.dark ? arrowLeftDark : arrowLeft}
          style={styles.back_img}
        />
      </TouchableOpacity>
      <Text style={styles.text}>Forgot Password</Text>
      <View style={{height: responsiveHeight(10)}}>
        <Text style={styles.heading}>Reset Password</Text>
        <Text style={styles.sub_heading}>
          We recommend you to use a strong password.
        </Text>
      </View>

      <View style={styles.parent_input_container}>
        <View style={styles.input_container1}>
          <Text style={styles.email_text}>New Password</Text>
          <View style={styles.input_icon_con}>
            <TextInput
              placeholderTextColor={COLORS.DARK_GREY}
              style={styles.input_style}
              placeholder="Enter Password"
              secureTextEntry={isFirstEyeOpen ? true : false}
              value={passwordInput}
              onChangeText={value => {
                handlePass(value);
              }}
            />
            <TouchableOpacity
              activeOpacity={0.7}
              style={styles.icon_style}
              onPress={() => {
                setIsFirstEyeOpen(!isFirstEyeOpen);
              }}>
              <Image
                source={
                  isFirstEyeOpen && theme.dark
                    ? eyeOpenDark
                    : !isFirstEyeOpen && !theme.dark
                    ? eyeClose
                    : isFirstEyeOpen && !theme.dark
                    ? eyeOpen
                    : theme.dark && !isFirstEyeOpen
                    ? eyeCloseDark
                    : ''
                }
                style={styles.input_img_style}
              />
            </TouchableOpacity>
            <Text style={styles.valid_msg}>{passMessage}</Text>
          </View>
        </View>
        <View style={styles.input_container}>
          <Text style={styles.email_text}>Confirm Password</Text>
          <View style={styles.input_icon_con}>
            <TextInput
              placeholderTextColor={COLORS.DARK_GREY}
              style={styles.input_style}
              secureTextEntry={isSecondEyeOpen ? true : false}
              placeholder="Enter Confirm Password"
              value={cPasswordInput}
              onChangeText={value => {
                handleCPass(value);
              }}
            />
            <TouchableOpacity
              activeOpacity={0.7}
              style={styles.icon_style}
              onPress={() => {
                setIsSecondEyeOpen(!isSecondEyeOpen);
              }}>
              <Image
                source={
                  isSecondEyeOpen && theme.dark
                    ? eyeOpenDark
                    : !isSecondEyeOpen && !theme.dark
                    ? eyeClose
                    : isSecondEyeOpen && !theme.dark
                    ? eyeOpen
                    : theme.dark && !isSecondEyeOpen
                    ? eyeCloseDark
                    : ''
                }
                style={styles.input_img_style}
              />
            </TouchableOpacity>
          </View>
          <Text style={styles.valid_msg}>{cPassMessage}</Text>
        </View>
      </View>
      <Button
        _onPress={() => {
          validatePass();
        }}
        _text={'Continue'}
        _bgColor={COLORS.LIGHT_BLUE}
        _fontSize={FONTSIZE.FONT_SIZE_16}
        _color={COLORS.WHITE}
        _bColor={'transparent'}
      />
    </View>
  );
};

export default ResetPassword;
