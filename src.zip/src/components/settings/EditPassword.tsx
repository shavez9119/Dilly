import {
  Image,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  TextInput,
  Alert,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {COLORS, FONTFAMILY, FONTSIZE} from '../../theme/Theme';
import {
  arrowLeft,
  arrowLeftDark,
  eyeClose,
  eyeCloseDark,
  eyeOpen,
  eyeOpenDark,
} from '../../assets/images/Index';
import {RFPercentage} from 'react-native-responsive-fontsize';
import {useNavigation} from '@react-navigation/native';
import {
  responsiveHeight,
  responsiveWidth,
} from 'react-native-responsive-dimensions';
import Button from '../Button';

import {useDispatch, useSelector} from 'react-redux';
import {
  selectCreateAccount,
  setPass,
} from '../../redux/slices/create_account_slice/CreateAccountSlices';
import {selectTheme} from '../../redux/slices/ThemeSlice';

const EditPassword = () => {
  const navigation = useNavigation();
  const [isFirstEyeOpen, setIsFirstEyeOpen] = useState(true);
  const [isSecondEyeOpen, setIsSecondEyeOpen] = useState(true);
  const [isThirdEyeOpen, setIsThirdEyeOpen] = useState(true);
  const theme = useSelector(selectTheme);

  const selectCreateAccountData = useSelector(selectCreateAccount);

  console.log('selectCreateAccountData:', selectCreateAccountData);

  const dispatch = useDispatch();
  const [oldPass, setOldPass] = useState('');
  const [newPass, setnewPass] = useState('');
  const [cNewPass, setCNewPass] = useState('');

  const [oldPassMsg, setOldPassMsg] = useState('');
  const [newPassMsg, setNewPassMsg] = useState('');
  const [cNewPassMsg, setCNewPassMsg] = useState('');

  const validateCreatePass = () => {
    if (oldPass === '') {
      setOldPassMsg('Please enter Old Password');
      setNewPassMsg('');
      setCNewPassMsg('');
    } else if (oldPass !== selectCreateAccountData.pass) {
      setOldPassMsg('Please enter correct Old Password');
      setNewPassMsg('');
      setCNewPassMsg('');
    } else if (newPass === '') {
      setNewPassMsg('Please enter New Password');
      setCNewPassMsg('');
      setOldPassMsg('');
    } else if (newPass === selectCreateAccountData.pass) {
      setNewPassMsg('Old Password and New Password should not be same');
      setCNewPassMsg('');
      setOldPassMsg('');
    } else if (cNewPass === '') {
      setCNewPassMsg('Please enter Confirm New Password');
      setNewPassMsg('');
      setOldPassMsg('');
    } else if (newPass === '' && newPass.length > 7) {
      setCNewPassMsg('Please enter Confirm New Password');
      setOldPassMsg('');
      setNewPassMsg('');
    } else if (newPass !== cNewPass && newPass !== '' && cNewPass !== '') {
      setCNewPassMsg('Password and Confirm Password must be same');
      setNewPassMsg('');
      setOldPassMsg('');
    } else {
      setOldPassMsg('');
      setNewPassMsg('');
      setCNewPassMsg('');
      Alert.alert('Password has been changed');
      dispatch(setPass(newPass));
      navigation.goBack();
    }
  };

  // const handleNewPass = (value: string) => {
  //   dispatch(setPass(value));
  // };

  // SETTING CHAR LIMIT == 12
  useEffect(() => {
    setOldPass(oldPass.slice(0, 12));
    setnewPass(newPass.slice(0, 12));
    setCNewPass(cNewPass.slice(0, 12));
  }, [oldPass, newPass, cNewPass]);

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
      paddingBottom: 10,
      paddingHorizontal: 23,
      zIndex: -20,
      paddingTop: 20,
    },
    input_container: {
      marginTop: '8.5%',
    },
    email_text: {
      marginBottom: 10,
      fontSize: RFPercentage(1.8),
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    input_style: {
      borderWidth: 1,
      paddingLeft: responsiveHeight(2),
      fontSize: RFPercentage(1.8),
      paddingVertical: responsiveHeight(1.1),
      fontFamily: FONTFAMILY.MEDIUM,
      borderRadius: responsiveHeight(1.2),
      // borderRadius: 10,
      borderColor: theme.dark ? COLORS.LIGHT_BLUE : COLORS.MEDIUM_GREY,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    icon_style: {
      position: 'absolute',
      right: 20,
      top: 16,
    },
    input_img_style: {
      aspectRatio: 1,
      height: responsiveHeight(2),
      width: responsiveWidth(2),
      padding: responsiveHeight(1.2),
    },
    valid_msg: {
      fontFamily: FONTFAMILY.MEDIUM,
      color: COLORS.RED,
      marginTop: '1%',
      fontSize: RFPercentage(1.8),
    },
    back_img: {
      aspectRatio: 1,
      resizeMode: 'cover',
      width: responsiveHeight(2),
      height: responsiveHeight(3.2),
    },
  });
  return (
    <View style={styles.container}>
      <TouchableOpacity
        activeOpacity={0.6}
        onPress={() => {
          navigation.goBack();
        }}>
        <Image
          source={theme.dark ? arrowLeftDark : arrowLeft}
          style={styles.back_img}
        />
      </TouchableOpacity>
      <View style={{height: responsiveHeight(81.5)}}>
        <View style={styles.input_container}>
          <Text style={styles.email_text}>Old Password</Text>
          <View>
            <TextInput
              placeholderTextColor={COLORS.DARK_GREY}
              style={styles.input_style}
              placeholder="Enter Old Password"
              value={oldPass}
              secureTextEntry={isFirstEyeOpen ? true : false}
              onChangeText={value => {
                // dispatch(setEditOldPassInput(value));
                setOldPass(value);
              }}
            />
            <TouchableOpacity
              activeOpacity={0.7}
              style={styles.icon_style}
              onPress={() => {
                setIsFirstEyeOpen(!isFirstEyeOpen);
              }}>
              <Image
                source={
                  isFirstEyeOpen && theme.dark
                    ? eyeOpenDark
                    : !isFirstEyeOpen && !theme.dark
                    ? eyeClose
                    : isFirstEyeOpen && !theme.dark
                    ? eyeOpen
                    : theme.dark && !isFirstEyeOpen
                    ? eyeCloseDark
                    : ''
                }
                style={styles.input_img_style}
              />
            </TouchableOpacity>
          </View>
        </View>
        {oldPassMsg !== '' && (
          <Text style={styles.valid_msg}>{oldPassMsg}</Text>
        )}
        <View style={styles.input_container}>
          <Text style={styles.email_text}>New Password</Text>
          <View>
            <TextInput
              placeholderTextColor={COLORS.DARK_GREY}
              style={styles.input_style}
              placeholder="Enter New Password"
              secureTextEntry={isSecondEyeOpen ? true : false}
              value={newPass}
              onChangeText={value => {
                // handleNewPass(value);
                setnewPass(value);
              }}
            />
            <TouchableOpacity
              activeOpacity={0.7}
              style={styles.icon_style}
              onPress={() => {
                setIsSecondEyeOpen(!isSecondEyeOpen);
              }}>
              <Image
                source={
                  isSecondEyeOpen && theme.dark
                    ? eyeOpenDark
                    : !isSecondEyeOpen && !theme.dark
                    ? eyeClose
                    : isSecondEyeOpen && !theme.dark
                    ? eyeOpen
                    : theme.dark && !isSecondEyeOpen
                    ? eyeCloseDark
                    : ''
                }
                style={styles.input_img_style}
              />
            </TouchableOpacity>
          </View>
        </View>
        {newPassMsg !== '' && (
          <Text style={styles.valid_msg}>{newPassMsg}</Text>
        )}
        <View style={styles.input_container}>
          <Text style={styles.email_text}>Confirm New Password</Text>
          <View>
            <TextInput
              style={styles.input_style}
              placeholderTextColor={COLORS.DARK_GREY}
              placeholder="Enter Confirm New Password"
              secureTextEntry={isThirdEyeOpen ? true : false}
              value={cNewPass}
              onChangeText={value => {
                // dispatch(setEditCNewPassInput(value));
                setCNewPass(value);
              }}
            />
            <TouchableOpacity
              activeOpacity={0.7}
              style={styles.icon_style}
              onPress={() => {
                setIsThirdEyeOpen(!isThirdEyeOpen);
              }}>
              <Image
                source={
                  isThirdEyeOpen && theme.dark
                    ? eyeOpenDark
                    : !isThirdEyeOpen && !theme.dark
                    ? eyeClose
                    : isThirdEyeOpen && !theme.dark
                    ? eyeOpen
                    : theme.dark && !isThirdEyeOpen
                    ? eyeCloseDark
                    : ''
                }
                style={styles.input_img_style}
              />
            </TouchableOpacity>
          </View>
        </View>
        {cNewPassMsg !== '' && (
          <Text style={styles.valid_msg}>{cNewPassMsg}</Text>
        )}
      </View>

      <Button
        _onPress={() => {
          // setStep(step + 1);
          validateCreatePass();
        }}
        _text={'Save'}
        _bgColor={COLORS.LIGHT_BLUE}
        _fontSize={FONTSIZE.FONT_SIZE_16}
        _color={COLORS.WHITE}
        _bColor={'transparent'}
      />
    </View>
  );
};

export default EditPassword;
