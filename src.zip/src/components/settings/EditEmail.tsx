import {
  Image,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  TextInput,
  Alert,
} from 'react-native';
import React, {useEffect, useRef, useState} from 'react';
import {COLORS, FONTFAMILY, FONTSIZE} from '../../theme/Theme';
import {
  arrowLeft,
  arrowLeftDark,
  editBlack,
  editDark,
} from '../../assets/images/Index';
import {RFPercentage} from 'react-native-responsive-fontsize';
import {useNavigation} from '@react-navigation/native';
import {
  responsiveHeight,
  responsiveWidth,
} from 'react-native-responsive-dimensions';
import Button from '../Button';
import {useDispatch, useSelector} from 'react-redux';

import {
  setEmail,
  selectCreateAccount,
} from '../../redux/slices/create_account_slice/CreateAccountSlices';
import {selectTheme} from '../../redux/slices/ThemeSlice';

const EditEmail = () => {
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const selectCreateAccountData = useSelector(selectCreateAccount);
  const [isEmailEditTrue, setIsEmailEditTrue] = useState(false);
  // const [email, setEmail] = useState('');
  const [pass, setPass] = useState('');
  const [emailMessage, setEmailMessage] = useState('');
  const [passMsg, setPassMsg] = useState('');
  const emailInputRef = useRef<TextInput>(null);
  const theme = useSelector(selectTheme);

  const handleSave = () => {
    const emailRegex = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}$/;
    if (emailRegex.test(selectCreateAccountData.email)) {
      setEmailMessage('');
    } else if (selectCreateAccountData.email == '') {
      setEmailMessage('Please enter email');
    } else {
      setEmailMessage('Please enter valid email');
    }
    if (pass === '') {
      setPassMsg(
        '**You need to enter your password to change your email address.',
      );
    } else if (pass !== selectCreateAccountData.pass) {
      setPassMsg('Password enter correct password');
    } else {
      setPassMsg('');
      Alert.alert('Email changed successsfully');
      navigation.goBack();
    }
  };

  useEffect(() => {
    if (isEmailEditTrue && emailInputRef.current) {
      emailInputRef.current.focus();
    }
  }, [isEmailEditTrue]);

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
      paddingBottom: 10,
      paddingHorizontal: 23,
      zIndex: -20,
      paddingTop: 20,
    },
    input_container: {
      marginTop: '8.5%',
    },
    email_text: {
      marginBottom: 10,
      fontSize: RFPercentage(1.8),
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    input_style: {
      borderRadius: 10,
      borderColor: theme.dark ? COLORS.LIGHT_BLUE : COLORS.MEDIUM_GREY,
      borderWidth: 1,
      paddingLeft: 20,
      fontSize: RFPercentage(2),
      paddingVertical: responsiveHeight(1.3),
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    icon_style: {
      position: 'absolute',
      right: 20,
      top: 14,
    },
    input_img_style: {
      aspectRatio: 1,
      height: responsiveHeight(1),
      width: responsiveWidth(1),
      marginTop: '3%',
      padding: responsiveHeight(1.3),
    },
    valid_msg: {
      fontFamily: FONTFAMILY.MEDIUM,
      color: COLORS.RED,
      marginTop: '2%',
      fontSize: RFPercentage(1.8),
    },
    back_img: {
      aspectRatio: 1,
      resizeMode: 'cover',
      width: responsiveHeight(2),
      height: responsiveHeight(3.2),
    },
  });
  return (
    <View style={styles.container}>
      <TouchableOpacity
        activeOpacity={0.6}
        onPress={() => {
          navigation.goBack();
        }}>
        <Image
          source={theme.dark ? arrowLeftDark : arrowLeft}
          style={styles.back_img}
        />
      </TouchableOpacity>
      <View style={{height: responsiveHeight(81)}}>
        <View style={styles.input_container}>
          <Text style={styles.email_text}>Email Address</Text>
          <View>
            <TextInput
              ref={emailInputRef}
              placeholderTextColor={COLORS.DARK_GREY}
              style={styles.input_style}
              placeholder="Enter Email Address"
              value={selectCreateAccountData.email}
              editable={isEmailEditTrue ? true : false}
              autoFocus={isEmailEditTrue ? true : false}
              onChangeText={value => {
                dispatch(setEmail(value));
                // setEmail(value);
              }}
            />
            <TouchableOpacity
              activeOpacity={0.7}
              style={styles.icon_style}
              onPress={() => {
                setIsEmailEditTrue(true);
              }}>
              <Image
                source={theme.dark ? editDark : editBlack}
                style={styles.input_img_style}
              />
            </TouchableOpacity>
          </View>
        </View>
        {emailMessage !== '' && (
          <Text style={styles.valid_msg}>{emailMessage}</Text>
        )}
        <View style={styles.input_container}>
          <Text style={styles.email_text}>Password</Text>
          <View>
            <TextInput
              placeholderTextColor={COLORS.DARK_GREY}
              style={styles.input_style}
              secureTextEntry
              placeholder="Enter Password"
              value={pass}
              onChangeText={value => {
                // dispatch(setEditPassword(value));
                setPass(value);
              }}
            />
          </View>
        </View>
        {passMsg !== '' && <Text style={styles.valid_msg}>{passMsg}</Text>}
      </View>

      <Button
        _onPress={() => {
          handleSave();
        }}
        _text={'Save'}
        _bgColor={COLORS.LIGHT_BLUE}
        _fontSize={FONTSIZE.FONT_SIZE_16}
        _color={COLORS.WHITE}
        _bColor={'transparent'}
      />
    </View>
  );
};

export default EditEmail;
