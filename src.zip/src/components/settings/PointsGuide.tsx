import {ScrollView, StyleSheet, Text, View} from 'react-native';
import React from 'react';
import {COLORS, FONTFAMILY} from '../../theme/Theme';
import {RFPercentage} from 'react-native-responsive-fontsize';
import {selectTheme} from '../../redux/slices/ThemeSlice';
import {useSelector} from 'react-redux';
const PointsGuide = () => {
  const theme = useSelector(selectTheme);

  const styles = StyleSheet.create({
    ans_text: {
      fontSize: RFPercentage(1.6),
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      marginTop: '1%',
    },
    ans_text_last: {
      fontSize: RFPercentage(1.6),
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      paddingTop: '5%',
    },
    que_text: {
      fontSize: RFPercentage(1.7),
      fontFamily: FONTFAMILY.BLACK,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      marginTop: '7%',
    },
    heading_history: {
      fontSize: RFPercentage(1.9),
      fontFamily: FONTFAMILY.BLACK,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      paddingTop: '12%',
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
      paddingHorizontal: 23,
      paddingBottom: '2%',
    },
  });
  return (
    <>
      <Text style={styles.heading_history}>How to earn points</Text>
      <ScrollView
        style={{
          backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
          paddingHorizontal: 23,
        }}>
        <Text style={styles.ans_text}>
          Here's how you earn points and unlock rewards
        </Text>
        <Text style={styles.que_text}>1. Daily Login - 5 Points Daily</Text>
        <Text style={styles.ans_text}>
          Consistency pays off! Get up to 5 points daily just by logging in.
          Your presence counts, and so do your points.
        </Text>
        <Text style={styles.que_text}>
          2. Create Tasks - 10 Points Per Task
        </Text>
        <Text style={styles.ans_text}>
          Plan your journey! Every task created earns you up to 10 points.
          Organize your goals and earn simultaneously
        </Text>
        <Text style={styles.que_text}>3. Complete Tasks - Up to 50 Points</Text>
        <Text style={styles.ans_text}>
          Achievement unlocked! Finish tasks to earn up to 50 points. Watch your
          progress grow along with your points.
        </Text>
        <Text style={styles.ans_text_last}>
          Join us, earn points, and let your progress lead to rewards. Start
          today and see your efforts bloom with every point earned!
        </Text>
      </ScrollView>
    </>
  );
};

export default PointsGuide;
