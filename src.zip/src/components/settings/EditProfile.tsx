import {
  Image,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  TextInput,
  Alert,
  PermissionsAndroid,
  Pressable,
} from 'react-native';
import React, {useEffect, useRef, useState} from 'react';
import {COLORS, FONTFAMILY, FONTSIZE} from '../../theme/Theme';
import {
  arrowLeft,
  arrowLeftDark,
  closeBig,
  editBlack,
  editDark,
  placeHolder,
} from '../../assets/images/Index';
import {RFPercentage} from 'react-native-responsive-fontsize';
import {useNavigation} from '@react-navigation/native';
import {
  responsiveHeight,
  responsiveWidth,
} from 'react-native-responsive-dimensions';
import Button from '../Button';
import {useSelector, useDispatch} from 'react-redux';
import {
  setFName,
  setLName,
  selectCreateAccount,
  setProfile,
} from '../../redux/slices/create_account_slice/CreateAccountSlices';
import ImagePicker from 'react-native-image-crop-picker';
import {selectTheme} from '../../redux/slices/ThemeSlice';
const EditProfile = () => {
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const selectCreateAccountData = useSelector(selectCreateAccount);
  const [isFNameEditTrue, setIsFNameEditTrue] = useState(false);
  const [isLNameEditTrue, setIsLNameEditTrue] = useState(false);
  const [imageUri, setImageUri] = useState('');
  const [isChoosPicOpen, setIsChoosPicOpen] = useState(false);
  console.log('selectCreateAccountData:', selectCreateAccountData);
  const theme = useSelector(selectTheme);
  // console.log('editFNameInput:', editFNameInput);
  const fNameInputRef = useRef<TextInput>(null);
  const lNameInputRef = useRef<TextInput>(null);

  useEffect(() => {
    if (isFNameEditTrue && fNameInputRef.current) {
      fNameInputRef.current.focus();
    }
  }, [isFNameEditTrue]);
  useEffect(() => {
    if (isLNameEditTrue && lNameInputRef.current) {
      lNameInputRef.current.focus();
    }
  }, [isLNameEditTrue]);

  const pickImageFromGallery = async () => {
    try {
      const image = await ImagePicker.openPicker({
        width: 300,
        height: 400,
        cropping: true,
      });
      // setImageUri(image.path);
      dispatch(setProfile(image.path));
      setIsChoosPicOpen(false);
    } catch (error) {
      console.log(error);
    }
  };
  const pickImageFromCamera = async () => {
    try {
      const cameraPermission = await requestCameraPermission();

      if (cameraPermission === 'granted') {
        const image = await ImagePicker.openCamera({
          width: 300,
          height: 400,
          cropping: true,
        });
        // setImageUri(image.path);
        dispatch(setProfile(image.path));
        setIsChoosPicOpen(false);
      } else {
        console.log('Camera permission denied');
      }
    } catch (error) {
      console.log(error);
    }
  };
  const requestCameraPermission = async () => {
    try {
      const cameraPermission = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.CAMERA,
      );

      console.log('Camera Permission Status (Android):', cameraPermission);

      return cameraPermission;
    } catch (error) {
      console.log('Error requesting camera permission:', error);
      return 'denied';
    }
  };

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
      paddingBottom: 10,
      paddingHorizontal: 23,
      zIndex: -20,
      paddingTop: 20,
    },
    profile_name_con: {
      alignItems: 'center',
      marginTop: '8%',
      height: responsiveHeight(18),
    },
    link_text: {
      color: COLORS.LIGHT_BLUE,
      fontFamily: FONTFAMILY.BOLD,
      textDecorationLine: 'underline',
      fontSize: RFPercentage(1.7),
      marginTop: '5%',
    },
    input_container: {
      marginTop: '8.5%',
    },
    email_text: {
      marginBottom: 10,
      fontSize: RFPercentage(1.8),
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    input_style: {
      borderRadius: 10,
      borderColor: theme.dark ? COLORS.LIGHT_BLUE : COLORS.MEDIUM_GREY,
      borderWidth: 1,
      paddingLeft: 20,
      fontSize: RFPercentage(2),
      paddingVertical: responsiveHeight(1.3),
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    icon_style: {
      position: 'absolute',
      right: 20,
      top: 14,
    },
    profile_big_style: {
      aspectRatio: 1,
      resizeMode: 'contain',
      height: responsiveHeight(13),
      width: responsiveWidth(13),
      borderRadius: responsiveHeight(6.5),
    },
    input_img_style: {
      aspectRatio: 1,
      height: responsiveHeight(1),
      width: responsiveWidth(1),
      marginTop: '3%',
      padding: responsiveHeight(1.3),
    },
    add_start_time_con: {
      position: 'absolute',
      backgroundColor: 'rgba(0,0,0,0.7)',
      height: responsiveHeight(100),
      width: responsiveWidth(100),
      justifyContent: 'center',
      alignItems: 'center',
    },
    pop_container: {
      width: responsiveWidth(90),
      padding: responsiveHeight(2.7),
      backgroundColor: COLORS.WHITE,
      borderRadius: responsiveHeight(1),
    },
    close_icon_big: {
      aspectRatio: 1,
      height: responsiveHeight(3.2),
      width: responsiveWidth(7),
      position: 'absolute',
      right: responsiveHeight(-1),
      top: responsiveHeight(-9),
    },
    pop_title_text: {
      fontFamily: FONTFAMILY.BLACK,
      fontSize: RFPercentage(2.9),
      color: COLORS.BLACK,
      textAlign: 'center',
      // backgroundColor: 'red',
      width: '100%',
      // zIndex: -23,
      marginBottom: '10%',
    },
    container_p: {
      backgroundColor: COLORS.RED,
      borderRadius: responsiveHeight(1),
    },
    back_img: {
      aspectRatio: 1,
      resizeMode: 'cover',
      width: responsiveHeight(2),
      height: responsiveHeight(3.2),
    },
  });
  return (
    <>
      <View style={styles.container}>
        <TouchableOpacity
          activeOpacity={0.6}
          onPress={() => {
            navigation.goBack();
          }}>
          <Image
            source={theme.dark ? arrowLeftDark : arrowLeft}
            style={styles.back_img}
          />
        </TouchableOpacity>
        <View style={styles.profile_name_con}>
          {selectCreateAccountData.profile !== '' ? (
            <TouchableOpacity onPress={() => {}}>
              <Image
                source={{uri: selectCreateAccountData.profile}}
                style={styles.profile_big_style}
              />
            </TouchableOpacity>
          ) : (
            <Image source={placeHolder} style={styles.profile_big_style} />
          )}
          <Text
            style={styles.link_text}
            onPress={() => {
              setIsChoosPicOpen(true);
            }}>
            {selectCreateAccountData.profile !== ''
              ? 'Change Profile Picture'
              : 'Upload Profile Picture'}
          </Text>
        </View>
        <View style={{height: responsiveHeight(59.5)}}>
          <View style={styles.input_container}>
            <Text style={styles.email_text}>First Name</Text>
            <View>
              <TextInput
                ref={fNameInputRef}
                placeholderTextColor={COLORS.DARK_GREY}
                style={styles.input_style}
                editable={isFNameEditTrue ? true : false}
                placeholder="First Name"
                autoFocus={isFNameEditTrue ? true : false}
                value={selectCreateAccountData.fName}
                onChangeText={value => {
                  dispatch(setFName(value));
                }}
              />
              <TouchableOpacity
                activeOpacity={0.7}
                style={styles.icon_style}
                onPress={() => {
                  setIsFNameEditTrue(true);
                }}>
                <Image
                  source={theme.dark ? editDark : editBlack}
                  style={styles.input_img_style}
                />
              </TouchableOpacity>
            </View>
          </View>
          <View style={styles.input_container}>
            <Text style={styles.email_text}>Last Name</Text>
            <View>
              <TextInput
                ref={lNameInputRef}
                placeholderTextColor={COLORS.DARK_GREY}
                style={styles.input_style}
                editable={isLNameEditTrue ? true : false}
                value={selectCreateAccountData.lName}
                placeholder="Last Name"
                autoFocus={isLNameEditTrue ? true : false}
                onChangeText={value => {
                  dispatch(setLName(value));
                }}
              />
              <TouchableOpacity
                activeOpacity={0.7}
                style={styles.icon_style}
                onPress={() => {
                  setIsLNameEditTrue(true);
                }}>
                <Image
                  source={theme.dark ? editDark : editBlack}
                  style={styles.input_img_style}
                />
              </TouchableOpacity>
            </View>
          </View>
        </View>

        <Button
          _onPress={() => {
            Alert.alert('Saved!');
            navigation.goBack();
          }}
          _text={'Save'}
          _bgColor={COLORS.LIGHT_BLUE}
          _fontSize={FONTSIZE.FONT_SIZE_16}
          _color={COLORS.WHITE}
          _bColor={'transparent'}
        />
      </View>

      {isChoosPicOpen && (
        <Pressable
          style={styles.add_start_time_con}
          onPress={() => {
            setIsChoosPicOpen(false);
          }}>
          <View style={styles.container_p}>
            <Pressable
              style={styles.pop_container}
              onPress={() => {
                setIsChoosPicOpen(true);
              }}>
              <Text style={styles.pop_title_text}>Choose Source</Text>
              <TouchableOpacity
                activeOpacity={0.7}
                onPress={() => {
                  //  setIsAddStartTimeOpen(!isAddStartTimeOpen);
                  setIsChoosPicOpen(false);
                }}>
                <Image source={closeBig} style={styles.close_icon_big} />
              </TouchableOpacity>
              <Button
                _onPress={() => {
                  // addStartTimeData();
                  // setIsAddStartTimeOpen(false);
                  pickImageFromCamera();
                }}
                _text={'Camera'}
                _bgColor={COLORS.LIGHT_BLUE}
                _fontSize={FONTSIZE.FONT_SIZE_16}
                _color={COLORS.WHITE}
                _bColor={'transparent'}
              />
              <View style={{marginVertical: '2%'}}></View>
              <Button
                _onPress={() => {
                  // addStartTimeData();
                  // setIsAddStartTimeOpen(false);
                  pickImageFromGallery();
                }}
                _text={'Gallery'}
                _bgColor={COLORS.DARK_BLUE}
                _fontSize={FONTSIZE.FONT_SIZE_16}
                _color={COLORS.WHITE}
                _bColor={'transparent'}
              />
            </Pressable>
          </View>
        </Pressable>
      )}
    </>
  );
};

export default EditProfile;
