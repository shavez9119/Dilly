import {
  Image,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import React, {useState} from 'react';
import {COLORS, FONTFAMILY, FONTSIZE} from '../../theme/Theme';
import {arrowLeft, arrowLeftDark} from '../../assets/images/Index';
import {RFPercentage} from 'react-native-responsive-fontsize';
import {useNavigation} from '@react-navigation/native';
import {
  responsiveHeight,
  responsiveScreenHeight,
  responsiveScreenWidth,
} from 'react-native-responsive-dimensions';
import Button from '../Button';
import {selectTheme} from '../../redux/slices/ThemeSlice';
import {useSelector} from 'react-redux';

const EditSyncing = () => {
  const navigation = useNavigation();
  const [isGoogleSyncEnabled, setIsGoogleSyncEnabled] = useState(false);
  const [isMicrosoftSyncEnabled, setIsMicorsoftSyncEnabled] = useState(false);
  const [isAppleSyncEnabled, setIsAppleSyncEnabled] = useState(false);
  const theme = useSelector(selectTheme);

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
      paddingBottom: 10,
      paddingHorizontal: 23,
      zIndex: -20,
      paddingTop: 20,
    },
    input_container: {
      marginTop: '8.5%',
    },
    email_text: {
      marginBottom: 10,
      fontSize: RFPercentage(1.8),
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    input_style: {
      borderRadius: 10,
      borderColor: COLORS.LIGHT_GREY,
      borderWidth: 1,
      paddingLeft: 20,
      fontSize: RFPercentage(1.8),
      paddingVertical: responsiveHeight(1.1),
      fontFamily: FONTFAMILY.REGULAR,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    icon_style: {
      position: 'absolute',
      right: 20,
      top: 14,
    },
    flex: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
    },
    switch_false: {
      backgroundColor: COLORS.WHITE,
      borderRadius: 50,
      height: '75%',
      width: '42%',
      margin: 3,
      right: 0,
      position: 'absolute',
    },
    switch_true: {
      backgroundColor: COLORS.WHITE,
      borderRadius: 50,
      height: '75%',
      width: '42%',
      margin: 3,
      left: 0,
      position: 'absolute',
    },
    switch_button_true: {
      backgroundColor: COLORS.LIGHT_BLUE,
      borderRadius: 50,
      height: responsiveScreenHeight(2.6),
      width: responsiveScreenWidth(10.7),
      justifyContent: 'center',
    },
    switch_button_false: {
      backgroundColor: COLORS.LIGHT_GREY,
      borderRadius: 50,
      height: responsiveScreenHeight(2.6),
      width: responsiveScreenWidth(10.7),
      justifyContent: 'center',
    },
    auto_schedule_section: {
      backgroundColor: COLORS.WHITE,
      paddingHorizontal: 23,
      height: responsiveScreenHeight(12),
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
    },
    back_img: {
      aspectRatio: 1,
      resizeMode: 'cover',
      width: responsiveHeight(2),
      height: responsiveHeight(3.2),
    },
  });
  return (
    <View style={styles.container}>
      <TouchableOpacity
        activeOpacity={0.6}
        onPress={() => {
          navigation.goBack();
        }}>
        <Image
          source={theme.dark ? arrowLeftDark : arrowLeft}
          style={styles.back_img}
        />
      </TouchableOpacity>
      <View style={{height: responsiveHeight(81)}}>
        <View style={styles.input_container}>
          <View style={styles.flex}>
            <Text style={styles.email_text}>Google Calendar</Text>
            <View style={{marginBottom: 10}}>
              <TouchableOpacity
                onPress={() => {
                  setIsGoogleSyncEnabled(!isGoogleSyncEnabled);
                }}
                activeOpacity={0.9}
                style={[
                  isGoogleSyncEnabled
                    ? styles.switch_button_true
                    : styles.switch_button_false,
                ]}>
                <TouchableOpacity
                  onPress={() => {
                    setIsGoogleSyncEnabled(!isGoogleSyncEnabled);
                  }}
                  activeOpacity={0.9}
                  style={[
                    isGoogleSyncEnabled
                      ? styles.switch_false
                      : styles.switch_true,
                  ]}></TouchableOpacity>
              </TouchableOpacity>
            </View>
          </View>
          {isGoogleSyncEnabled && (
            <View>
              <TextInput
                placeholderTextColor={theme.dark ? COLORS.WHITE : COLORS.BLACK}
                style={styles.input_style}
                placeholder="divyanshbhatnagar14@gmail.com"
                editable={false}
              />
            </View>
          )}
        </View>
        <View style={styles.input_container}>
          <View style={styles.flex}>
            <Text style={styles.email_text}>Microsoft Calendar</Text>
            <View style={{marginBottom: 10}}>
              <TouchableOpacity
                onPress={() => {
                  setIsMicorsoftSyncEnabled(!isMicrosoftSyncEnabled);
                }}
                activeOpacity={0.9}
                style={[
                  isMicrosoftSyncEnabled
                    ? styles.switch_button_true
                    : styles.switch_button_false,
                ]}>
                <TouchableOpacity
                  onPress={() => {
                    setIsMicorsoftSyncEnabled(!isMicrosoftSyncEnabled);
                  }}
                  activeOpacity={0.9}
                  style={[
                    isMicrosoftSyncEnabled
                      ? styles.switch_false
                      : styles.switch_true,
                  ]}></TouchableOpacity>
              </TouchableOpacity>
            </View>
          </View>

          {isMicrosoftSyncEnabled && (
            <View>
              <TextInput
                placeholderTextColor={theme.dark ? COLORS.WHITE : COLORS.BLACK}
                style={styles.input_style}
                placeholder="divyanshbhatnagar14@gmail.com"
                editable={false}
              />
            </View>
          )}
        </View>
        <View style={styles.input_container}>
          <View style={styles.flex}>
            <Text style={styles.email_text}>Apple Calendar</Text>
            <View style={{marginBottom: 10}}>
              <TouchableOpacity
                onPress={() => {
                  setIsAppleSyncEnabled(!isAppleSyncEnabled);
                }}
                activeOpacity={0.9}
                style={[
                  isAppleSyncEnabled
                    ? styles.switch_button_true
                    : styles.switch_button_false,
                ]}>
                <TouchableOpacity
                  onPress={() => {
                    setIsAppleSyncEnabled(!isAppleSyncEnabled);
                  }}
                  activeOpacity={0.9}
                  style={[
                    isAppleSyncEnabled
                      ? styles.switch_false
                      : styles.switch_true,
                  ]}></TouchableOpacity>
              </TouchableOpacity>
            </View>
          </View>
          {isAppleSyncEnabled && (
            <View>
              <TextInput
                placeholderTextColor={theme.dark ? COLORS.WHITE : COLORS.BLACK}
                style={styles.input_style}
                placeholder="divyanshbhatnagar14@gmail.com"
                editable={false}
              />
            </View>
          )}
        </View>
      </View>

      <Button
        _onPress={() => {
          // setStep(step + 1);
        }}
        _text={'Save'}
        _bgColor={COLORS.LIGHT_BLUE}
        _fontSize={FONTSIZE.FONT_SIZE_16}
        _color={COLORS.WHITE}
        _bColor={'transparent'}
      />
    </View>
  );
};

export default EditSyncing;
