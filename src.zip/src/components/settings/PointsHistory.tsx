import {ScrollView, StyleSheet, Text, View} from 'react-native';
import React from 'react';
import {COLORS, FONTFAMILY} from '../../theme/Theme';
import {
  responsiveScreenHeight,
  responsiveScreenWidth,
} from 'react-native-responsive-dimensions';
import {RFPercentage} from 'react-native-responsive-fontsize';
import {selectTheme} from '../../redux/slices/ThemeSlice';
import {useSelector} from 'react-redux';

const PointsHistory = () => {
  const theme = useSelector(selectTheme);

  const styles = StyleSheet.create({
    heading: {
      fontSize: RFPercentage(1.9),
      fontFamily: FONTFAMILY.BLACK,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      // height: responsiveScreenHeight(7),
      paddingTop: '6%',
      marginBottom: '2%',
    },
    divider: {
      height: responsiveScreenHeight(0.2),
      width: responsiveScreenWidth(100),
      backgroundColor: theme.dark ? COLORS.LIGHT_BLACK : COLORS.LIGHT_GREY,
    },

    rest_content: {
      flexDirection: 'row',
      gap: responsiveScreenHeight(1),
    },
    description_text: {
      fontSize: RFPercentage(1.6),
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    section_divider: {
      paddingHorizontal: 23,
      paddingVertical: responsiveScreenHeight(1.5),
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
    },
    dot_styl: {
      fontSize: RFPercentage(3.5),
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      // backgroundColor: 'red',
      height: responsiveScreenHeight(4),
      bottom: responsiveScreenHeight(2.3),
      // marginRight: 20,
    },
    underline_text: {
      textDecorationColor: COLORS.BLACK,
      textDecorationLine: 'underline',
    },
    scroll_con: {
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
    },
  });
  return (
    <>
      <View
        style={{
          backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
          paddingHorizontal: 23,
          paddingTop: responsiveScreenHeight(3),
        }}>
        <Text style={styles.heading}>Points History</Text>
      </View>
      <ScrollView style={styles.scroll_con}>
        <View style={styles.section_divider}>
          <View style={styles.rest_content}>
            <Text style={styles.dot_styl}>.</Text>
            <Text style={styles.description_text}>
              You earned 30 points for Completing Task:
              <Text style={styles.underline_text}> Wireframe & Prototype</Text>.
            </Text>
          </View>
        </View>
        <View style={styles.divider}></View>
        <View style={styles.section_divider}>
          <View style={styles.rest_content}>
            <Text style={styles.dot_styl}>.</Text>
            <Text style={styles.description_text}>
              You earned 30 points for Creating Task:
              <Text style={styles.underline_text}> Wireframe & Prototype</Text>.
            </Text>
          </View>
        </View>
        <View style={styles.divider}></View>
        <View style={styles.section_divider}>
          <View style={styles.rest_content}>
            <Text style={styles.dot_styl}>.</Text>
            <Text style={styles.description_text}>
              You earned 10 points as Daily Login Reward.
            </Text>
          </View>
        </View>
        <View style={styles.divider}></View>
        <View style={styles.section_divider}>
          <View style={styles.rest_content}>
            <Text style={styles.dot_styl}>.</Text>
            <Text style={styles.description_text}>
              You earned 30 points for Completing Task:
              <Text style={styles.underline_text}> Wireframe & Prototype</Text>.
            </Text>
          </View>
        </View>
        <View style={styles.divider}></View>
        <View style={styles.section_divider}>
          <View style={styles.rest_content}>
            <Text style={styles.dot_styl}>.</Text>
            <Text style={styles.description_text}>
              You earned 30 points for Creating Task:
              <Text style={styles.underline_text}> Wireframe & Prototype</Text>.
            </Text>
          </View>
        </View>
        <View style={styles.divider}></View>
        <View style={styles.section_divider}>
          <View style={styles.rest_content}>
            <Text style={styles.dot_styl}>.</Text>
            <Text style={styles.description_text}>
              You earned 10 points as Daily Login Reward.
            </Text>
          </View>
        </View>
      </ScrollView>
    </>
  );
};

export default PointsHistory;
