import {Image, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import React, {useState} from 'react';
import {COLORS, FONTFAMILY} from '../../theme/Theme';
import {useNavigation} from '@react-navigation/native';
import {
  arrowLeft,
  arrowLeftDark,
  rewardBig,
  rewardBigDark,
} from '../../assets/images/Index';
import {RFPercentage} from 'react-native-responsive-fontsize';
import {
  responsiveHeight,
  responsiveScreenHeight,
  responsiveScreenWidth,
} from 'react-native-responsive-dimensions';
import {PointsHistory, PointsGuide} from '../Index';
import {selectTheme} from '../../redux/slices/ThemeSlice';
import {useSelector} from 'react-redux';

const Reward = () => {
  const navigation = useNavigation();
  const [isPointsEarnedActive, setIsPointsEarnedActive] = useState(true);
  const [isGuideActive, setIsGuideActive] = useState(false);
  const theme = useSelector(selectTheme);

  const styles = StyleSheet.create({
    container: {
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
      paddingBottom: 10,
      paddingHorizontal: 23,
      paddingTop: 20,
    },
    back_arrow: {
      paddingLeft: 0,
      paddingRight: 50,
      paddingBottom: 10,
      paddingTop: 10,
      width: '15%',
    },
    text: {
      textAlign: 'center',
      fontSize: RFPercentage(2),
      bottom: 20,
      fontFamily: FONTFAMILY.BLACK,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      marginTop: -13,
    },
    heading: {
      fontSize: RFPercentage(1.9),
      fontFamily: FONTFAMILY.BLACK,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      height: responsiveScreenHeight(7),
      paddingTop: '4%',
    },
    flex: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 20,
      height: responsiveScreenHeight(10),
    },
    reward_count_text: {
      color: COLORS.LIGHT_BLUE,
      fontSize: RFPercentage(3.4),
      fontFamily: FONTFAMILY.BOLD,
    },
    divider: {
      height: responsiveScreenHeight(0.5),
      width: responsiveScreenWidth(100),
      backgroundColor: theme.dark ? COLORS.LIGHT_BLACK : COLORS.LIGHT_GREY,
    },
    reward_bottom_section: {
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
      paddingHorizontal: 23,
    },
    buttons_bg: {
      backgroundColor: theme.dark ? COLORS.LIGHT_BLACK : COLORS.LIGHT_GREY,
      paddingHorizontal: responsiveScreenHeight(0.8),
      // paddingVertical: responsiveScreenHeight(0.),
      marginTop: '8%',
      borderRadius: 10,
    },
    pointes_active: {
      fontSize: RFPercentage(1.9),
      fontFamily: FONTFAMILY.BLACK,
      color: COLORS.WHITE,
      paddingHorizontal: responsiveScreenWidth(8),
      paddingVertical: responsiveScreenWidth(5),
      marginRight: responsiveScreenWidth(4.7),
    },
    points_not_active: {
      fontSize: RFPercentage(1.9),
      fontFamily: FONTFAMILY.BLACK,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      paddingHorizontal: responsiveScreenWidth(11),
      paddingVertical: responsiveScreenWidth(5),
      marginRight: responsiveScreenWidth(6),
    },
    guide_active: {
      fontSize: RFPercentage(1.9),
      fontFamily: FONTFAMILY.BLACK,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      paddingHorizontal: responsiveScreenWidth(11),
      paddingVertical: responsiveScreenWidth(5),
      marginLeft: responsiveScreenHeight(1.4),
    },
    guide_not_active: {
      fontSize: RFPercentage(1.9),
      fontFamily: FONTFAMILY.BLACK,
      color: COLORS.WHITE,
      paddingHorizontal: responsiveScreenWidth(11),
      paddingVertical: responsiveScreenWidth(5),
      marginRight: responsiveScreenHeight(2.4),
    },
    reward_big_img: {
      aspectRatio: 1,
      resizeMode: 'contain',
      // height: responsiveScreenHeight(12),
      width: responsiveScreenWidth(12.5),
    },
    back_img: {
      aspectRatio: 1,
      resizeMode: 'cover',
      width: responsiveHeight(2),
      height: responsiveHeight(3.2),
    },
  });
  return (
    <>
      <View style={styles.container}>
        <TouchableOpacity
          style={styles.back_arrow}
          onPress={() => {
            navigation.goBack();
          }}>
          <Image
            source={theme.dark ? arrowLeftDark : arrowLeft}
            style={styles.back_img}
          />
        </TouchableOpacity>
        <Text style={styles.text}>Rewards</Text>
        <Text style={styles.heading}>My Points</Text>
        <View style={styles.flex}>
          <Image
            source={theme.dark ? rewardBigDark : rewardBig}
            style={styles.reward_big_img}
          />
          <Text style={styles.reward_count_text}>200,000</Text>
        </View>
      </View>
      <View style={styles.divider}></View>
      <View style={styles.reward_bottom_section}>
        <View style={styles.buttons_bg}>
          <View style={{}}>
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'space-around',
                alignItems: 'center',
                gap: responsiveScreenWidth(6),
              }}>
              {isPointsEarnedActive && (
                <TouchableOpacity
                  activeOpacity={0.7}
                  onPress={() => {
                    setIsPointsEarnedActive(true);
                    setIsGuideActive(false);
                  }}
                  style={{
                    position: 'absolute',
                    backgroundColor: COLORS.LIGHT_BLUE,
                    height: responsiveScreenHeight(5.3),
                    width: responsiveScreenWidth(40),
                    left: '0%',
                    zIndex: -1,
                    borderRadius: 10,
                    marginTop: '2%',
                  }}></TouchableOpacity>
              )}
              <Text
                onPress={() => {
                  setIsPointsEarnedActive(true);
                  setIsGuideActive(false);
                }}
                style={[
                  isPointsEarnedActive
                    ? styles.pointes_active
                    : styles.points_not_active,
                ]}>
                Points Earned
              </Text>
              {isGuideActive && (
                <TouchableOpacity
                  activeOpacity={0.7}
                  onPress={() => {
                    setIsGuideActive(true);
                    setIsPointsEarnedActive(false);
                  }}
                  style={{
                    position: 'absolute',
                    backgroundColor: COLORS.LIGHT_BLUE,
                    height: responsiveScreenHeight(5.3),
                    width: responsiveScreenWidth(40),
                    right: '0%',
                    zIndex: -1,
                    borderRadius: 10,
                    marginTop: '2%',
                  }}></TouchableOpacity>
              )}
              <Text
                onPress={() => {
                  setIsGuideActive(true);
                  setIsPointsEarnedActive(false);
                }}
                style={[
                  isPointsEarnedActive
                    ? styles.guide_active
                    : styles.guide_not_active,
                ]}>
                Guide
              </Text>
            </View>
          </View>
        </View>
      </View>
      {isPointsEarnedActive ? (
        <>
          <PointsHistory />
        </>
      ) : (
        <>
          <PointsGuide />
        </>
      )}
    </>
  );
};

export default Reward;
