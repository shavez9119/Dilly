import {StyleSheet, Text, View, TouchableOpacity, Image} from 'react-native';
import React from 'react';
import {buttonPropIF} from '../types/Types';
import {FONTFAMILY, FONTSIZE} from '../theme/Theme';
import {
  responsiveHeight,
  responsiveScreenWidth,
} from 'react-native-responsive-dimensions';

const Button = ({
  _text,
  _bgColor,
  _color,
  _bColor,
  _img_source,
  _onPress,
}: buttonPropIF) => {
  return (
    <TouchableOpacity
      onPress={_onPress}
      activeOpacity={0.7}
      style={[
        styles.buttonContainer,
        {backgroundColor: _bgColor, borderColor: _bColor},
      ]}>
      {_img_source ? (
        <View style={styles.img_button_contaienr}>
          <Image source={_img_source} style={styles.img_style} />

          <Text style={[styles.buttonText, {color: _color}]}>{_text}</Text>
        </View>
      ) : (
        <Text style={[styles.buttonText, {color: _color}]}>{_text}</Text>
      )}
    </TouchableOpacity>
  );
};

export default Button;
const styles = StyleSheet.create({
  buttonContainer: {
    borderRadius: 8,
    paddingVertical: 13,
    borderWidth: 1,
  },
  buttonText: {
    fontSize: FONTSIZE.FONT_SIZE_20,
    fontFamily: FONTFAMILY.BLACK,
    textAlign: 'center',
  },
  img_button_contaienr: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: responsiveHeight(2),
  },
  img_style: {
    aspectRatio: 1,
    height: responsiveHeight(6),
    width: responsiveScreenWidth(6),
  },
});
