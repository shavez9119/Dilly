import {Image, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import React, {useEffect, useState} from 'react';
import Button from '../../components/Button';
import {COLORS, FONTFAMILY, FONTSIZE} from '../../theme/Theme';
import {
  responsiveHeight,
  responsiveWidth,
} from 'react-native-responsive-dimensions';
import {RFPercentage} from 'react-native-responsive-fontsize';
import {arrowLeft, arrowLeftDark} from '../../assets/images/Index';
import {useDispatch, useSelector} from 'react-redux';
import {
  toggleWorkingDays,
  selectWorkingDays,
} from '../../redux/slices/WorkingDaysSlice';
import {selectTheme} from '../../redux/slices/ThemeSlice';
const WorkingDays = ({
  step,
  setStep,
}: {
  step: number;
  setStep: React.Dispatch<React.SetStateAction<number>>;
}) => {
  const dispatch = useDispatch();
  const [isWorkingDaysValid, setIsWorkingDaysValid] = useState(false);
  const [message, setMessage] = useState('');
  const {workingDays, selectedWorkingDays} = useSelector(selectWorkingDays);
  const theme = useSelector(selectTheme);

  // VALIDATE USER SELECTED ATLEAST 1 DAY OR NOT
  const validateWorkingDays = () => {
    if (selectedWorkingDays.length >= 1) {
      setStep(step + 1);
    } else {
      return false;
    }
  };

  useEffect(() => {
    if (selectedWorkingDays.length < 1) {
      setIsWorkingDaysValid(false);
      setMessage('Please select atleast 1 day');
    } else {
      setIsWorkingDaysValid(true);
      setMessage('');
    }
  }, [selectedWorkingDays]);

  const selectWorkingDay = (index: number) => {
    dispatch(toggleWorkingDays(index));
  };

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
      paddingHorizontal: 23,
      paddingTop: responsiveHeight(7),
    },
    text: {
      textAlign: 'center',
      fontSize: RFPercentage(2),
      bottom: 20,
      fontFamily: FONTFAMILY.BLACK,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      marginTop: -13,
    },
    progress_outer: {
      marginTop: 10,
      height: responsiveHeight(1),
      borderRadius: 10,
      backgroundColor: theme.dark ? COLORS.LIGHT_BLACK : COLORS.LIGHT_GREY,
    },
    progress_inner: {
      position: 'absolute',
      backgroundColor: COLORS.LIGHT_BLUE,
      width: '71%',
      height: responsiveHeight(1),
      borderRadius: 10,
    },
    heading: {
      fontSize: RFPercentage(2.8),
      fontFamily: FONTFAMILY.BLACK,
      marginTop: 40,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    sub_heading: {
      fontSize: RFPercentage(1.5),
      marginTop: 10,
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.MEDIUM_GREY : COLORS.LIGHT_BLACK,
    },

    dyas_container: {
      flexDirection: 'row',
      justifyContent: 'space-evenly',
      gap: 14,
    },
    days_selected: {
      backgroundColor: COLORS.LIGHT_BLUE,
      height: responsiveHeight(4.8),
      width: responsiveWidth(10),
      borderRadius: 70,
      alignItems: 'center',
      justifyContent: 'center',
    },
    days_text_unselected: {
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      fontFamily: FONTFAMILY.BLACK,
    },
    days_text_selected: {
      color: COLORS.WHITE,
      fontFamily: FONTFAMILY.BLACK,
    },
    days_unselected: {
      backgroundColor: theme.dark ? COLORS.LIGHT_BLACK : COLORS.LIGHT_GREY,
      height: responsiveHeight(4.8),
      width: responsiveWidth(10),
      borderRadius: 50,
      alignItems: 'center',
      justifyContent: 'center',
    },
    valid_msg: {
      fontFamily: FONTFAMILY.MEDIUM,
      color: COLORS.RED,
      marginTop: '4%',
      fontSize: RFPercentage(1.8),
    },
    back_img: {
      aspectRatio: 1,
      resizeMode: 'cover',
      width: responsiveHeight(2),
      height: responsiveHeight(3.2),
    },
  });
  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={{
          position: 'absolute',
          top: 0,
          marginTop: responsiveHeight(1.6),
          padding: 10,
          left: 10,
          width: '15%',
          zIndex: 999,
        }}
        onPress={() => {
          setStep(step - 1);
        }}>
        <Image
          source={theme.dark ? arrowLeftDark : arrowLeft}
          style={styles.back_img}
        />
      </TouchableOpacity>
      <Text style={styles.text}>Create an Account</Text>

      <View style={styles.progress_outer}>
        <View style={styles.progress_inner}></View>
      </View>
      <View style={{height: responsiveHeight(16)}}>
        <Text style={styles.heading}>Setup your Working Days.</Text>
        <Text style={styles.sub_heading}>Setup your working days.</Text>
      </View>
      <View style={styles.dyas_container}>
        {workingDays.map((item: string, index: number) => {
          return (
            <TouchableOpacity
              key={index}
              activeOpacity={10}
              onPress={() => selectWorkingDay(index)}
              style={[
                styles.days_unselected,
                selectedWorkingDays.includes(index) && styles.days_selected,
              ]}>
              <Text
                style={[
                  styles.days_text_unselected,
                  selectedWorkingDays.includes(index) &&
                    styles.days_text_selected,
                ]}>
                {item}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>
      <View style={{height: responsiveHeight(56.5)}}>
        <Text style={styles.valid_msg}>{message}</Text>
      </View>

      <Button
        _onPress={() => {
          validateWorkingDays();
        }}
        _text={'Continue'}
        _bgColor={isWorkingDaysValid ? COLORS.LIGHT_BLUE : COLORS.LIGHT_BLACK}
        _fontSize={FONTSIZE.FONT_SIZE_16}
        _color={COLORS.WHITE}
        _bColor={'transparent'}
      />
    </View>
  );
};

export default WorkingDays;
