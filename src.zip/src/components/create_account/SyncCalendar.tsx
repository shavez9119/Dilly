import {
  Image,
  Pressable,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React from 'react';
import Button from '../../components/Button';
import {COLORS, FONTFAMILY, FONTSIZE} from '../../theme/Theme';
import {responsiveHeight} from 'react-native-responsive-dimensions';
import {RFPercentage} from 'react-native-responsive-fontsize';
import {arrowLeft, arrowLeftDark, arrowRight} from '../../assets/images/Index';

import {useDispatch, useSelector} from 'react-redux';

import {selectTheme} from '../../redux/slices/ThemeSlice';
const SyncCalendar = ({
  step,
  setStep,
}: {
  step: number;
  setStep: React.Dispatch<React.SetStateAction<number>>;
}) => {
  const dispatch = useDispatch();
  const theme = useSelector(selectTheme);
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
      paddingHorizontal: 23,
      paddingTop: responsiveHeight(7),
    },
    text: {
      textAlign: 'center',
      fontSize: RFPercentage(2),
      bottom: 20,
      fontFamily: FONTFAMILY.BLACK,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      marginTop: -13,
    },
    progress_outer: {
      marginTop: 10,
      height: responsiveHeight(1),
      borderRadius: 10,
      backgroundColor: theme.dark ? COLORS.LIGHT_BLACK : COLORS.LIGHT_GREY,
    },
    progress_inner: {
      position: 'absolute',
      backgroundColor: COLORS.LIGHT_BLUE,
      width: '71%',
      height: responsiveHeight(1),
      borderRadius: 10,
    },
    heading: {
      fontSize: RFPercentage(2.8),
      fontFamily: FONTFAMILY.BLACK,
      marginTop: 40,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    sub_heading: {
      fontSize: RFPercentage(1.5),
      marginTop: 10,
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.MEDIUM_GREY : COLORS.LIGHT_BLACK,
    },
    buttons_gap: {
      marginVertical: responsiveHeight(0.9),
    },
    button_container: {
      height: responsiveHeight(60),
      marginTop: '10%',
    },
    skip_button_con: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 10,
    },
    skip_text: {
      color: COLORS.LIGHT_BLUE,
      fontFamily: FONTFAMILY.BOLD,
      marginRight: 5,
      fontSize: RFPercentage(1.9),
    },
    back_img: {
      aspectRatio: 1,
      resizeMode: 'cover',
      width: responsiveHeight(2),
      height: responsiveHeight(3.2),
    },
    skip_img: {
      aspectRatio: 1,
      resizeMode: 'cover',
      width: responsiveHeight(3.5),
    },
  });
  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={{
          position: 'absolute',
          top: 0,
          marginTop: responsiveHeight(1.6),
          padding: 10,
          left: 10,
          width: '15%',
          zIndex: 999,
        }}
        onPress={() => {
          setStep(step - 1);
        }}>
        <Image
          source={theme.dark ? arrowLeftDark : arrowLeft}
          style={styles.back_img}
        />
      </TouchableOpacity>
      <Text style={styles.text}>Create an Account</Text>

      <View style={styles.progress_outer}>
        <View style={styles.progress_inner}></View>
      </View>
      <View style={{height: responsiveHeight(13)}}>
        <Text style={styles.heading}>Sync your Calendar</Text>
        <Text style={styles.sub_heading}>
          To switch the email IDs and sync the calendar, tap the same calendar
          tab again and select the desired ID. You can also synchronize multiple
          calendars
        </Text>
      </View>

      <View style={styles.button_container}>
        <View style={styles.buttons_gap}>
          <Button
            _onPress={() => {}}
            _text={'Google Calendar'}
            _bgColor={COLORS.RED}
            _fontSize={FONTSIZE.FONT_SIZE_16}
            _color={COLORS.WHITE}
            _bColor={'transparent'}
          />
        </View>
        <View style={styles.buttons_gap}>
          <Button
            _onPress={() => {}}
            _text={'Microsoft Calendar'}
            _bgColor={COLORS.PURPLE}
            _fontSize={FONTSIZE.FONT_SIZE_16}
            _color={COLORS.WHITE}
            _bColor={'transparent'}
          />
        </View>
        <View style={styles.buttons_gap}>
          <Button
            _onPress={() => {}}
            _text={'Apple Calendar'}
            _bgColor={theme.dark ? COLORS.WHITE : COLORS.BLACK}
            _fontSize={FONTSIZE.FONT_SIZE_16}
            _color={theme.dark ? COLORS.DARK : COLORS.WHITE}
            _bColor={'transparent'}
          />
        </View>
        <TouchableOpacity
          style={styles.skip_button_con}
          onPress={() => {
            setStep(step + 1);
          }}>
          <Text style={styles.skip_text}>Skip</Text>
          <Image source={arrowRight} style={styles.skip_img} />
        </TouchableOpacity>
      </View>

      <Button
        _onPress={() => {
          setStep(step + 1);
        }}
        _text={'Continue'}
        _bgColor={COLORS.LIGHT_BLUE}
        _fontSize={FONTSIZE.FONT_SIZE_16}
        _color={COLORS.WHITE}
        _bColor={'transparent'}
      />
    </View>
  );
};

export default SyncCalendar;
