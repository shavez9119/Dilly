import {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  TextInput,
  Alert,
} from 'react-native';
import React, {useState, useEffect} from 'react';
import {COLORS, FONTFAMILY, FONTSIZE} from '../../theme/Theme';
import {RFPercentage} from 'react-native-responsive-fontsize';
import DateTimePicker from '@react-native-community/datetimepicker';

import {
  responsiveHeight,
  responsiveWidth,
} from 'react-native-responsive-dimensions';
import Button from '../../components/Button';
import {
  arrowLeft,
  arrowLeftDark,
  clock,
  clockDark,
} from '../../assets/images/Index';
import {useSelector, useDispatch} from 'react-redux';
import {
  updateWorkingFromHours,
  updateWorkingToHours,
  selectWorkingTime,
  setFromTime,
  setToTime,
} from '../../redux/slices/WorkingHoursSlice';
import {selectTheme} from '../../redux/slices/ThemeSlice';
import {useNavigation} from '@react-navigation/native';
const WorkingHours = ({
  step,
  setStep,
}: {
  step: number;
  setStep: React.Dispatch<React.SetStateAction<number>>;
}) => {
  const [showFromTimePicker, setShowFromTimePicker] = useState(false);
  const [showToTimePicker, setShowToTimePicker] = useState(false);

  const dispatch = useDispatch();
  const {from, to} = useSelector(selectWorkingTime);
  const navigation = useNavigation();
  const theme = useSelector(selectTheme);

  // WHEN FROM TIME CHANGE
  const fromTimeChange = (event: any, selectedTime: any) => {
    dispatch(setFromTime(selectedTime.getTime()));
    setShowFromTimePicker(false);
  };

  // FROM TIME (HOURS) -- CHANGING TIME FORMAT 24hrs TO 12hrs
  useEffect(() => {
    dispatch(updateWorkingFromHours());
    setShowFromTimePicker(false);
  }, [from.hours, dispatch]);

  // TO TIME (HOURS) -- CHANGING TIME FORMAT 24hrs TO 12hrs
  useEffect(() => {
    dispatch(updateWorkingToHours());
    setShowToTimePicker(false);
  }, [to.hours, dispatch]);

  // WHEN TO TIME CHANGE
  const toTimeChange = (event: any, selectedTime: any) => {
    dispatch(setToTime(selectedTime.getTime()));
    setShowToTimePicker(false);
  };
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
      paddingHorizontal: 23,
      paddingTop: responsiveHeight(7),
    },
    back_container: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    text: {
      textAlign: 'center',
      fontSize: RFPercentage(2),
      bottom: 20,
      fontFamily: FONTFAMILY.BLACK,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      marginTop: -13,
    },
    progress_outer: {
      marginTop: 10,
      height: responsiveHeight(1),
      borderRadius: 10,
      backgroundColor: theme.dark ? COLORS.LIGHT_BLACK : COLORS.LIGHT_GREY,
    },
    progress_inner: {
      position: 'absolute',
      backgroundColor: COLORS.LIGHT_BLUE,
      width: '85.2%',
      height: responsiveHeight(1),
      borderRadius: 10,
    },
    heading: {
      fontSize: RFPercentage(2.8),
      fontFamily: FONTFAMILY.BLACK,
      marginTop: 40,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    sub_heading: {
      fontSize: RFPercentage(1.5),
      marginTop: 10,
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.MEDIUM_GREY : COLORS.LIGHT_BLACK,
    },
    input_container: {
      marginTop: '8.5%',
    },
    input_style: {
      borderRadius: 10,
      borderColor: COLORS.LIGHT_BLUE,
      borderWidth: 1,
      paddingLeft: 16,
      fontSize: RFPercentage(1.8),
      height: responsiveHeight(5.9),
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    email_text: {
      marginBottom: 10,
      fontSize: RFPercentage(1.8),
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    parent_input_container: {
      height: responsiveHeight(64),
    },
    input_icon_con: {},
    icon_style: {
      position: 'absolute',
      right: 20,
      top: 14,
    },
    dateTimePicker: {
      backgroundColor: 'white',
      borderRadius: 5,
      borderColor: '#C5C5C5',
      borderWidth: 1,
      marginVertical: 10,
      height: 43,
    },

    input_img_style: {
      aspectRatio: 1,
      resizeMode: 'contain',
      height: responsiveHeight(2.7),
      width: responsiveWidth(2.7),
    },
    back_img: {
      aspectRatio: 1,
      resizeMode: 'cover',
      width: responsiveHeight(2),
      height: responsiveHeight(3.2),
    },
  });
  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={{
          position: 'absolute',
          top: 0,
          marginTop: responsiveHeight(1.6),
          padding: 10,
          left: 10,
          width: '15%',
          zIndex: 999,
        }}
        onPress={() => {
          setStep(step - 1);
        }}>
        <Image
          source={theme.dark ? arrowLeftDark : arrowLeft}
          style={styles.back_img}
        />
      </TouchableOpacity>
      <Text style={styles.text}>Create an Account</Text>

      <View style={styles.progress_outer}>
        <View style={styles.progress_inner}></View>
      </View>
      <View style={{height: responsiveHeight(13)}}>
        <Text style={styles.heading}>Setup your Working Hours.</Text>
        <Text style={styles.sub_heading}>Setup your working hours</Text>
      </View>

      <View style={styles.parent_input_container}>
        <View style={styles.input_container}>
          <Text style={styles.email_text}>From</Text>
          <View style={styles.input_icon_con}>
            <TouchableOpacity
              activeOpacity={0.6}
              onPress={() => {
                setShowFromTimePicker(true);
              }}>
              <TextInput
                placeholderTextColor={COLORS.DARK_GREY}
                style={styles.input_style}
                value={`${from.hours < 10 ? '0' + from.hours : from.hours}:${
                  from.minutes < 10 ? '0' + from.minutes : from.minutes
                } ${from.amPm}`}
                editable={false}
              />

              <View style={styles.icon_style}>
                <Image
                  source={theme.dark ? clockDark : clock}
                  style={styles.input_img_style}
                />
              </View>
            </TouchableOpacity>
          </View>
        </View>
        <View style={styles.input_container}>
          <Text style={styles.email_text}>To</Text>
          <View style={styles.input_icon_con}>
            <TouchableOpacity
              activeOpacity={0.6}
              onPress={() => {
                setShowToTimePicker(true);
              }}>
              <TextInput
                placeholderTextColor={COLORS.DARK_GREY}
                style={styles.input_style}
                value={`${to.hours < 10 ? '0' + to.hours : to.hours}:${
                  to.minutes < 10 ? '0' + to.minutes : to.minutes
                } ${to.amPm}`}
                editable={false}
              />

              <View style={styles.icon_style}>
                <Image
                  source={theme.dark ? clockDark : clock}
                  style={styles.input_img_style}
                />
              </View>
            </TouchableOpacity>
          </View>
        </View>
      </View>
      <Button
        _onPress={() => {
          Alert.alert('Success');
        }}
        _text={'Continue'}
        _bgColor={COLORS.LIGHT_BLUE}
        _fontSize={FONTSIZE.FONT_SIZE_16}
        _color={COLORS.WHITE}
        _bColor={'transparent'}
      />
      {showFromTimePicker && (
        <DateTimePicker
          mode="time"
          value={new Date(from.time)}
          is24Hour={false}
          onChange={fromTimeChange}
          style={styles.dateTimePicker}
        />
      )}

      {showToTimePicker && (
        <DateTimePicker
          style={{backgroundColor: 'red'}}
          mode="time"
          value={new Date(to.time)}
          is24Hour={false}
          onChange={toTimeChange}
          minimumDate={new Date(`2023-12-31T23:59:59`)}
        />
      )}
    </View>
  );
};

export default WorkingHours;
