import {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  TextInput,
  Pressable,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {COLORS, FONTFAMILY, FONTSIZE} from '../../theme/Theme';
import {RFPercentage} from 'react-native-responsive-fontsize';
import {
  eyeOpen,
  eyeClose,
  arrowLeft,
  arrowLeftDark,
  eyeOpenDark,
  eyeCloseDark,
} from '../../assets/images/Index';
import {
  responsiveHeight,
  responsiveWidth,
} from 'react-native-responsive-dimensions';
import Button from '../../components/Button';
import {useDispatch, useSelector} from 'react-redux';
import {
  selectCreateAccount,
  setPass,
  setCPass,
} from '../../redux/slices/create_account_slice/CreateAccountSlices';
import {selectTheme} from '../../redux/slices/ThemeSlice';

const CreatePassword = ({
  step,
  setStep,
}: {
  step: number;
  setStep: React.Dispatch<React.SetStateAction<number>>;
}) => {
  const [isFirstEyeOpen, setIsFirstEyeOpen] = useState(true);
  const [isSecondEyeOpen, setIsSecondEyeOpen] = useState(true);
  const [passMessage, setPassMessage] = useState('');
  const [cPassMessage, setCPassMessage] = useState('');
  const dispatch = useDispatch();
  const createAccount = useSelector(selectCreateAccount);
  const theme = useSelector(selectTheme);

  // VALIDATE PASSWORDS INPUT CORRECT OR NOT
  const validateCreatePass = () => {
    if (createAccount.pass === '') {
      setPassMessage('Please enter password');
      setCPassMessage('');
    } else if (createAccount.pass.length <= 7) {
      setPassMessage('Please enter atleast 8 characters');
      setCPassMessage('');
    } else if (createAccount.cPass === '') {
      setCPassMessage('Please enter confirm password');
      setPassMessage('');
    } else if (createAccount.cPass === '' && createAccount.pass.length > 7) {
      setCPassMessage('Please enter confirm password');
      setPassMessage('');
    } else if (
      createAccount.pass !== createAccount.cPass &&
      createAccount.pass !== '' &&
      createAccount.cPass !== ''
    ) {
      setCPassMessage('Password and Confirm Password must be same');
      setPassMessage('');
    } else {
      setPassMessage('');
      setCPassMessage('');
      setStep(step + 1);
    }
  };

  // HANDLE PASSWORD INPUT
  const handlePass = (value: string) => {
    // const formattedText = value.slice(0, 11);
    dispatch(setPass(value.slice(0, 12)));
  };

  // HANDLE CONFIRM PASSWORD INPUT
  const handleCPass = (value: string) => {
    const formattedText = value.slice(0, 12);
    dispatch(setCPass(formattedText));
  };

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
      paddingHorizontal: 23,
      paddingTop: responsiveHeight(7),
    },
    back_container: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    text: {
      textAlign: 'center',
      fontSize: RFPercentage(2),
      bottom: 20,
      fontFamily: FONTFAMILY.BLACK,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      marginTop: -13,
    },
    progress_outer: {
      marginTop: 10,
      height: responsiveHeight(1),
      borderRadius: 10,
      backgroundColor: COLORS.LIGHT_GREY,
    },
    progress_inner: {
      position: 'absolute',
      backgroundColor: COLORS.LIGHT_BLUE,
      width: '42.6%',
      height: responsiveHeight(1),
      borderRadius: 10,
    },
    heading: {
      fontSize: RFPercentage(2.8),
      fontFamily: FONTFAMILY.BLACK,
      marginTop: 40,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    sub_heading: {
      fontSize: RFPercentage(1.8),
      marginTop: 10,
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.MEDIUM_GREY : COLORS.LIGHT_BLACK,
    },
    input_container: {
      marginTop: '8.5%',
    },
    input_container2: {
      marginTop: '7%',
    },
    input_style: {
      borderRadius: 10,
      borderColor: COLORS.LIGHT_BLUE,
      borderWidth: 1,
      paddingLeft: responsiveHeight(2),
      fontSize: RFPercentage(1.8),
      height: responsiveHeight(5.8),
      fontFamily: FONTFAMILY.REGULAR,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    email_text: {
      marginBottom: 10,
      fontSize: RFPercentage(1.8),
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    parent_input_container: {
      height: responsiveHeight(64.2),
    },
    input_icon_con: {},
    icon_style: {
      position: 'absolute',
      right: 20,
      top: 14,
    },
    input_img_style: {
      aspectRatio: 1,
      resizeMode: 'contain',
      height: responsiveHeight(2.7),
      width: responsiveWidth(2.7),
    },
    valid_msg: {
      fontFamily: FONTFAMILY.MEDIUM,
      color: COLORS.RED,
      marginTop: '1%',
      fontSize: RFPercentage(1.8),
    },
    back_img: {
      aspectRatio: 1,
      resizeMode: 'cover',
      width: responsiveHeight(2),
      height: responsiveHeight(3.2),
    },
  });

  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={{
          position: 'absolute',
          top: 0,
          marginTop: responsiveHeight(1.6),
          padding: 10,
          left: 10,
          width: '15%',
          zIndex: 999,
        }}
        onPress={() => {
          setStep(step - 1);
        }}>
        <Image
          source={theme.dark ? arrowLeftDark : arrowLeft}
          style={styles.back_img}
        />
      </TouchableOpacity>
      <Text style={styles.text}>Create an Account</Text>

      <View style={styles.progress_outer}>
        <View style={styles.progress_inner}></View>
      </View>
      <View style={{height: responsiveHeight(13)}}>
        <Text style={styles.heading}>Create a Password</Text>
        <Text style={styles.sub_heading}>
          We recommend you to use a strong password.
        </Text>
      </View>

      <View style={styles.parent_input_container}>
        <View style={styles.input_container}>
          <Text style={styles.email_text}>Password</Text>
          <View style={styles.input_icon_con}>
            <TextInput
              placeholderTextColor={COLORS.DARK_GREY}
              style={styles.input_style}
              placeholder="Enter Password"
              secureTextEntry={isFirstEyeOpen ? true : false}
              value={createAccount.pass}
              onChangeText={value => {
                // dispatch(setPass(value));
                handlePass(value);
              }}
            />
            <TouchableOpacity
              activeOpacity={0.7}
              style={styles.icon_style}
              onPress={() => {
                setIsFirstEyeOpen(!isFirstEyeOpen);
              }}>
              <Image
                source={
                  isFirstEyeOpen && theme.dark
                    ? eyeOpenDark
                    : !isFirstEyeOpen && !theme.dark
                    ? eyeClose
                    : isFirstEyeOpen && !theme.dark
                    ? eyeOpen
                    : theme.dark && !isFirstEyeOpen
                    ? eyeCloseDark
                    : ''
                }
                style={styles.input_img_style}
              />
            </TouchableOpacity>
            <Text style={[styles.valid_msg]}>{passMessage}</Text>
          </View>
        </View>
        <View style={styles.input_container2}>
          <Text style={styles.email_text}>Confirm Password</Text>
          <View style={styles.input_icon_con}>
            <TextInput
              placeholderTextColor={COLORS.DARK_GREY}
              style={styles.input_style}
              secureTextEntry={isSecondEyeOpen ? true : false}
              placeholder="Enter Confirm Password"
              value={createAccount.cPass}
              onChangeText={value => {
                handleCPass(value);
              }}
            />
            <TouchableOpacity
              activeOpacity={0.7}
              style={styles.icon_style}
              onPress={() => {
                setIsSecondEyeOpen(!isSecondEyeOpen);
              }}>
              <Image
                source={
                  isSecondEyeOpen && theme.dark
                    ? eyeOpenDark
                    : !isSecondEyeOpen && !theme.dark
                    ? eyeClose
                    : isSecondEyeOpen && !theme.dark
                    ? eyeOpen
                    : theme.dark && !isSecondEyeOpen
                    ? eyeCloseDark
                    : ''
                }
                style={styles.input_img_style}
              />
            </TouchableOpacity>
            <Text style={[styles.valid_msg]}>{cPassMessage}</Text>
          </View>
        </View>
      </View>
      <Button
        _onPress={() => {
          validateCreatePass();
        }}
        _text={'Continue'}
        _bgColor={COLORS.LIGHT_BLUE}
        _fontSize={FONTSIZE.FONT_SIZE_16}
        _color={COLORS.WHITE}
        _bColor={'transparent'}
      />
    </View>
  );
};

export default CreatePassword;
