import {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  Pressable,
  TextInput,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {COLORS, FONTFAMILY, FONTSIZE} from '../../theme/Theme';
import {RFPercentage} from 'react-native-responsive-fontsize';
import {responsiveHeight} from 'react-native-responsive-dimensions';
import {useNavigation} from '@react-navigation/native';
import Button from '../../components/Button';
import {arrowLeft, arrowLeftDark} from '../../assets/images/Index';
import Input from '../../components/Input';
import Toast from 'react-native-toast-message';

import {useDispatch, useSelector} from 'react-redux';
import {
  selectCreateAccount,
  setEmail,
} from '../../redux/slices/create_account_slice/CreateAccountSlices';

import {selectTheme} from '../../redux/slices/ThemeSlice';

const CreateEmailAddress = ({
  step,
  setStep,
}: {
  step: number;
  setStep: React.Dispatch<React.SetStateAction<number>>;
}) => {
  const dispatch = useDispatch();
  const createAccount = useSelector(selectCreateAccount);
  const navigation = useNavigation();
  const [message, setMessage] = useState('');
  const theme = useSelector(selectTheme);

  // VALIDATE EMAIL CORRECT OR NOT
  const validateEmail = () => {
    const emailRegex = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}$/;
    if (emailRegex.test(createAccount.email)) {
      setMessage('');
      setStep(step + 1);
    } else if (createAccount.email == '') {
      setMessage('Please enter email');
    } else {
      setMessage('Please enter valid email');
    }
  };

  const handleEmail = (value: string) => {
    let formattedText = value.replace(/\s+/g, '');
    dispatch(setEmail(formattedText));
  };

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
      paddingHorizontal: 23,
      paddingTop: responsiveHeight(7),
    },
    text: {
      textAlign: 'center',
      fontSize: RFPercentage(2),
      bottom: 20,
      fontFamily: FONTFAMILY.BLACK,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      marginTop: -13,
    },
    progress_outer: {
      marginTop: 10,
      height: responsiveHeight(1),
      borderRadius: 10,
      backgroundColor: theme.dark ? COLORS.LIGHT_BLACK : COLORS.LIGHT_GREY,
    },
    progress_inner: {
      position: 'absolute',
      backgroundColor: COLORS.LIGHT_BLUE,
      width: '14.2%',
      height: responsiveHeight(1),
      borderRadius: 10,
    },
    heading: {
      fontSize: RFPercentage(2.8),
      fontFamily: FONTFAMILY.BLACK,
      marginTop: 40,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    sub_heading: {
      fontSize: RFPercentage(1.5),
      marginTop: 10,
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.MEDIUM_GREY : COLORS.LIGHT_BLACK,
    },
    input_container: {
      height: responsiveHeight(54),
    },
    input_style: {
      borderRadius: 10,
      borderColor: COLORS.LIGHT_BLUE,
      borderWidth: 1,
      paddingLeft: 20,
      fontSize: RFPercentage(1.7),
      paddingVertical: 9,
      fontFamily: FONTFAMILY.REGULAR,
    },
    email_text: {
      marginBottom: 10,
      fontSize: RFPercentage(1.8),
      fontFamily: FONTFAMILY.BOLD,
      color: COLORS.BLACK,
    },
    small_text: {
      textAlign: 'center',
      marginTop: 14,
      fontSize: RFPercentage(1.5),
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    link_text: {
      color: COLORS.LIGHT_BLUE,
      fontFamily: FONTFAMILY.BOLD,
      textDecorationLine: 'underline',
      fontSize: RFPercentage(1.4),
    },
    valid_msg: {
      fontFamily: FONTFAMILY.MEDIUM,
      color: COLORS.RED,
      marginLeft: '2%',
      marginTop: '11%',
      fontSize: RFPercentage(1.8),
    },
    back_img: {
      aspectRatio: 1,
      resizeMode: 'cover',
      width: responsiveHeight(2),
      height: responsiveHeight(3.2),
    },
  });

  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={{
          position: 'absolute',
          top: 0,
          marginTop: responsiveHeight(1.6),
          padding: 10,
          left: 10,
          width: '15%',
          zIndex: 999,
        }}
        onPress={() => {
          navigation.goBack();
        }}>
        <Image
          source={theme.dark ? arrowLeftDark : arrowLeft}
          style={styles.back_img}
        />
      </TouchableOpacity>
      <Text style={styles.text}>Create an Account</Text>

      <View style={styles.progress_outer}>
        <View style={styles.progress_inner}></View>
      </View>
      <View style={{height: responsiveHeight(13)}}>
        <Text style={styles.heading}>What is your Email Address?</Text>
        <Text style={styles.sub_heading}>
          We need your email address to register you on Dillydally Calendar.
        </Text>
      </View>

      <Input
        _lable={'Email Address'}
        _bColor={COLORS.LIGHT_BLUE}
        _placeHolder="Enter Email"
        _bRadius={10}
        _height={responsiveHeight(5.8)}
        _value={createAccount.email}
        _onChange={(value: string) => {
          // dispatch(setEmail(value));
          handleEmail(value);
        }}
        _maxLength={undefined}
      />

      <View style={{height: responsiveHeight(52.5)}}>
        <Text style={styles.valid_msg}>{message}</Text>
      </View>
      <Button
        _onPress={() => {
          validateEmail();
        }}
        _text={'Continue'}
        _bgColor={COLORS.LIGHT_BLUE}
        _fontSize={FONTSIZE.FONT_SIZE_16}
        _color={COLORS.WHITE}
        _bColor={'transparent'}
      />
      <Text
        style={styles.small_text}
        onPress={() => {
          navigation.navigate('LOGIN');
        }}>
        Already have an account? <Text style={styles.link_text}>Login</Text>
      </Text>
    </View>
  );
};

export {CreateEmailAddress};
