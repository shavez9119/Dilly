import {
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  PermissionsAndroid,
  Platform,
  Linking,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import Button from '../../components/Button';
import {COLORS, FONTFAMILY, FONTSIZE} from '../../theme/Theme';
import {
  responsiveHeight,
  responsiveWidth,
} from 'react-native-responsive-dimensions';
import {
  arrowLeft,
  profile,
  edit,
  placeHolder,
  closeBig,
  arrowLeftDark,
} from '../../assets/images/Index';
import {RFPercentage} from 'react-native-responsive-fontsize';
import Input from '../../components/Input';
import {
  selectCreateAccount,
  setFName,
  setLName,
  setCPassEmpty,
  setPassEmpty,
  sanitizedFName,
  sanitizedLName,
  setProfile,
} from '../../redux/slices/create_account_slice/CreateAccountSlices';

import {useSelector, useDispatch} from 'react-redux';
import ImagePicker from 'react-native-image-crop-picker';

import {request, PERMISSIONS} from 'react-native-permissions';
import {selectTheme} from '../../redux/slices/ThemeSlice';

const SetupProfile = ({
  step,
  setStep,
}: {
  step: number;
  setStep: React.Dispatch<React.SetStateAction<number>>;
}) => {
  const dispatch = useDispatch();
  const createAccount = useSelector(selectCreateAccount);
  const [fNameMessage, setFNameMessage] = useState('');
  const [lNameMessage, setLNameMessage] = useState('');
  const [isChoosPicOpen, setIsChoosPicOpen] = useState(false);
  const [imageUri, setImageUri] = useState('');
  const theme = useSelector(selectTheme);

  // VALIDATE NAMES INPUT : EMPTY OR NOT
  const validateProfile = () => {
    if (createAccount.fName == '') {
      setFNameMessage('Please enter First Name');
    } else if (createAccount.lName == '') {
      setLNameMessage('Please enter Last Name');
      setFNameMessage('');
    } else {
      setFNameMessage('');
      setLNameMessage('');
      setStep(step + 1);
    }
  };

  const pickImageFromGallery = async () => {
    try {
      const image = await ImagePicker.openPicker({
        width: 300,
        height: 400,
        cropping: true,
      });
      // setImageUri(image.path);
      dispatch(setProfile(image.path));
      setIsChoosPicOpen(false);
    } catch (error) {
      console.log(error);
    }
  };

  const pickImageFromCamera = async () => {
    try {
      const cameraPermission = await requestCameraPermission();

      if (cameraPermission === 'granted') {
        const image = await ImagePicker.openCamera({
          width: 300,
          height: 400,
          cropping: true,
        });
        // setImageUri(image.path);
        dispatch(setProfile(image.path));
        setIsChoosPicOpen(false);
      } else {
        console.log('Camera permission denied');
      }
    } catch (error) {
      console.log(error);
    }
  };
  const requestCameraPermission = async () => {
    try {
      const cameraPermission = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.CAMERA,
      );

      console.log('Camera Permission Status (Android):', cameraPermission);

      return cameraPermission;
    } catch (error) {
      console.log('Error requesting camera permission:', error);
      return 'denied';
    }
  };
  const handleFName = (value: string) => {
    const formattedText = value.replace(/[^a-zA-Z\s]/g, '').slice(0, 8);

    // Ensure exactly one space
    const oneSpaceText = formattedText.replace(/\s+/g, ' ');

    // Dispatch the result
    dispatch(setFName(oneSpaceText));
  };
  const handleLName = (value: string) => {
    const formattedText = value.replace(/[^a-zA-Z\s]/g, '').slice(0, 15);

    // Ensure exactly one space
    const oneSpaceText = formattedText.replace(/\s+/g, ' ');

    // Dispatch the result
    dispatch(setLName(oneSpaceText));
  };

  // RESTRICT USER FROM ENTERING SPECIAL CHARACTERS
  useEffect(() => {
    dispatch(sanitizedFName(createAccount.fName));
    dispatch(sanitizedLName(createAccount.lName));
  }, [createAccount.fName, createAccount.lName]);

  useEffect(() => {
    if (createAccount.fName == ' ') {
      dispatch(setFName(''));
    }
  }, [createAccount.fName]);
  useEffect(() => {
    if (createAccount.lName == ' ') {
      dispatch(setLName(''));
    }
  }, [createAccount.lName]);

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
      paddingHorizontal: 23,
      // paddingTop: responsiveHeight(7),
    },
    text: {
      textAlign: 'center',
      fontSize: RFPercentage(2),
      bottom: 20,
      fontFamily: FONTFAMILY.BLACK,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      marginTop: -13,
    },
    img_edit_img_con: {
      position: 'relative',
    },
    progress_outer: {
      marginTop: 10,
      height: responsiveHeight(1),
      borderRadius: 10,
      backgroundColor: theme.dark ? COLORS.LIGHT_BLACK : COLORS.LIGHT_GREY,
    },
    progress_inner: {
      position: 'absolute',
      backgroundColor: COLORS.LIGHT_BLUE,
      width: '56.8%',
      height: responsiveHeight(1),
      borderRadius: 10,
    },
    parent_input_container: {
      height: responsiveHeight(49),
    },
    heading: {
      fontSize: RFPercentage(2.8),
      fontFamily: FONTFAMILY.BLACK,
      marginTop: 40,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    sub_heading: {
      fontSize: RFPercentage(1.5),
      marginTop: 10,
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.MEDIUM_GREY : COLORS.LIGHT_BLACK,
    },
    profile_pic_con: {
      height: responsiveHeight(15),
      justifyContent: 'center',
      alignItems: 'center',
    },
    edit_img_con: {
      backgroundColor: COLORS.LIGHT_BLUE,
      height: responsiveWidth(8),
      width: responsiveWidth(8),
      borderColor: COLORS.WHITE,
      borderWidth: 1,
      borderRadius: 50,
      alignItems: 'center',
      justifyContent: 'center',
      position: 'absolute',
      bottom: 2,
      right: 0,
    },
    profile_img_style: {
      aspectRatio: 1,
      resizeMode: 'contain',
      height: responsiveHeight(11),
      width: responsiveWidth(11),
      borderRadius: responsiveWidth(20),
    },
    pecil_img_style: {
      resizeMode: 'contain',
      height: responsiveHeight(3),
      width: responsiveWidth(4),
    },
    valid_msg: {
      fontFamily: FONTFAMILY.MEDIUM,
      color: COLORS.RED,
      top: '8%',
      fontSize: RFPercentage(1.8),
    },
    add_start_time_con: {
      position: 'absolute',
      backgroundColor: 'rgba(0,0,0,0.7)',
      height: responsiveHeight(100),
      width: responsiveWidth(100),
      justifyContent: 'center',
      alignItems: 'center',
    },
    pop_container: {
      width: responsiveWidth(90),
      padding: responsiveHeight(2.7),
      backgroundColor: COLORS.WHITE,
      borderRadius: responsiveHeight(1),
    },
    container_p: {
      backgroundColor: COLORS.RED,
      borderRadius: responsiveHeight(1),
    },
    close_icon_big: {
      aspectRatio: 1,
      height: responsiveHeight(3.2),
      width: responsiveWidth(7),
      position: 'absolute',
      right: responsiveHeight(-1),
      top: responsiveHeight(-9),
      // padding: responsiveHeight(1),
    },
    pop_title_text: {
      fontFamily: FONTFAMILY.BLACK,
      fontSize: RFPercentage(2.9),
      color: COLORS.BLACK,
      textAlign: 'center',
      // backgroundColor: 'red',
      width: '100%',
      // zIndex: -23,
      marginBottom: '10%',
    },
    back_img: {
      aspectRatio: 1,
      resizeMode: 'cover',
      width: responsiveHeight(2),
      height: responsiveHeight(3.2),
    },
  });
  return (
    <>
      <View style={styles.container}>
        <ScrollView showsVerticalScrollIndicator={false}>
          <TouchableOpacity
            style={{
              position: 'relative',
              top: 0,
              marginTop: responsiveHeight(1.6),
              paddingVertical: 10,
              width: '15%',
              zIndex: 999,
            }}
            onPress={() => {
              setStep(step - 1);
            }}>
            <Image
              source={theme.dark ? arrowLeftDark : arrowLeft}
              style={styles.back_img}
            />
          </TouchableOpacity>
          <Text style={styles.text}>Create an Account</Text>

          <View style={styles.progress_outer}>
            <View style={styles.progress_inner}></View>
          </View>
          <View style={{height: responsiveHeight(13)}}>
            <Text
              style={styles.heading}
              onPress={() => {
                // pickImageFromCamera();
              }}>
              Setup your Profile
            </Text>
            <Text style={styles.sub_heading}>
              You’re almost done! Let’s setup your account.
            </Text>
          </View>
          <View style={styles.profile_pic_con}>
            <View style={styles.img_edit_img_con}>
              <TouchableOpacity
                activeOpacity={0.7}
                style={{}}
                onPress={() => {
                  // pickImageFromGallery();
                  setIsChoosPicOpen(true);
                }}>
                {createAccount.profile == '' ? (
                  <Image
                    source={placeHolder}
                    style={styles.profile_img_style}
                  />
                ) : (
                  <Image
                    source={{uri: createAccount.profile}}
                    style={styles.profile_img_style}
                  />
                )}
              </TouchableOpacity>
              <TouchableOpacity
                activeOpacity={0.7}
                style={styles.edit_img_con}
                onPress={() => {
                  // pickImageFromGallery();
                  setIsChoosPicOpen(true);
                }}>
                <Image source={edit} style={styles.pecil_img_style} />
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.parent_input_container}>
            <Input
              _editable={undefined}
              _lable={'First Name'}
              _bColor={COLORS.LIGHT_BLUE}
              _placeHolder="First Name"
              _bRadius={10}
              _height={responsiveHeight(5.8)}
              _value={createAccount.fName}
              _onChange={(value: string) => {
                handleFName(value);
              }}
            />
            <Text style={styles.valid_msg}>{fNameMessage}</Text>
            <View style={{marginTop: '3%'}}>
              <Input
                _editable={undefined}
                _lable={'Last Name'}
                _bColor={COLORS.LIGHT_BLUE}
                _placeHolder="Last Name"
                _bRadius={10}
                _height={responsiveHeight(5.8)}
                _value={createAccount.lName}
                _onChange={(value: string) => {
                  handleLName(value);
                }}
              />
            </View>
            <Text style={styles.valid_msg}>{lNameMessage}</Text>
          </View>
          <Button
            _onPress={() => {
              validateProfile();
            }}
            _text={'Continue'}
            _bgColor={COLORS.LIGHT_BLUE}
            _fontSize={FONTSIZE.FONT_SIZE_16}
            _color={COLORS.WHITE}
            _bColor={'transparent'}
          />
        </ScrollView>
      </View>

      {isChoosPicOpen && (
        <Pressable
          style={styles.add_start_time_con}
          onPress={() => {
            setIsChoosPicOpen(false);
          }}>
          <View style={styles.container_p}>
            <Pressable
              style={styles.pop_container}
              onPress={() => {
                setIsChoosPicOpen(true);
              }}>
              <Text style={styles.pop_title_text}>Choose Source</Text>
              <TouchableOpacity
                activeOpacity={0.7}
                onPress={() => {
                  //  setIsAddStartTimeOpen(!isAddStartTimeOpen);
                  setIsChoosPicOpen(false);
                }}>
                <Image source={closeBig} style={styles.close_icon_big} />
              </TouchableOpacity>
              <Button
                _onPress={() => {
                  // addStartTimeData();
                  // setIsAddStartTimeOpen(false);
                  pickImageFromCamera();
                }}
                _text={'Camera'}
                _bgColor={COLORS.LIGHT_BLUE}
                _fontSize={FONTSIZE.FONT_SIZE_16}
                _color={COLORS.WHITE}
                _bColor={'transparent'}
              />
              <View style={{marginVertical: '2%'}}></View>
              <Button
                _onPress={() => {
                  // addStartTimeData();
                  // setIsAddStartTimeOpen(false);
                  pickImageFromGallery();
                }}
                _text={'Gallery'}
                _bgColor={COLORS.DARK_BLUE}
                _fontSize={FONTSIZE.FONT_SIZE_16}
                _color={COLORS.WHITE}
                _bColor={'transparent'}
              />
            </Pressable>
          </View>
        </Pressable>
      )}
    </>
  );
};

export default SetupProfile;
