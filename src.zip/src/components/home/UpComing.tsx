import {
  Image,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React from 'react';
import {
  caretDownBig,
  caretUpBig,
  moreVertical,
  rectangleEmpty,
  redFleg,
  smallEllips,
} from '../../assets/images/Index';
import {
  responsiveHeight,
  responsiveWidth,
} from 'react-native-responsive-dimensions';
import {COLORS, FONTFAMILY} from '../../theme/Theme';
import {RFPercentage} from 'react-native-responsive-fontsize';

const UpComing = ({
  isUpcomingOpen,
  setIsUpcomingOpen,
}: {
  isUpcomingOpen: boolean;
  setIsUpcomingOpen: React.Dispatch<React.SetStateAction<boolean>>;
}) => {
  return (
    <View>
      <TouchableOpacity
        activeOpacity={1}
        style={[
          isUpcomingOpen ? styles.upper_section : styles.upper_section_radius,
        ]}
        onPress={() => {
          setIsUpcomingOpen(!isUpcomingOpen);
        }}>
        <>
          <View style={styles.flex}>
            <View style={styles.title_circle}>
              <Text style={styles.task_type_text}>Upcoming Tasks</Text>
              <View style={styles.circle}>
                <Text style={styles.task_counter_text}>5</Text>
              </View>
            </View>
            <View>
              <Image
                style={styles.caret_img_style}
                source={isUpcomingOpen ? caretUpBig : caretDownBig}
              />
            </View>
          </View>
          <Text style={styles.small_text}>
            Here you can see your upcoming tasks for the day.
          </Text>
        </>
      </TouchableOpacity>
      {isUpcomingOpen && (
        <View style={styles.bottom_section}>
          <View
            style={{
              paddingTop: responsiveHeight(2),
            }}>
            <View style={styles.flex}>
              <View style={styles.flex_gap}>
                <Image source={rectangleEmpty} style={styles.rectangle_img} />
                <Text style={styles.task_name_text}>User Flow - Project X</Text>
                <Text style={styles.priority_text}>High</Text>
              </View>
              <View>
                <Image style={styles.more_vertical_img} source={moreVertical} />
              </View>
            </View>
            <View style={styles.flex_row}>
              <Image source={redFleg} style={styles.red_flag_img} />
              <Text style={styles.another_text}>9 - 10 AM</Text>
              <Image source={smallEllips} style={styles.small_elips_img} />
              <Text style={styles.another_text}>Personal</Text>
            </View>
          </View>
          <View
            style={{
              paddingTop: responsiveHeight(2),
            }}>
            <View style={styles.flex}>
              <View style={styles.flex_gap}>
                <Image source={rectangleEmpty} style={styles.rectangle_img} />
                <Text style={styles.task_name_text}>User Flow - Project X</Text>
                <Text style={styles.priority_text}>High</Text>
              </View>
              <View>
                <Image style={styles.more_vertical_img} source={moreVertical} />
              </View>
            </View>
            <View style={styles.flex_row}>
              <Image source={redFleg} style={styles.red_flag_img} />
              <Text style={styles.another_text}>9 - 10 AM</Text>
              <Image source={smallEllips} style={styles.small_elips_img} />
              <Text style={styles.another_text}>Personal</Text>
            </View>
          </View>
          <View
            style={{
              paddingTop: responsiveHeight(2),
            }}>
            <View style={styles.flex}>
              <View style={styles.flex_gap}>
                <Image source={rectangleEmpty} style={styles.rectangle_img} />
                <Text style={styles.task_name_text}>User Flow - Project X</Text>
                <Text style={styles.priority_text}>High</Text>
              </View>
              <View>
                <Image style={styles.more_vertical_img} source={moreVertical} />
              </View>
            </View>
            <View style={styles.flex_row}>
              <Image source={redFleg} style={styles.red_flag_img} />
              <Text style={styles.another_text}>9 - 10 AM</Text>
              <Image source={smallEllips} style={styles.small_elips_img} />
              <Text style={styles.another_text}>Personal</Text>
            </View>
          </View>
        </View>
      )}
    </View>
  );
};

export default UpComing;

const styles = StyleSheet.create({
  upper_section: {
    borderTopRightRadius: responsiveHeight(2.4),
    borderTopLeftRadius: responsiveHeight(2.4),
    height: responsiveHeight(11),
    marginTop: '2%',
    padding: responsiveHeight(2),

    ...Platform.select({
      ios: {
        shadowColor: 'black',
        shadowOffset: {width: 0, height: -2},
        shadowOpacity: 0.2,
        shadowRadius: 4,
      },
      android: {
        elevation: 2,
        shadowColor: COLORS.DARK_GREY,
      },
    }),
  },
  upper_section_radius: {
    borderRadius: responsiveHeight(2.4),
    height: responsiveHeight(13),
    marginTop: '2%',
    padding: responsiveHeight(2.4),
    ...Platform.select({
      ios: {
        shadowColor: 'black',
        shadowOffset: {width: 0, height: -2},
        shadowOpacity: 0.2,
        shadowRadius: 4,
      },
      android: {
        elevation: 2,
        shadowColor: COLORS.DARK_GREY,
      },
    }),
  },
  flex: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  task_type_text: {
    fontSize: RFPercentage(2),
    fontFamily: FONTFAMILY.BOLD,
    color: COLORS.BLACK,
  },
  title_circle: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: responsiveHeight(1.5),
  },
  circle: {
    height: responsiveHeight(3.2),
    width: responsiveHeight(3.2),
    borderRadius: responsiveHeight(2),
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.LIGHT_BLUE,
  },
  task_counter_text: {
    fontFamily: FONTFAMILY.BLACK,
    color: COLORS.WHITE,
  },
  caret_img_style: {
    aspectRatio: 1,
    resizeMode: 'contain',
    height: responsiveHeight(3.5),
  },
  small_text: {
    marginTop: '2%',
    fontSize: RFPercentage(1.5),
    fontFamily: FONTFAMILY.MEDIUM,
    color: COLORS.DARK_GREY,
  },
  bottom_section: {
    borderBottomRightRadius: responsiveHeight(2.4),
    borderBottomLeftRadius: responsiveHeight(2.4),
    paddingHorizontal: responsiveHeight(2),
    paddingBottom: responsiveHeight(2),
    ...Platform.select({
      ios: {
        shadowColor: 'black',
        shadowOffset: {width: 0, height: -2},
        shadowOpacity: 0.2,
        shadowRadius: 4,
      },
      android: {
        elevation: 2,
        shadowColor: COLORS.DARK_GREY,
      },
    }),
  },
  flex_gap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: responsiveWidth(3.5),
  },
  rectangle_img: {
    aspectRatio: 1,
    resizeMode: 'contain',
    height: responsiveHeight(2),
    width: responsiveWidth(6.5),
  },
  task_name_text: {
    fontFamily: FONTFAMILY.BLACK,
    fontSize: RFPercentage(1.8),
    color: COLORS.BLACK,
  },
  priority_text: {
    backgroundColor: COLORS.SKY_BLUE_LIGHT,
    color: COLORS.LIGHT_BLUE,
    paddingHorizontal: responsiveHeight(1.5),
    paddingVertical: responsiveHeight(0.6),
    borderRadius: responsiveHeight(0.5),
    fontFamily: FONTFAMILY.MEDIUM,
    fontSize: RFPercentage(1.4),
  },
  more_vertical_img: {
    aspectRatio: 1,
    resizeMode: 'contain',
    height: responsiveHeight(2.4),
  },
  flex_row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: responsiveHeight(1),
    marginLeft: responsiveHeight(4.1),
    marginTop: '1%',
  },
  red_flag_img: {
    aspectRatio: 1,
    resizeMode: 'contain',
    width: responsiveWidth(5.5),
  },
  another_text: {
    fontFamily: FONTFAMILY.MEDIUM,
    fontSize: RFPercentage(1.4),
  },
  small_elips_img: {
    aspectRatio: 1,
    resizeMode: 'contain',
    width: responsiveWidth(1.6),
  },
});
