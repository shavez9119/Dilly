import {
  Image,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React from 'react';
import {
  caretDownBig,
  caretUpBig,
  complete,
  cross,
  redFleg,
  smallEllips,
} from '../../assets/images/Index';
import {
  responsiveHeight,
  responsiveWidth,
} from 'react-native-responsive-dimensions';
import {COLORS, FONTFAMILY} from '../../theme/Theme';
import {RFPercentage} from 'react-native-responsive-fontsize';

const Missed = ({
  isMissedOpen,
  setIsMissedOpen,
}: {
  isMissedOpen: boolean;
  setIsMissedOpen: React.Dispatch<React.SetStateAction<boolean>>;
}) => {
  return (
    <View>
      <TouchableOpacity
        activeOpacity={1}
        style={[
          isMissedOpen ? styles.upper_section : styles.upper_section_radius,
        ]}
        onPress={() => {
          setIsMissedOpen(!isMissedOpen);
        }}>
        <>
          <View style={styles.flex}>
            <View style={styles.title_circle}>
              <Text style={styles.task_type_text}>Missed Tasks</Text>
              <View style={styles.circle}>
                <Text style={styles.task_counter_text}>8</Text>
              </View>
            </View>
            <View>
              <Image
                style={styles.caret_img_style}
                source={isMissedOpen ? caretUpBig : caretDownBig}
              />
            </View>
          </View>
          <Text style={styles.small_text}>
            Here you can see your missed tasks of the day.
          </Text>
        </>
      </TouchableOpacity>
      {isMissedOpen && (
        <View style={styles.bottom_section}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              paddingBottom: responsiveHeight(3),
              justifyContent: 'space-between',
            }}>
            <View style={{}}>
              <Text style={styles.task_name_text}>Wireframe - Project X</Text>
              <View style={styles.flex_row_another}>
                <Image source={redFleg} style={styles.red_flag_img} />
                <Text style={styles.another_text}>9 - 10 AM</Text>
                <Image
                  source={smallEllips}
                  style={{aspectRatio: 1, resizeMode: 'center'}}
                />
                <Text style={styles.another_text}>Personal</Text>
              </View>
            </View>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                gap: responsiveHeight(2),
              }}>
              <Image source={complete} style={styles.complete_img_style} />
              <Image source={cross} style={styles.complete_img_style} />
            </View>
          </View>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              paddingBottom: responsiveHeight(3),
              justifyContent: 'space-between',
            }}>
            <View style={{}}>
              <Text style={styles.task_name_text}>Wireframe - Project X</Text>
              <View style={styles.flex_row_another}>
                <Image source={redFleg} style={styles.red_flag_img} />
                <Text style={styles.another_text}>9 - 10 AM</Text>
                <Image
                  source={smallEllips}
                  style={{aspectRatio: 1, resizeMode: 'center'}}
                />
                <Text style={styles.another_text}>Personal</Text>
              </View>
            </View>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                gap: responsiveHeight(2),
              }}>
              <Image source={complete} style={styles.complete_img_style} />
              <Image source={cross} style={styles.complete_img_style} />
            </View>
          </View>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              paddingBottom: responsiveHeight(2),
            }}>
            <View style={{}}>
              <Text style={styles.task_name_text}>Lunch Break</Text>
              <View style={styles.flex_row_another}>
                <Image source={redFleg} style={styles.red_flag_img} />
                <Text style={styles.another_text}>1 - 2 PM</Text>
                <Image
                  source={smallEllips}
                  style={{aspectRatio: 1, resizeMode: 'center'}}
                />
                <Text style={styles.another_text}>Personal</Text>
              </View>
            </View>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                gap: responsiveHeight(2),
              }}>
              <Image source={complete} style={styles.complete_img_style} />
              <Image source={cross} style={styles.complete_img_style} />
            </View>
          </View>
        </View>
      )}
    </View>
  );
};

export default Missed;

const styles = StyleSheet.create({
  upper_section: {
    borderTopRightRadius: responsiveHeight(2.4),
    borderTopLeftRadius: responsiveHeight(2.4),
    height: responsiveHeight(13),
    marginTop: '2%',
    padding: responsiveHeight(2.4),
    ...Platform.select({
      ios: {
        shadowColor: 'black',
        shadowOffset: {width: 0, height: -2},
        shadowOpacity: 0.2,
        shadowRadius: 4,
      },
      android: {
        elevation: 2,
        shadowColor: COLORS.DARK_GREY,
      },
    }),
  },
  upper_section_radius: {
    borderRadius: responsiveHeight(2.4),
    height: responsiveHeight(13),
    marginTop: '2%',
    padding: responsiveHeight(2.4),
    ...Platform.select({
      ios: {
        shadowColor: 'black',
        shadowOffset: {width: 0, height: -2},
        shadowOpacity: 0.2,
        shadowRadius: 4,
      },
      android: {
        elevation: 2,
        shadowColor: COLORS.DARK_GREY,
      },
    }),
  },
  flex: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  task_type_text: {
    fontSize: RFPercentage(2),
    fontFamily: FONTFAMILY.BOLD,
    color: COLORS.BLACK,
  },
  title_circle: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: responsiveHeight(1.5),
  },
  circle: {
    height: responsiveHeight(3.2),
    width: responsiveHeight(3.2),
    borderRadius: responsiveHeight(2),
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.LIGHT_BLUE,
  },
  task_counter_text: {
    fontFamily: FONTFAMILY.BLACK,
    color: COLORS.WHITE,
  },
  small_text: {
    fontFamily: FONTFAMILY.MEDIUM,
    marginTop: '4%',
    color: COLORS.DARK_GREY,
    fontSize: RFPercentage(1.6),
  },
  bottom_section: {
    borderBottomRightRadius: responsiveHeight(2.4),
    borderBottomLeftRadius: responsiveHeight(2.4),
    padding: responsiveHeight(2.4),
    ...Platform.select({
      ios: {
        shadowColor: 'black',
        shadowOffset: {width: 0, height: -2},
        shadowOpacity: 0.2,
        shadowRadius: 4,
      },
      android: {
        elevation: 2,
        shadowColor: COLORS.DARK_GREY,
      },
    }),
  },
  caret_img_style: {
    aspectRatio: 1,
    resizeMode: 'contain',
    height: responsiveHeight(4),
  },
  task_name_text: {
    fontFamily: FONTFAMILY.BLACK,
    fontSize: RFPercentage(1.8),
    color: COLORS.BLACK,
  },
  flex_row_another: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: responsiveHeight(1),
    marginTop: '6%',
  },
  red_flag_img: {
    aspectRatio: 1,
    resizeMode: 'contain',
    width: responsiveWidth(5.5),
  },
  another_text: {
    fontFamily: FONTFAMILY.MEDIUM,
    fontSize: RFPercentage(1.4),
  },
  complete_img_style: {
    aspectRatio: 1,
    resizeMode: 'contain',
    width: responsiveWidth(9.6),
  },
});
