import {StyleSheet, Text, TextInput, View} from 'react-native';
import React from 'react';
import {COLORS, FONTFAMILY} from '../theme/Theme';
import {RFPercentage} from 'react-native-responsive-fontsize';
import {inputIF} from '../types/Types';
import {responsiveHeight} from 'react-native-responsive-dimensions';
import {selectTheme} from '../redux/slices/ThemeSlice';
import {useSelector} from 'react-redux';

const Input = ({
  _bColor,
  _bRadius,
  _placeHolder,
  _value,
  _lable,
  _height,
  _onChange,
  _editable,
  _maxLength,
}: inputIF) => {
  const theme = useSelector(selectTheme);

  const styles = StyleSheet.create({
    input_container: {
      marginTop: '8.5%',
    },
    email_text: {
      marginBottom: 10,
      fontSize: RFPercentage(1.8),
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    input_style: {
      borderWidth: 1,
      paddingLeft: responsiveHeight(2),
      fontSize: RFPercentage(1.8),
      paddingVertical: responsiveHeight(1.3),
      fontFamily: FONTFAMILY.REGULAR,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
  });

  return (
    <View style={[styles.input_container, {height: _height}]}>
      <Text style={styles.email_text}>{_lable}</Text>
      <TextInput
        editable={_editable}
        maxLength={_maxLength}
        placeholderTextColor={COLORS.DARK_GREY}
        style={[
          styles.input_style,
          {borderColor: _bColor, borderRadius: _bRadius},
        ]}
        placeholder={_placeHolder}
        value={_value}
        onChangeText={_onChange}
      />
    </View>
  );
};

export default Input;
