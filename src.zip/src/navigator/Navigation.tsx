import React from 'react';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {NavigationContainer} from '@react-navigation/native';
import {
  Welcome,
  BottomNavigation,
  CreateAccount,
  Login,
} from '../screens/Index';

import {
  ForgotPassword,
  EditProfile,
  EditEmail,
  EditPassword,
  EditSyncing,
  Reward,
} from '../components/Index';
const Stack = createNativeStackNavigator();

export type RootStackParamList = {
  Home: undefined;
  REWARD: undefined;
  CREATEACCOUNT: undefined;
  BOTTOMNAVIGATION: undefined;
  LOGIN: undefined;
  FORGOTPASSWORD: undefined;
  EDITPROFILE: undefined;
  EDITEMAIL: undefined;
  EDITPASSWORD: undefined;
  EDITSYNCING: undefined;
};

const Navigation = () => {
  return (
    <>
      <NavigationContainer>
        <Stack.Navigator
          screenOptions={{
            animation: 'none',
            headerShown: false,
          }}>
          <Stack.Screen name="WELCOME" component={Welcome} />
          <Stack.Screen name="CREATEACCOUNT" component={CreateAccount} />
          <Stack.Screen name="BOTTOMNAVIGATION" component={BottomNavigation} />
          <Stack.Screen name="LOGIN" component={Login} />
          <Stack.Screen name="FORGOTPASSWORD" component={ForgotPassword} />
          <Stack.Screen name="EDITPROFILE" component={EditProfile} />
          <Stack.Screen name="EDITEMAIL" component={EditEmail} />
          <Stack.Screen name="EDITPASSWORD" component={EditPassword} />
          <Stack.Screen name="EDITSYNCING" component={EditSyncing} />
          <Stack.Screen name="REWARD" component={Reward} />
        </Stack.Navigator>
      </NavigationContainer>
    </>
  );
};

export default Navigation;
