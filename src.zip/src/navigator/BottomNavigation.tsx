import React from 'react';
import {Image, Keyboard, StyleSheet} from 'react-native';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {Home, CreateTask, Setting, CalendarScreen} from '../screens/Index';
import {
  responsiveHeight,
  responsiveWidth,
} from 'react-native-responsive-dimensions';
import {useIsFocused} from '@react-navigation/native';

const Tab = createBottomTabNavigator();

const BottomNavigation = () => {
  const isCreateFocused = useIsFocused();
  return (
    <>
      <Tab.Navigator
        screenOptions={{
          headerShown: false,
          tabBarShowLabel: false,
          tabBarHideOnKeyboard: true,
          title: 'Home',
          headerStyle: {
            bottom: 0,
          },
        }}>
        <Tab.Screen
          name="HOME"
          component={Home}
          options={{
            tabBarStyle: {
              borderTopEndRadius: 30,
              borderTopStartRadius: 30,
              shadowColor: '#171717',
              shadowOffset: {width: 4, height: 4},
              shadowOpacity: 10,
              shadowRadius: 20,
              elevation: 20,
              height: responsiveHeight(9),
            },
            tabBarIcon: ({focused}: any) => {
              return (
                <>
                  {focused ? (
                    <Image
                      style={styles.bottom_tab_img}
                      source={require('../assets/images/home_active.png')}
                    />
                  ) : (
                    <Image
                      style={styles.bottom_tab_img}
                      source={require('../assets/images/home_non_active.png')}
                    />
                  )}
                </>
              );
            },
          }}
        />
        <Tab.Screen
          name="CREATETASK"
          component={CreateTask}
          options={{
            tabBarStyle: {
              borderTopEndRadius: 30,
              borderTopStartRadius: 30,
              shadowColor: '#171717',
              shadowOffset: {width: 4, height: 4},
              shadowOpacity: 10,
              shadowRadius: 20,
              elevation: 20,
              height: responsiveHeight(9),
              display: isCreateFocused ? 'none' : 'flex',
            },
            tabBarIcon: ({focused}: any) => {
              return (
                <>
                  {focused ? (
                    <Image
                      style={styles.bottom_tab_img}
                      source={require('../assets/images/plus_non_active.png')}
                    />
                  ) : (
                    <Image
                      style={styles.bottom_tab_img}
                      source={require('../assets/images/plus_non_active.png')}
                    />
                  )}
                </>
              );
            },
          }}
        />
        <Tab.Screen
          name="CALENDAR"
          component={CalendarScreen}
          options={{
            tabBarStyle: {
              borderTopEndRadius: 30,
              borderTopStartRadius: 30,
              shadowColor: '#171717',
              shadowOffset: {width: 4, height: 4},
              shadowOpacity: 10,
              shadowRadius: 20,
              elevation: 20,
              height: responsiveHeight(9),
            },
            tabBarIcon: ({focused}: any) => {
              return (
                <>
                  {focused ? (
                    <Image
                      style={styles.bottom_tab_img}
                      source={require('../assets/images/calendar_active.png')}
                    />
                  ) : (
                    <Image
                      style={styles.bottom_tab_img}
                      source={require('../assets/images/calendar_non_active.png')}
                    />
                  )}
                </>
              );
            },
          }}
        />
        <Tab.Screen
          name="SETTING"
          component={Setting}
          options={{
            tabBarStyle: {
              borderTopEndRadius: 30,
              borderTopStartRadius: 30,
              shadowColor: '#171717',
              shadowOffset: {width: 4, height: 4},
              shadowOpacity: 10,
              shadowRadius: 20,
              elevation: 20,
              height: responsiveHeight(9),
            },
            tabBarIcon: ({focused}: any) => {
              return (
                <>
                  {focused ? (
                    <Image
                      style={styles.bottom_tab_img}
                      source={require('../assets/images/setting_active.png')}
                    />
                  ) : (
                    <Image
                      style={styles.bottom_tab_img}
                      source={require('../assets/images/setting_non_active.png')}
                    />
                  )}
                </>
              );
            },
          }}
        />
      </Tab.Navigator>
    </>
  );
};

export default BottomNavigation;

const styles = StyleSheet.create({
  bottom_tab_img: {
    aspectRatio: 1,
    resizeMode: 'contain',
    height: responsiveHeight(3.6),
  },
});
