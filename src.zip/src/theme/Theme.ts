import {responsiveFontSize} from 'react-native-responsive-dimensions';
// ===== COLORS ======
export interface ColorsIF {
  LIGHT_BLUE: string;
  BLACK: string;
  LIGHT_GREY: string;
  MEDIUM_GREY: string;
  DARK_GREY: string;
  WHITE: string;
  DARK_GREEN: string;
  RED: string;
  YELLOW: string;
  ORANGE: string;
  DARK_BLUE: string;
  LIGHT_PURPLE: string;
  LIGHT_GREEN: string;
  DARK_PURPLE: string;
  DARK_PINK: string;
  SKY_BLUE: string;
  SKY_BLUE_LIGHT: string;
  PURPLE: string;
  BLUE: string;
  LIGHT_BLACK: string;
  GREY: string;
  DARK: string;
}
const COLORS: ColorsIF = {
  LIGHT_BLUE: '#4851f5',
  DARK_BLUE: '#550BFB',
  BLACK: '#1A1A1A',
  DARK_GREY: '#9A9A9A',
  MEDIUM_GREY: '#BCBCBC',
  LIGHT_GREY: '#E5E5E5',
  WHITE: '#FFF',
  DARK_GREEN: '#07D240',
  RED: '#e53b32',
  ORANGE: '#FB8008',
  YELLOW: '#F4C41A',
  DARK_PINK: '#FB0878',
  DARK_PURPLE: '#65188E',
  LIGHT_PURPLE: '#856AD1',
  LIGHT_GREEN: '#08FB88',
  SKY_BLUE: '#9BF7E8',
  SKY_BLUE_LIGHT: '#E3F2FF',
  PURPLE: '#5558AF',
  BLUE: '#5f52ac',
  LIGHT_BLACK: '#4a4a4a',
  GREY: '#f7f7f7',
  DARK: '#252525',
};

//  ===== FONT FAMILY ======
const FONTFAMILY: FontFamilyIF = {
  BOLD: 'ProductSans-Bold',
  BLACK: 'ProductSans-Black',
  LIGHT: 'ProductSans-Light',
  MEDIUM: 'ProductSans-Medium',
  REGULAR: 'ProductSans-Regular',
  THIN: 'ProductSans-Thin',
};

interface FontFamilyIF {
  BOLD: string;
  BLACK: string;
  LIGHT: string;
  MEDIUM: string;
  REGULAR: string;
  THIN: string;
}

// ====== FONT SIZE ======
interface FontSizeIF {
  FONT_SIZE_32: number;
  FONT_SIZE_24: number;
  FONT_SIZE_20: number;
  FONT_SIZE_16: number;
  FONT_SIZE_15: number;
  FONT_SIZE_14: number;
  FONT_SIZE_12: number;
  FONT_SIZE_11: number;
}
const FONTSIZE: FontSizeIF = {
  FONT_SIZE_32: responsiveFontSize(4.4),
  FONT_SIZE_24: responsiveFontSize(3.7),
  FONT_SIZE_20: responsiveFontSize(2),
  FONT_SIZE_16: 16,
  FONT_SIZE_15: 15,
  FONT_SIZE_14: responsiveFontSize(1.8),
  FONT_SIZE_12: 12,
  FONT_SIZE_11: 11,
};

export {COLORS, FONTFAMILY, FONTSIZE};
