import {createSlice} from '@reduxjs/toolkit';

export const workingDaysSlice = createSlice({
  name: 'workingDays',
  initialState: {
    workingDays: ['M', 'T', 'W', 'T', 'F', 'S', 'S'],
    selectedWorkingDays: [0, 1, 2, 3, 4, 5, 6],
  },
  reducers: {
    toggleWorkingDays: (state, action) => {
      const index = action.payload;

      if (!state.selectedWorkingDays.includes(index)) {
        state.selectedWorkingDays.push(index);
      } else {
        state.selectedWorkingDays = state.selectedWorkingDays.filter(
          selectedDay => selectedDay !== index,
        );
      }
    },
  },
});

export const {toggleWorkingDays} = workingDaysSlice.actions;

export const selectWorkingDays = (state: any) => state.workingDays;

export default workingDaysSlice.reducer;
