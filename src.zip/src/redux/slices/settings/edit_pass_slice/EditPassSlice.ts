import {createSlice} from '@reduxjs/toolkit';

export const editPassSlice = createSlice({
  name: 'editPassSlice',
  initialState: {
    editOldPassInput: '',
    editNewPassInput: '',
    editCNewPassInput: '',
  },
  reducers: {
    setEditOldPassInput: (state, action) => {
      state.editOldPassInput = action.payload;
    },
    setEditNewPassInput: (state, action) => {
      state.editNewPassInput = action.payload;
    },
    setEditCNewPassInput: (state, action) => {
      state.editCNewPassInput = action.payload;
    },
  },
});

export const {setEditOldPassInput, setEditNewPassInput, setEditCNewPassInput} =
  editPassSlice.actions;

export const selectEditPass = state => state.editPassSlice;

export default editPassSlice.reducer;
