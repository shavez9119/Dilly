import {createSlice} from '@reduxjs/toolkit';

export const editEmailSlice = createSlice({
  name: 'editEmailSlice',
  initialState: {
    editEmail: '',
    editPassword: '',
  },
  reducers: {
    setEditEmail: (state, action) => {
      state.editEmail = action.payload;
    },
    setEditPassword: (state, action) => {
      state.editPassword = action.payload;
    },
  },
});

export const {setEditEmail, setEditPassword} = editEmailSlice.actions;

export const selectEditProfile = state => state.editEmailSlice;

export default editEmailSlice.reducer;
