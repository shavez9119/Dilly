import {createSlice} from '@reduxjs/toolkit';

export const editProfileSlice = createSlice({
  name: 'editProfile',
  initialState: {
    editFNameInput: '',
    editLNameInput: '',
  },

  reducers: {
    setEditFNameInput: (state, action) => {
      state.editFNameInput = action.payload;
    },
    setEditLNameInput: (state, action) => {
      state.editLNameInput = action.payload;
    },
  },
});

export const {setEditFNameInput, setEditLNameInput} = editProfileSlice.actions;

export const selectEditProfile = (state: {editProfile: any}) =>
  state.editProfile;
export default editProfileSlice.reducer;
