// slices/nextScreenSlice.js

import {createSlice} from '@reduxjs/toolkit';

const collectedTitleDataSlice = createSlice({
  name: 'titleData',
  initialState: {
    titleData: [],
  },
  reducers: {
    setTitleData: (state, action) => {
      state.titleData = action.payload;
    },
  },
});

export const {setTitleData} = collectedTitleDataSlice.actions;
export const selectTitleData = state => state.titleData.titleData;

export default collectedTitleDataSlice.reducer;
