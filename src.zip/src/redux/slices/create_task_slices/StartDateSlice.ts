import {createSlice} from '@reduxjs/toolkit';

const currenDate = new Date();
const initialState = {
  reminder: '5 mins prior start time',
  selectedDay: currenDate.getDate(),
  selectedMonth: currenDate.getMonth() + 1,
  selectedYear: currenDate.getFullYear(),
};

export const startDateSlice = createSlice({
  name: 'startDateSlice',
  initialState,
  reducers: {
    setReminder: (state, action) => {
      state.reminder = action.payload;
    },
    setStartDate: (state, action) => {
      const selectedDate = new Date(action.payload);
      state.selectedDay = selectedDate.getDate();
      state.selectedMonth = selectedDate.getMonth() + 1;
      state.selectedYear = selectedDate.getFullYear();
      state.selectedDay =
        state.selectedDay < 10
          ? `0${selectedDate.getDate()}`
          : selectedDate.getDate();
    },
  },
});

export const {setReminder, setStartDate} = startDateSlice.actions;

export const selectStartDate = state => state.startDateSlice;
export default startDateSlice.reducer;
