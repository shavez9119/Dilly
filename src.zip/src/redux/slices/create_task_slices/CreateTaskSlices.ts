import {PayloadAction, createSlice} from '@reduxjs/toolkit';
// const sanitizeText = text => text.replace(/[^a-zA-Z\s]/g, '');
const currentDate = new Date();
const initialState = {
  titleInput: '',
  categoryArray: [],
  categoryInput: '',
  taskType: '',
  taskDescriptionInput: '',
  priority: '',
  notesInput: '',

  startDate: new Date().toDateString(),
  reminder: '5 mins prior start time',
  startTime: new Date().toLocaleTimeString(),
  duration: '15 mins',
};
export const createTaskSlice = createSlice({
  name: 'createTaskSlice',
  initialState,
  reducers: {
    setTitleInput: (state, action) => {
      const sanitizedText = action.payload;
      state.titleInput = sanitizedText;
    },
    setCategoryInput: (state, action) => {
      state.categoryInput = action.payload;
    },
    setTaskTypeInput: (state, action) => {
      state.taskType = action.payload;
    },
    setTaskDescriptionInput: (state, action) => {
      state.taskDescriptionInput = action.payload;
    },
    setTaskPriorityInput: (state, action) => {
      state.priority = action.payload;
    },
    setTaskNotesInput: (state, action) => {
      state.notesInput = action.payload;
    },

    setReminder: (state, action) => {
      state.reminder = action.payload;
    },
    setStartDate: (state, action) => {
      state.startDate = action.payload;
    },

    addCategory: (state, action) => {
      const category = action.payload;
      if (!state.categoryArray.includes(category)) {
        state.categoryArray.push(category);
      }
    },

    setStartTime: (state, action) => {
      state.startTime = action.payload;
    },
    setDuration: (state, action) => {
      state.duration = action.payload;
    },
  },
});

export const {
  setTitleInput,
  setCategoryInput,
  setTaskTypeInput,
  setTaskDescriptionInput,
  setTaskNotesInput,
  setTaskPriorityInput,

  setReminder,
  setStartDate,
  setStartTime,
  setDuration,
  addCategory,
} = createTaskSlice.actions;
export const selectCreateTask = state => state.createTaskSlice;

export default createTaskSlice.reducer;
