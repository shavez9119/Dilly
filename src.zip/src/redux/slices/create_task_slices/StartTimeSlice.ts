import {PayloadAction, createSlice} from '@reduxjs/toolkit';

const currentDate = new Date();
const initialState = {
  time: currentDate.getTime(),
  hours: currentDate.getHours(),
  minutes: currentDate.getMinutes(),
  amPm: currentDate.getHours() >= 12 ? 'PM' : 'AM',
  duration: '15 mins',
};
const startTimeSlice = createSlice({
  name: 'startTime',
  initialState,
  reducers: {
    setStartTime: (state, action: PayloadAction<number>) => {
      const selectedStartTime = new Date(action.payload);
      state.time = selectedStartTime.getTime();
      state.hours = selectedStartTime.getHours();
      state.minutes = selectedStartTime.getMinutes();
      state.amPm = selectedStartTime.getHours() >= 12 ? 'PM' : 'AM';

      state.minutes =
        state.minutes < 10
          ? `0${state.minutes}`
          : selectedStartTime.getMinutes();

      state.hours =
        state.hours < 10 ? `0${state.hours}` : selectedStartTime.getHours();
    },
    setDuration: (state, action) => {
      state.duration = action.payload;
    },

    updateStartHours: (state, action) => {
      state.hours = action.payload;
    },
    updateStartMinutes: (state, action) => {
      state.minutes = action.payload;
    },
  },
});

export const {setStartTime, updateStartHours, updateStartMinutes, setDuration} =
  startTimeSlice.actions;
export const selectStartWorkingTime = state => state.startTime;
export default startTimeSlice.reducer;
