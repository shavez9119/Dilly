import {createSlice} from '@reduxjs/toolkit';
const sanitizeText = text => text.replace(/[^a-zA-Z\s]/g, '');
const initialState = {
  email: '',
  pass: '',
  cPass: '',
  fName: '',
  lName: '',
  emailOTP: '',
  profile: '',
};
export const CreateAccountSlices = createSlice({
  name: 'crateAccount',
  initialState,

  reducers: {
    // setting input field
    setEmail: (state, action) => {
      state.email = action.payload;
    },
    setPass: (state, action) => {
      state.pass = action.payload;
    },
    setCPass: (state, action) => {
      state.cPass = action.payload;
    },
    setFName: (state, action) => {
      state.fName = action.payload;
    },
    setLName: (state, action) => {
      state.lName = action.payload;
    },
    setProfile: (state, action) => {
      state.profile = action.payload;
    },

    // REMOVING SPECIAL CHAR/NUMBERS
    sanitizedFName: (state, action) => {
      const sanitizedText = sanitizeText(action.payload);
      state.fName = sanitizedText;
    },
    sanitizedLName: (state, action) => {
      const sanitizedText = sanitizeText(action.payload);
      state.lName = sanitizedText;
    },

    // setting values === ""
    setEmailEmpty: (state, action) => {
      state.email = action.payload;
    },
    setPassEmpty: (state, action) => {
      state.pass = action.payload;
    },
    setCPassEmpty: (state, action) => {
      state.cPass = action.payload;
    },
    setFNameEmpty: (state, action) => {
      state.fName = action.payload;
    },
    setLNameEmpty: (state, action) => {
      state.lName = action.payload;
    },
  },
});

export const {
  setEmail,
  setPass,
  setCPass,
  setFName,
  setLName,
  setProfile,
  setEmailEmpty,
  setPassEmpty,
  setCPassEmpty,
  setFNameEmpty,
  setLNameEmpty,
  sanitizedFName,
  sanitizedLName,
} = CreateAccountSlices.actions;

export const selectCreateAccount = state => state.crateAccount;
export default CreateAccountSlices.reducer;
