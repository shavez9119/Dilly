import {PayloadAction, createSlice} from '@reduxjs/toolkit';
const currentDate = new Date();
const initialState = {
  from: {
    time: currentDate.getTime(),
    hours: currentDate.getHours(),
    minutes: currentDate.getMinutes(),
    amPm: currentDate.getHours() >= 12 ? 'PM' : 'AM',
  },
  to: {
    time: currentDate.getTime(),
    hours: currentDate.getHours(),
    minutes: currentDate.getMinutes(),
    amPm: currentDate.getHours() >= 12 ? 'PM' : 'AM',
  },
};

const workingHoursSlice = createSlice({
  name: 'workingTime',
  initialState,
  reducers: {
    setFromTime: (state, action: PayloadAction<number>) => {
      const selectedFromTime = new Date(action.payload);
      state.from.time = selectedFromTime.getTime();
      state.from.hours = selectedFromTime.getHours();
      state.from.minutes = selectedFromTime.getMinutes();
      state.from.amPm = selectedFromTime.getHours() >= 12 ? 'PM' : 'AM';
    },
    setToTime: (state, action: PayloadAction<number>) => {
      const selectedToTime = new Date(action.payload);
      state.to.time = selectedToTime.getTime();
      state.to.hours = selectedToTime.getHours();
      state.to.minutes = selectedToTime.getMinutes();
      state.to.amPm = selectedToTime.getHours() >= 12 ? 'PM' : 'AM';
    },
    updateWorkingFromHours: state => {
      if (state.from.hours == 13) {
        state.from.hours = 1;
      }
      if (state.from.hours == 14) {
        state.from.hours = 2;
      }
      if (state.from.hours == 15) {
        state.from.hours = 3;
      }
      if (state.from.hours == 16) {
        state.from.hours = 4;
      }
      if (state.from.hours == 17) {
        state.from.hours = 5;
      }
      if (state.from.hours == 18) {
        state.from.hours = 6;
      }
      if (state.from.hours == 19) {
        state.from.hours = 7;
      }
      if (state.from.hours == 20) {
        state.from.hours = 8;
      }
      if (state.from.hours == 21) {
        state.from.hours = 9;
      }
      if (state.from.hours == 22) {
        state.from.hours = 10;
      }
      if (state.from.hours == 23) {
        state.from.hours = 11;
      }
      if (state.from.hours == 24) {
        state.from.hours = 12;
      }
    },
    updateWorkingToHours: state => {
      if (state.to.hours == 13) {
        state.to.hours = 1;
      }
      if (state.to.hours == 14) {
        state.to.hours = 2;
      }
      if (state.to.hours == 15) {
        state.to.hours = 3;
      }
      if (state.to.hours == 16) {
        state.to.hours = 4;
      }
      if (state.to.hours == 17) {
        state.to.hours = 5;
      }
      if (state.to.hours == 18) {
        state.to.hours = 6;
      }
      if (state.to.hours == 19) {
        state.to.hours = 7;
      }
      if (state.to.hours == 20) {
        state.to.hours = 8;
      }
      if (state.to.hours == 21) {
        state.to.hours = 9;
      }
      if (state.to.hours == 22) {
        state.to.hours = 10;
      }
      if (state.to.hours == 23) {
        state.to.hours = 11;
      }
      if (state.to.hours == 24) {
        state.to.hours = 12;
      }
    },
  },
});

export const {
  setFromTime,
  setToTime,
  updateWorkingFromHours,
  updateWorkingToHours,
} = workingHoursSlice.actions;
export const selectWorkingTime = state => state.workingTime;
export default workingHoursSlice.reducer;
