import {createSlice} from '@reduxjs/toolkit';

export const otpSlice = createSlice({
  name: 'otp',
  initialState: Array(6).fill(''),
  reducers: {
    setOtpDigit: (state, action) => {
      const {index, value} = action.payload;
      state[index] = value;
    },
  },
});

export const {setOtpDigit} = otpSlice.actions;
export const selectOtp = (state: any) => state.otp;

export default otpSlice.reducer;
