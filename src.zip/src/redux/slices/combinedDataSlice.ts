// combinedDataSlice.ts
import {createSlice} from '@reduxjs/toolkit';

const initialState = {
  // Define your initial state for combined data here
  combinedData: [],
};

const combinedDataSlice = createSlice({
  name: 'combinedData',
  initialState,
  reducers: {
    setCombinedData: (state, action) => {
      state.combinedData = action.payload;
    },
  },
});

export const {setCombinedData} = combinedDataSlice.actions;
export const selectCombinedData = state => state.combinedData;
export default combinedDataSlice.reducer;
