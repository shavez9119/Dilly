import {createSlice} from '@reduxjs/toolkit';

const initialState = {
  dark: true,
};

export const ThemeSlice = createSlice({
  initialState,
  name: 'themeSlice',
  reducers: {
    setTheme: (state, action) => {
      state.dark = !action.payload;
    },
  },
});

export const {setTheme} = ThemeSlice.actions;

export const selectTheme = state => state.themeSlice;

export default ThemeSlice.reducer;
