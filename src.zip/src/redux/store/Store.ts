import {configureStore} from '@reduxjs/toolkit';
import otpSlice from '../slices/OtpSlice';
import workingDaysSlice from '../slices/WorkingDaysSlice';
import workingHoursSlice from '../slices/WorkingHoursSlice';
import editProfileSlice from '../slices/settings/edit_profile_slices/EditProfileSlices';
import editEmailSlice from '../slices/settings/edit_email_slices/EditEmailSlices';
import editPassSlice from '../slices/settings/edit_pass_slice/EditPassSlice';
import createTaskSlice from '../slices/create_task_slices/CreateTaskSlices';
import startTimeSlice from '../slices/create_task_slices/StartTimeSlice';
import startDateSlice from '../slices/create_task_slices/StartDateSlice';
import CollectedTitleDataSlice from '../slices/CollectedTitleDataSlice';
import CreateAccountSlices from '../slices/create_account_slice/CreateAccountSlices';
import ThemeSlice from '../slices/ThemeSlice';

const store = configureStore({
  reducer: {
    crateAccount: CreateAccountSlices,
    otp: otpSlice,
    workingDays: workingDaysSlice,
    workingTime: workingHoursSlice,
    editProfile: editProfileSlice,
    editEmailSlice: editEmailSlice,
    editPassSlice: editPassSlice,
    createTaskSlice: createTaskSlice,
    startTime: startTimeSlice,
    startDateSlice: startDateSlice,
    titleData: CollectedTitleDataSlice,
    themeSlice: ThemeSlice,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;

export {store};
