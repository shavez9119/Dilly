import React, {useState} from 'react';

import AddTitleCreateTask from './create_task/AddTitleCreateTask';
import StartDateTime from './create_task/StartDateTime';

const CreateTask = () => {
  const [step, setStep] = useState(1);

  return (
    <>
      {step === 1 ? (
        <AddTitleCreateTask step={step} setStep={setStep} />
      ) : (
        <StartDateTime step={step} setStep={setStep} />
      )}
    </>
  );
};

export default CreateTask;
