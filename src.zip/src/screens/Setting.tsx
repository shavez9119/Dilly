import {
  Alert,
  Image,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useState} from 'react';
import {COLORS, FONTFAMILY} from '../theme/Theme';
import {RFPercentage} from 'react-native-responsive-fontsize';
import {
  responsiveHeight,
  responsiveScreenHeight,
  responsiveScreenWidth,
  responsiveWidth,
} from 'react-native-responsive-dimensions';
import {useNavigation} from '@react-navigation/native';
import {
  profile,
  rewardSmall,
  moon,
  caretRight,
  moonDark,
  sunLite,
  profileBig,
  profileSetting,
  sunDark,
  rewardSmallDark,
} from '../assets/images/Index';
import {selectCreateAccount} from '../redux/slices/create_account_slice/CreateAccountSlices';
import {useSelector, useDispatch} from 'react-redux';
import {selectTheme, setTheme} from '../redux/slices/ThemeSlice';
const Setting = () => {
  const [isAutoScheduleEnabled, setIsAutoScheduleEnabled] = useState(false);
  const selectCreateAccountData = useSelector(selectCreateAccount);

  const theme = useSelector(selectTheme);

  console.log('selectThemeData:', theme.dark);

  const dispatch = useDispatch();
  const navigation = useNavigation();

  const styles = StyleSheet.create({
    container: {
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
      paddingHorizontal: 23,
    },
    profile_container: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: responsiveHeight(2.5),
      height: responsiveScreenHeight(13),
    },
    profile_name: {
      fontSize: RFPercentage(1.9),
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      fontFamily: FONTFAMILY.BLACK,
    },
    link_text: {
      color: COLORS.LIGHT_BLUE,
      fontFamily: FONTFAMILY.MEDIUM,
      textDecorationLine: 'underline',
      fontSize: RFPercentage(1.7),
      marginTop: 8,
    },
    account_text: {
      fontSize: RFPercentage(2.3),
      fontFamily: FONTFAMILY.BLACK,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      height: responsiveScreenHeight(5.3),

      // backgroundColor: 'red',
    },
    account_text_another: {
      fontSize: RFPercentage(2.1),
      fontFamily: FONTFAMILY.BLACK,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      height: responsiveScreenHeight(3),
    },
    account_sub_text: {
      fontSize: RFPercentage(1.5),
      fontFamily: FONTFAMILY.BOLD,
      marginTop: '5%',
      color: theme.dark ? COLORS.MEDIUM_GREY : COLORS.LIGHT_BLACK,
    },
    fade_text_con: {
      height: responsiveScreenHeight(7),
    },
    fade_text: {
      fontFamily: FONTFAMILY.BOLD,
      fontSize: RFPercentage(1.8),
      color: COLORS.DARK_GREY,
    },
    divider: {
      height: responsiveScreenHeight(0.4),
      width: responsiveScreenWidth(100),
      backgroundColor: theme.dark ? COLORS.LIGHT_BLACK : COLORS.LIGHT_GREY,
    },
    reward_section: {
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
      paddingHorizontal: 23,
      height: responsiveScreenHeight(17.5),
      paddingTop: '5%',
    },
    sync_section: {
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
      paddingHorizontal: 23,
      height: responsiveScreenHeight(30),
      paddingTop: '5%',
    },
    auto_schedule_section: {
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
      paddingHorizontal: 23,
      height: responsiveScreenHeight(10),
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
    },
    about_section: {
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
      paddingHorizontal: 23,
      height: responsiveScreenHeight(40),
      paddingTop: '5.5%',
    },
    theme_section: {
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
      paddingHorizontal: 23,
      height: responsiveScreenHeight(10),
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
    },
    flex: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 10,
      marginTop: 10,
    },
    img_style: {
      aspectRatio: 1,
      // height: '100%',
      resizeMode: 'contain',
      marginTop: 7,
      height: responsiveHeight(6),
      width: responsiveWidth(6),
    },
    switch_button_true: {
      backgroundColor: COLORS.LIGHT_BLUE,
      borderRadius: 50,
      height: responsiveScreenHeight(3.1),
      width: responsiveScreenWidth(14),
      justifyContent: 'center',
    },
    switch_button_false: {
      backgroundColor: COLORS.LIGHT_GREY,
      borderRadius: 50,
      height: responsiveScreenHeight(3.1),
      width: responsiveScreenWidth(14),
      justifyContent: 'center',
    },
    switch_false: {
      backgroundColor: COLORS.WHITE,
      borderRadius: 50,
      height: '75%',
      width: '38%',
      margin: 3,
      right: 0,
      position: 'absolute',
    },
    switch_true: {
      backgroundColor: COLORS.WHITE,
      borderRadius: 50,
      height: '75%',
      width: '38%',
      margin: 3,
      left: 0,
      position: 'absolute',
    },

    dark_button_true: {
      backgroundColor: COLORS.LIGHT_BLUE,
      borderRadius: 50,
      height: responsiveScreenHeight(3.1),
      width: responsiveScreenWidth(14),
      justifyContent: 'center',
    },
    dark_button_false: {
      backgroundColor: COLORS.LIGHT_GREY,
      borderRadius: 50,
      height: responsiveScreenHeight(3.1),
      width: responsiveScreenWidth(14),
      justifyContent: 'center',
    },

    dark_false: {
      backgroundColor: COLORS.WHITE,
      borderRadius: 50,
      height: '75%',
      width: '38%',
      margin: 3,
      right: 0,
      position: 'absolute',
      alignItems: 'center',
      justifyContent: 'center',
    },
    dark_true: {
      backgroundColor: COLORS.WHITE,
      borderRadius: 50,
      height: '75%',
      width: '38%',
      margin: 3,
      left: 0,
      position: 'absolute',
    },
    bg_img_left: {
      left: '14%',
      aspectRatio: 1,
      // position: 'absolute',
      height: responsiveHeight(1.5),
      top: '2%',
    },
    bg_img_right: {
      left: '65%',
      // marginTop: 5,
    },
    text_icon: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginTop: '6%',
    },
    profile_img_style: {
      aspectRatio: 1,
      resizeMode: 'contain',
      width: responsiveWidth(15),
      borderRadius: responsiveHeight(7),
    },
    dark_sun_theme_img: {
      aspectRatio: 1,
      // position: 'absolute',
      top: '20%',
      left: '20%',
      height: responsiveHeight(1.5),
      // width: responsiveScreenWidth(),
    },
    moon_dark_img: {
      aspectRatio: 1,
      // position: 'absolute',
      height: responsiveHeight(1.5),
      top: '2%',
      left: '2%',
    },
    moon_img: {
      aspectRatio: 1,
      // position: 'absolute',
      height: responsiveHeight(1.5),
      top: '2%',
      left: '60%',
    },
  });
  return (
    <>
      <ScrollView scrollEnabled={true} showsVerticalScrollIndicator={false}>
        <View style={styles.container}>
          <View style={styles.profile_container}>
            <Image
              source={{uri: selectCreateAccountData.profile}}
              style={styles.profile_img_style}
            />
            <View>
              <Text style={styles.profile_name}>
                {selectCreateAccountData.fName} {selectCreateAccountData.lName}
              </Text>
              <Text
                style={styles.link_text}
                onPress={() => {
                  navigation.navigate('EDITPROFILE');
                }}>
                View Profile
              </Text>
            </View>
          </View>
          <View>
            <Text style={styles.account_text}>Account</Text>
            <View style={styles.fade_text_con}>
              <Text style={styles.fade_text}>Email Address</Text>
              <Text
                style={styles.link_text}
                onPress={() => {
                  navigation.navigate('EDITEMAIL');
                }}>
                divyanshbhatnagar14@gmail.com
              </Text>
            </View>
            <View style={styles.fade_text_con}>
              <Text style={styles.fade_text}>Password</Text>
              <Text
                style={styles.link_text}
                onPress={() => {
                  navigation.navigate('EDITPASSWORD');
                }}>
                Change Password
              </Text>
            </View>
          </View>
        </View>
        <View style={styles.divider}></View>
        <View style={styles.reward_section}>
          <Text style={styles.account_text}>Rewards</Text>
          <View style={styles.fade_text_con}>
            <Text style={styles.fade_text}>Total Points</Text>
            <View style={styles.flex}>
              <Image
                source={theme.dark ? rewardSmallDark : rewardSmall}
                style={styles.img_style}
              />
              <Text
                style={styles.link_text}
                onPress={() => {
                  navigation.navigate('REWARD');
                }}>
                200,000 Points
              </Text>
            </View>
          </View>
        </View>
        <View style={styles.divider}></View>
        <View style={styles.sync_section}>
          <Text style={styles.account_text}>Auto-Sync</Text>
          <View style={styles.fade_text_con}>
            <Text style={styles.fade_text}>Google Calendar</Text>
            <Text
              style={styles.link_text}
              onPress={() => {
                navigation.navigate('EDITSYNCING');
              }}>
              divyanshbhatnagar14@gmail.com
            </Text>
          </View>
          <View style={styles.fade_text_con}>
            <Text style={styles.fade_text}>Microsoft Calendar</Text>
            <Text
              style={styles.link_text}
              onPress={() => {
                navigation.navigate('EDITSYNCING');
              }}>
              divyansh.bhatnagar@agicent.com
            </Text>
          </View>
          <View style={styles.fade_text_con}>
            <Text style={styles.fade_text}>Apple Calendar</Text>
            <Text
              style={styles.link_text}
              onPress={() => {
                navigation.navigate('EDITSYNCING');
              }}>
              Not Sync
            </Text>
          </View>
        </View>
        <View style={styles.divider}></View>
        <View style={styles.auto_schedule_section}>
          <View style={{}}>
            <Text style={styles.account_text_another}>Auto-Schedule</Text>
            <Text style={styles.account_sub_text}>Enable auto-schedule</Text>
          </View>
          <View>
            <TouchableOpacity
              onPress={() => {
                setIsAutoScheduleEnabled(!isAutoScheduleEnabled);
              }}
              activeOpacity={0.9}
              style={[
                isAutoScheduleEnabled
                  ? styles.switch_button_true
                  : styles.switch_button_false,
              ]}>
              <TouchableOpacity
                onPress={() => {
                  setIsAutoScheduleEnabled(!isAutoScheduleEnabled);
                }}
                activeOpacity={0.9}
                style={[
                  isAutoScheduleEnabled
                    ? styles.switch_false
                    : styles.switch_true,
                ]}></TouchableOpacity>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.divider}></View>
        <TouchableOpacity
          activeOpacity={0.7}
          onPress={() => {
            navigation.navigate('CREATEACCOUNT');
          }}
          style={styles.auto_schedule_section}>
          <View style={{}}>
            <Text style={styles.account_text_another}>
              Working Days & Hours
            </Text>
            <Text style={styles.account_sub_text}>
              Edit your working days and hours
            </Text>
          </View>
        </TouchableOpacity>

        <View style={styles.divider}></View>
        <View style={styles.theme_section}>
          <View style={{}}>
            <Text style={styles.account_text_another}>Theme</Text>
            <Text style={styles.account_sub_text}>
              Switch between Light and Dark Theme
            </Text>
          </View>
          <View>
            <TouchableOpacity
              onPress={() => {
                dispatch(setTheme(theme.dark));
              }}
              activeOpacity={0.9}
              style={[
                theme.dark ? styles.dark_button_true : styles.dark_button_false,
              ]}>
              {theme.dark ? (
                <Image
                  source={sunLite}
                  style={[
                    theme.dark ? styles.bg_img_left : styles.bg_img_right,
                  ]}
                />
              ) : (
                <Image source={moon} style={styles.moon_img} />
              )}
              <TouchableOpacity
                onPress={() => {
                  // setIsDarkModeOn(!isDarkModeOn);
                  dispatch(setTheme(theme.dark));
                }}
                activeOpacity={0.9}
                style={[theme.dark ? styles.dark_false : styles.dark_true]}>
                {theme.dark ? (
                  <Image source={moonDark} style={styles.moon_dark_img} />
                ) : (
                  <Image source={sunDark} style={styles.dark_sun_theme_img} />
                )}
              </TouchableOpacity>
            </TouchableOpacity>
          </View>
        </View>
        <View style={styles.divider}></View>
        <View style={styles.about_section}>
          <View>
            <Text style={styles.account_text_another}>About</Text>
            <Text style={styles.account_sub_text}>Version 1.0.1</Text>
          </View>
          <View style={styles.text_icon}>
            <Text style={styles.account_text_another}>Terms of Usage</Text>
            <Image source={caretRight} />
          </View>
          <View style={styles.text_icon}>
            <Text style={styles.account_text_another}>Privacy Policy</Text>
            <Image source={caretRight} />
          </View>
          <View style={styles.text_icon}>
            <Text style={styles.account_text_another}>Delete Account</Text>
            <Image source={caretRight} />
          </View>
          <View style={styles.text_icon}>
            <Text style={styles.account_text_another}>Signout</Text>
            <Image source={caretRight} />
          </View>
        </View>
      </ScrollView>
    </>
  );
};

export default Setting;
