import {StyleSheet, Text, View, Image} from 'react-native';
import React, {useEffect} from 'react';
import {useNavigation} from '@react-navigation/native';
import {COLORS, FONTFAMILY} from '../theme/Theme';
import {RFPercentage} from 'react-native-responsive-fontsize';
import {splash} from '../assets/images/Index';
const Splash = () => {
  const navigation: any = useNavigation();
  useEffect(() => {
    setTimeout(() => {
      navigation.navigate('WELCOME');
    }, 1500);
  }, []);

  return (
    <>
      <View style={styles.contaienr}>
        <Image source={splash} style={styles.splashImg} />
        <Text style={styles.splashText}>DillyDally Calendar</Text>
      </View>
    </>
  );
};

export default Splash;

const styles = StyleSheet.create({
  contaienr: {
    flex: 1,
    backgroundColor: COLORS.LIGHT_BLUE,
    textAlign: 'center',
    justifyContent: 'center',
  },
  splashText: {
    textAlign: 'center',
    fontSize: RFPercentage(4.4),
    color: COLORS.WHITE,
    fontFamily: FONTFAMILY.BLACK,
  },
  splashImg: {
    alignSelf: 'center',
    bottom: 20,
  },
});
