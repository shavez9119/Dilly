import {StyleSheet, Text} from 'react-native';
import React, {useState} from 'react';
import {
  ForgotEmailAddress,
  ForgotVerifyEmail,
  ResetPassword,
} from '../components/Index';

const ForgotPassword = () => {
  const [step, setStep] = useState(1);
  return (
    <>
      {step === 1 ? (
        <ForgotEmailAddress step={step} setStep={setStep} />
      ) : step === 2 ? (
        <ForgotVerifyEmail step={step} setStep={setStep} />
      ) : step === 3 ? (
        <ResetPassword step={step} setStep={setStep} />
      ) : (
        <Text>sdfl</Text>
      )}
    </>
  );
};

export default ForgotPassword;

const styles = StyleSheet.create({});
