import {View, Text, Image, StyleSheet, Animated} from 'react-native';
import Swiper from 'react-native-swiper';
import React, {useEffect, useState} from 'react';
import {COLORS, FONTFAMILY, FONTSIZE} from '../theme/Theme';
import {RFPercentage} from 'react-native-responsive-fontsize';
import Button from '../components/Button';
import BottomSheet from '../components/BottomSheet';
import {
  splash,
  welcomeBg,
  welcomeBg2,
  welcomeBg2Dark,
  welcomeBg3,
  welcomeBg3Dark,
  welcomeBgDark,
} from '../assets/images/Index';
import {
  responsiveScreenHeight,
  responsiveScreenWidth,
} from 'react-native-responsive-dimensions';
import {selectTheme} from '../redux/slices/ThemeSlice';
import {useSelector} from 'react-redux';

const Welcome = () => {
  const [isBottomSheetOpen, setIsBottomSheetOpen] = useState(false);
  const [isWelcomeReady, setIsWelcomeReady] = useState(false);
  const theme = useSelector(selectTheme);

  useEffect(() => {
    setTimeout(() => {
      setIsWelcomeReady(true);
    }, 1500);
  }, []);

  const styles = StyleSheet.create({
    container: {
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
      paddingHorizontal: 23,
      flex: 1,
    },
    slide: {
      justifyContent: 'center',
      alignItems: 'center',
    },
    image: {
      top: responsiveScreenHeight(2),
      height: responsiveScreenHeight(45),
      width: responsiveScreenHeight(44),
    },
    sliderTitle: {
      fontSize: FONTSIZE.FONT_SIZE_24,
      fontFamily: FONTFAMILY.BLACK,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      marginTop: responsiveScreenHeight(4),
      textAlign: 'center',
    },
    sliderSubTitle: {
      textAlign: 'center',
      fontSize: FONTSIZE.FONT_SIZE_14,
      fontFamily: FONTFAMILY.MEDIUM,
      marginVertical: responsiveScreenHeight(2.5),
      color: theme.dark ? COLORS.MEDIUM_GREY : COLORS.BLACK,
    },
    dot: {
      backgroundColor: theme.dark ? COLORS.LIGHT_BLACK : COLORS.LIGHT_GREY,
      width: 8,
      height: 8,
      borderRadius: 4,
      margin: 3,
    },
    activeDot: {
      backgroundColor: COLORS.LIGHT_BLUE,
      width: 25,
      height: 8,
      borderRadius: 4,
      margin: 3,
    },
    terms_policy_con: {
      marginVertical: 20,
      alignItems: 'center',
      marginHorizontal: 4,
    },
    terms_policy_text: {
      fontFamily: FONTFAMILY.MEDIUM,
      textAlign: 'center',
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      fontSize: RFPercentage(1.7),
    },
    link_text: {
      color: COLORS.LIGHT_BLUE,
      fontFamily: FONTFAMILY.BOLD,
      textDecorationLine: 'underline',
      fontSize: RFPercentage(1.4),
    },
    contaienrSp: {
      flex: 1,
      backgroundColor: COLORS.LIGHT_BLUE,
      textAlign: 'center',
      justifyContent: 'center',
    },
    splashText: {
      textAlign: 'center',
      fontSize: RFPercentage(4.4),
      color: COLORS.WHITE,
      fontFamily: FONTFAMILY.BLACK,
    },
    splashImg: {
      alignSelf: 'center',
      // bottom: 20,
      height: responsiveScreenHeight(26),
      width: responsiveScreenWidth(35),
    },
  });
  return (
    <>
      {isWelcomeReady ? (
        <View style={styles.container}>
          <Swiper
            showsButtons={false}
            loop={true}
            autoplay={true}
            showsPagination={true}
            dotStyle={styles.dot}
            activeDotStyle={styles.activeDot}>
            <View style={styles.slide}>
              <Image
                style={styles.image}
                source={theme.dark ? welcomeBgDark : welcomeBg}
              />
              <Text style={styles.sliderTitle}>
                Manage all your tasks with Dillydally Calendar
              </Text>

              <Text style={styles.sliderSubTitle}>
                The Dillydally Calendar assists in keeping your Google,
                Microsoft, and Apple Calendars synced in one place.
              </Text>
            </View>
            <View style={styles.slide}>
              <Image
                style={styles.image}
                source={theme.dark ? welcomeBg2Dark : welcomeBg2}
              />
              <Text style={styles.sliderTitle}>
                Track all your daily tasks with Dillydally Calendar
              </Text>
              <Text style={styles.sliderSubTitle}>
                Effortlessly track your daily tasks with fewer clicks using the
                Dillydally Calendar.
              </Text>
            </View>
            <View style={styles.slide}>
              <Animated.Image
                style={styles.image}
                source={theme.dark ? welcomeBg3Dark : welcomeBg3}
              />
              <Text style={styles.sliderTitle}>
                Time and Work Management never been so easy
              </Text>
              <Text style={styles.sliderSubTitle}>
                Efficiently manage your business or personal tasks type using
                the Dillydally Calendar.
              </Text>
            </View>
          </Swiper>
          <Button
            _onPress={() => setIsBottomSheetOpen(true)}
            _text={'Get Started'}
            _bgColor={COLORS.LIGHT_BLUE}
            _fontSize={FONTSIZE.FONT_SIZE_16}
            _color={COLORS.WHITE}
            _bColor={'transparent'}
          />
          <View style={styles.terms_policy_con}>
            <Text style={styles.terms_policy_text}>
              By clicking “Get Started”, you’ll agree to Dillydally Calendar’s
              <Text style={styles.link_text}> Terms of Usage</Text> and{' '}
              <Text style={styles.link_text}> Privacy Policy</Text>.
            </Text>
          </View>
        </View>
      ) : (
        <View style={styles.contaienrSp}>
          <Image source={splash} style={styles.splashImg} />
          <Text style={styles.splashText}>DillyDally Calendar</Text>
        </View>
      )}

      {/* BOTTOM SHEET ANIMATED */}
      {isBottomSheetOpen && (
        <BottomSheet setIsBottomSheetOpen={setIsBottomSheetOpen} />
      )}
    </>
  );
};

export default Welcome;
