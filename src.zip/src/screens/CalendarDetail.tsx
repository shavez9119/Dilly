import {StyleSheet, Text, View} from 'react-native';
import React from 'react';

const CalendarDetail = () => {
  return (
    <View>
      <Text>CalendarDetail</Text>
    </View>
  );
};

export default CalendarDetail;

const styles = StyleSheet.create({});
