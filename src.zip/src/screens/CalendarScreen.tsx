import React, {useState, useEffect} from 'react';
import {Text, TouchableOpacity, View} from 'react-native';
import moment from 'moment';
import CalendarStrip from 'react-native-calendar-strip';
import {Calendar} from 'react-native-calendars';
import {COLORS} from '../theme/Theme';

const CalendarScreen = () => {
  const [isCalendarVisible, setCalendarVisibility] = useState(false);
  const [selectedDate, setSelectedDate] = useState(moment());
  const [markedDates, setMarkedDates] = useState({});

  const showCalendar = () => {
    setCalendarVisibility(true);
  };

  const hideCalendar = () => {
    setCalendarVisibility(false);
  };

  const handleDayPress = day => {
    const newSelectedDate = moment(day.dateString);
    setSelectedDate(newSelectedDate);
    setMarkedDates({[newSelectedDate.format('YYYY-MM-DD')]: {selected: true}});
    hideCalendar();
  };

  useEffect(() => {
    setMarkedDates({[selectedDate.format('YYYY-MM-DD')]: {selected: true}});
  }, [selectedDate]);

  return (
    <View>
      <TouchableOpacity onPress={showCalendar}>
        <Text>Open Calendar</Text>
      </TouchableOpacity>

      {isCalendarVisible && (
        <View
          style={{position: 'absolute', zIndex: 1, width: '100%', top: '20%'}}>
          <Calendar
            onDayPress={handleDayPress}
            markedDates={markedDates}
            theme={{
              calendarBackground: COLORS.GREY,
              textSectionTitleColor: COLORS.LIGHT_BLUE,
              dayTextColor: COLORS.LIGHT_BLUE,
              todayTextColor: COLORS.BLACK,
              selectedDayTextColor: 'yellow',
              arrowColor: COLORS.WHITE,
            }}
            hideExtraDays
          />
        </View>
      )}

      <CalendarStrip
        onDayPress={handleDayPress}
        calendarAnimation={{type: 'sequence', duration: 30}}
        daySelectionAnimation={{
          type: 'border',
          duration: 200,
          borderWidth: 1,
          borderHighlightColor: 'white',
        }}
        style={{height: 100, paddingTop: 20, paddingBottom: 10}}
        calendarHeaderStyle={{color: 'white'}}
        calendarColor={'#7743CE'}
        dateNumberStyle={{color: 'white'}}
        dateNameStyle={{color: 'white'}}
        highlightDateNumberStyle={{color: 'yellow'}}
        highlightDateNameStyle={{color: 'yellow'}}
        disabledDateNameStyle={{color: 'grey'}}
        disabledDateNumberStyle={{color: 'grey'}}
        selectedDate={selectedDate.format('YYYY-MM-DD')}
        iconContainer={{flex: 0.1}}
      />
    </View>
  );
};

export default CalendarScreen;
