import {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  TextInput,
  ScrollView,
} from 'react-native';
import React, {useState, useEffect} from 'react';
import {COLORS, FONTFAMILY} from '../theme/Theme';
import {
  notification,
  notificationDark,
  profile,
  rewardVerySmall,
  search,
} from '../assets/images/Index';
import {RFPercentage} from 'react-native-responsive-fontsize';
import {
  responsiveHeight,
  responsiveScreenWidth,
  responsiveWidth,
} from 'react-native-responsive-dimensions';
import {StackNavigationProp} from '@react-navigation/stack';
import {RootStackParamList} from '../navigator/Navigation';
import {Completed, Missed, OnGoing, UpComing} from '../components/Index';
type HomeScreenProps = {
  navigation: StackNavigationProp<RootStackParamList, 'REWARD'>;
};
import {useSelector} from 'react-redux';
import {selectCreateAccount} from '../redux/slices/create_account_slice/CreateAccountSlices';
import {selectTheme} from '../redux/slices/ThemeSlice';
const HomeScreen = ({navigation}: HomeScreenProps) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [isGoingOnOpen, setIsGoingOnOpen] = useState(false);
  const [isUpcomingOpen, setIsUpcomingOpen] = useState(false);
  const [isMissedOpen, setIsMissedOpen] = useState(false);
  const [isCompletedOpen, setIsCompletedOpen] = useState(false);
  const theme = useSelector(selectTheme);

  const selectCreateAccountData = useSelector(selectCreateAccount);

  const months = [
    'Jan',
    'Feb',
    'March',
    'April',
    'May',
    'June',
    'July',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];

  const [currentYear, setCurrentYear] = useState(currentDate.getFullYear());
  const [currentMonth, setCurrentMonth] = useState<string | number>(
    currentDate.getMonth(),
  );
  const [currentDay, setCurrentDay] = useState<number | string>(
    currentDate.getDate(),
  );

  console.log('selectCreateAccountData:', selectCreateAccountData);

  useEffect(() => {
    setCurrentMonth(months[currentDate.getMonth()]);
  }, [currentDate]);

  const styles = StyleSheet.create({
    container: {
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
      paddingBottom: 10,
      paddingHorizontal: 23,
      zIndex: -20,
      paddingTop: 20,
    },
    flex: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
    },
    flex_gap: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: responsiveScreenWidth(3.5),
    },
    name_text: {
      fontSize: RFPercentage(2.1),
      fontFamily: FONTFAMILY.BLACK,
      color: COLORS.BLACK,
    },
    task_text: {
      fontSize: RFPercentage(3),
      fontFamily: FONTFAMILY.BLACK,
      color: COLORS.BLACK,
      height: responsiveHeight(6),
    },
    date_text: {
      fontSize: RFPercentage(1.5),
      fontFamily: FONTFAMILY.MEDIUM,
      color: COLORS.DARK_GREY,
      marginTop: '1.5%',
    },
    points_bg: {
      backgroundColor: COLORS.LIGHT_BLUE,
      borderRadius: 50,
    },
    flex_small: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingHorizontal: responsiveScreenWidth(2.7),
      paddingVertical: responsiveHeight(0.7),
      gap: responsiveScreenWidth(2),
    },
    points_count_text: {
      color: COLORS.WHITE,
      fontSize: RFPercentage(1.8),
      fontFamily: FONTFAMILY.MEDIUM,
    },
    search_style: {
      borderRadius: responsiveHeight(1),
      borderColor: COLORS.LIGHT_GREY,
      borderWidth: 1,
      width: '100%',
      height: responsiveHeight(6),
      marginTop: '9%',
      paddingVertical: responsiveHeight(1.3),
      paddingLeft: responsiveScreenWidth(10),
      fontSize: RFPercentage(1.6),
      fontFamily: FONTFAMILY.MEDIUM,
    },

    searchIcon_searchInput: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: responsiveHeight(3),
    },
    search_img: {
      position: 'absolute',
      left: '3.5%',
      bottom: responsiveHeight(0.5),
      aspectRatio: 1,
      height: responsiveHeight(5),
      width: responsiveWidth(5),
      resizeMode: 'contain',
    },
    divider: {
      height: responsiveHeight(0.4),
      width: responsiveScreenWidth(100),
      backgroundColor: COLORS.LIGHT_GREY,
    },
    bottom_container: {
      flex: 1,
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
      paddingHorizontal: 23,
      paddingVertical: 20,
    },
    profile_img_style: {
      aspectRatio: 1,
      resizeMode: 'contain',
      height: responsiveHeight(11),
      width: responsiveWidth(11),
      borderRadius: responsiveHeight(5),
    },
    notification_img_style: {
      height: responsiveHeight(3.5),
      width: responsiveWidth(3.5),
      aspectRatio: 1,
    },
    reward_small_style: {
      aspectRatio: 1,
      resizeMode: 'contain',
      height: responsiveHeight(5.5),
      width: responsiveWidth(5.5),
    },
  });
  return (
    <>
      <View style={styles.container}>
        <View style={styles.flex}>
          <View style={styles.flex_gap}>
            <Image
              source={{uri: selectCreateAccountData.profile}}
              style={styles.profile_img_style}
            />
            <View>
              <Text style={styles.name_text}>
                Hi {selectCreateAccountData.fName}
              </Text>
              <Text
                style={
                  styles.date_text
                }>{`Today is ${currentMonth} ${currentDay}, ${currentYear}`}</Text>
            </View>
          </View>
          <View style={styles.flex_gap}>
            <TouchableOpacity activeOpacity={0.7}>
              <Image
                source={theme.dark ? notificationDark : notification}
                style={styles.notification_img_style}
              />
            </TouchableOpacity>
            <TouchableOpacity
              activeOpacity={0.8}
              style={styles.points_bg}
              onPress={() => {
                navigation.navigate('REWARD');
              }}>
              <TouchableOpacity
                style={styles.flex_small}
                activeOpacity={0.7}
                onPress={() => {
                  navigation.navigate('REWARD');
                }}>
                <Image
                  source={rewardVerySmall}
                  style={styles.reward_small_style}
                />
                <Text style={styles.points_count_text}>200K</Text>
              </TouchableOpacity>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.searchIcon_searchInput}>
          <Image style={styles.search_img} source={search} />
          <TextInput
            placeholder="Search for tasks..."
            style={styles.search_style}
          />
        </View>
      </View>
      <View style={styles.divider}></View>
      <View style={styles.bottom_container}>
        <Text style={styles.name_text}>Tasks</Text>
        <ScrollView showsVerticalScrollIndicator={false}>
          {/* ON-GOING TASK */}
          <OnGoing
            isGoingOnOpen={isGoingOnOpen}
            setIsGoingOnOpen={setIsGoingOnOpen}
          />
          {/* UP-COMING TASK */}
          <UpComing
            isUpcomingOpen={isUpcomingOpen}
            setIsUpcomingOpen={setIsUpcomingOpen}
          />
          {/* MISSED TASK */}
          <Missed
            isMissedOpen={isMissedOpen}
            setIsMissedOpen={setIsMissedOpen}
          />
          {/* COMPLETED TASK */}
          <Completed
            isCompletedOpen={isCompletedOpen}
            setIsCompletedOpen={setIsCompletedOpen}
          />
        </ScrollView>
      </View>
    </>
  );
};

export default HomeScreen;
