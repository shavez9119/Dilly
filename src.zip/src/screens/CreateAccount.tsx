import {StyleSheet, Text} from 'react-native';
import React, {useState} from 'react';
import {
  CreatePassword,
  CreateEmailAddress,
  CreateVerifyEmail,
  SetupProfile,
  SyncCalendar,
  WorkingDays,
  WorkingHours,
} from '../components/Index';

const CreateAccount = () => {
  const [step, setStep] = useState(1);
  return (
    <>
      {step === 1 ? (
        <CreateEmailAddress step={step} setStep={setStep} />
      ) : step === 2 ? (
        <CreateVerifyEmail step={step} setStep={setStep} />
      ) : step === 3 ? (
        <CreatePassword step={step} setStep={setStep} />
      ) : step === 4 ? (
        <SetupProfile step={step} setStep={setStep} />
      ) : step === 5 ? (
        <SyncCalendar step={step} setStep={setStep} />
      ) : step === 6 ? (
        <WorkingDays step={step} setStep={setStep} />
      ) : step === 7 ? (
        <WorkingHours step={step} setStep={setStep} />
      ) : (
        <Text>Null</Text>
      )}
    </>
  );
};

export default CreateAccount;

const styles = StyleSheet.create({});
