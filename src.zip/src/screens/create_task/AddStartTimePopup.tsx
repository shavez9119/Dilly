import {
  Image,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {
  clock,
  clockDark,
  closeBig,
  closeBigDark,
  selectedIcon,
  unSelectedIcon,
  unSelectedIconDark,
} from '../../assets/images/Index';
import {COLORS, FONTFAMILY, FONTSIZE} from '../../theme/Theme';
import Button from '../../components/Button';
import {
  responsiveHeight,
  responsiveWidth,
} from 'react-native-responsive-dimensions';
import {RFPercentage} from 'react-native-responsive-fontsize';
import DateTimePicker from '@react-native-community/datetimepicker';
import {useDispatch, useSelector} from 'react-redux';
import {
  setStartTime,
  selectCreateTask,
  setDuration,
} from '../../redux/slices/create_task_slices/CreateTaskSlices';
import {selectTheme} from '../../redux/slices/ThemeSlice';

const AddStartTimePopup = ({
  isAddStartTimeOpen,
  setIsAddStartTimeOpen,
}: {
  isAddStartTimeOpen: boolean;
  setIsAddStartTimeOpen: React.Dispatch<React.SetStateAction<boolean>>;
}) => {
  const dispatch = useDispatch();
  const theme = useSelector(selectTheme);

  const [isStartTimeOpen, setIsStartTimeOpen] = useState(false);
  const selectCreateTaskData = useSelector(selectCreateTask);

  console.log('selectCreateTaskData:', selectCreateTaskData.startTime);

  const [timeWithoutAmPm, amPm] = selectCreateTaskData.startTime.split(' ');
  const [hours, minutes] = timeWithoutAmPm.split(':');
  console.log('amPm:', amPm);

  const addZeroHours = (value: number) => {
    return value < 10 ? `0${value}` : `${value}`;
  };
  const addZeroMinutes = (value: number) => {
    return value < 10 ? `0${value}` : `${value}`;
  };

  // console.log('time:', hours);

  const [taskDuration, setTaskDuration] = useState([
    '15 mins',
    '30 mins',
    '45 mins',
    '60 mins',
  ]);

  const fromTimeChange = (event: any, selectedTime: any) => {
    dispatch(setStartTime(selectedTime));
    setIsStartTimeOpen(!isStartTimeOpen);

    console.log('selectedTime:', selectedTime);
  };

  let [startTimeData, setStartTimeData] = useState([]);

  // const addStartTimeData = () => {
  //   let newData = {
  //     hours,
  //     minutes,
  //     amPm,
  //     duration,
  //   };

  //   setStartTimeData(prevData => [...prevData, newData]);
  // };

  console.log('startTimeData:', startTimeData);

  // START TIME (HOURS) -- CHANGING TIME FORMAT 24hrs TO 12hrs
  // useEffect(() => {
  //   if (selectTime.hours === 13) {
  //     dispatch(updateStartHours('01'));
  //     console.log('01');
  //   }
  //   if (selectTime.hours === 14) {
  //     dispatch(updateStartHours('02'));
  //   }
  //   if (selectTime.hours === 15) {
  //     dispatch(updateStartHours('03'));
  //   }
  //   if (selectTime.hours === 16) {
  //     dispatch(updateStartHours('04'));
  //   }
  //   if (selectTime.hours === 17) {
  //     dispatch(updateStartHours('05'));
  //   }
  //   if (selectTime.hours === 18) {
  //     dispatch(updateStartHours('06'));
  //   }
  //   if (selectTime.hours === 19) {
  //     dispatch(updateStartHours('07'));
  //   }
  //   if (selectTime.hours === 20) {
  //     dispatch(updateStartHours('08'));
  //   }
  //   if (selectTime.hours === 21) {
  //     dispatch(updateStartHours('09'));
  //   }
  //   if (selectTime.hours === 22) {
  //     dispatch(updateStartHours('10'));
  //   }
  //   if (selectTime.hours === 23) {
  //     dispatch(updateStartHours('11'));
  //   }
  //   if (selectTime.hours === 24) {
  //     dispatch(updateStartHours('12'));
  //   }
  // }, [selectTime]);

  // console.log('selectTime>Hours:', selectTime.hours);
  // console.log('selectTime>Minutes:', selectTime.minutes);
  // console.log('selectTime>am/pm:', selectTime.amPm);
  // console.log('selectTime>Duration:', selectTime.duration);

  const styles = StyleSheet.create({
    add_start_time_con: {
      position: 'absolute',
      backgroundColor: 'rgba(0,0,0,0.7)',
      height: responsiveHeight(100),
      width: responsiveWidth(100),
      justifyContent: 'center',
      alignItems: 'center',
    },

    container: {
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
      borderRadius: responsiveHeight(1),
    },
    pop_container: {
      width: responsiveWidth(90),
      padding: responsiveHeight(2.7),
    },
    pop_title_text: {
      fontFamily: FONTFAMILY.BLACK,
      fontSize: RFPercentage(2.9),
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      textAlign: 'center',
      // backgroundColor: 'red',
      width: '100%',
      zIndex: -23,
    },
    close_icon_big: {
      aspectRatio: 1,
      height: responsiveHeight(3.2),
      width: responsiveWidth(7),
      position: 'absolute',
      right: responsiveHeight(1.5),
      top: responsiveHeight(1.5),
      padding: responsiveHeight(1),
    },
    email_text: {
      marginBottom: 10,
      fontSize: RFPercentage(1.8),
      fontFamily: FONTFAMILY.BOLD,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    input_style: {
      borderRadius: 10,
      borderColor: COLORS.LIGHT_GREY,
      borderWidth: 1,
      paddingLeft: 20,
      fontSize: RFPercentage(1.7),
      paddingVertical: 9,
      fontFamily: FONTFAMILY.BOLD,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      height: responsiveHeight(6),
    },
    icon_style: {
      position: 'absolute',
      right: 20,
      top: responsiveHeight(2.1),
    },
    set_remainder_con: {
      marginTop: '6%',
      height: responsiveHeight(30),
    },
    remainder_flex: {
      flexDirection: 'row',
      alignItems: 'center',
      marginTop: '3%',
    },
    selected_icon: {
      height: responsiveHeight(3.3),
      aspectRatio: 1,
      width: responsiveWidth(6.1),
    },
    remainder_text: {
      // marginTop: '4.3%',
      marginLeft: '2%',
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      fontSize: RFPercentage(1.8),
    },
    input_img_style: {
      aspectRatio: 1,
      resizeMode: 'contain',
      height: responsiveHeight(3),
      width: responsiveWidth(3),
      bottom: '12%',
    },
  });
  return (
    <>
      <View style={styles.add_start_time_con}>
        <View style={styles.container}>
          <TouchableOpacity
            activeOpacity={0.7}
            onPress={() => {
              setIsAddStartTimeOpen(!isAddStartTimeOpen);
            }}>
            <Image
              source={theme.dark ? closeBigDark : closeBig}
              style={styles.close_icon_big}
            />
          </TouchableOpacity>

          <View style={styles.pop_container}>
            <Text style={styles.pop_title_text}>Add Start Time</Text>

            <View style={{marginTop: '12%'}}>
              <Text style={styles.email_text}>Start Time</Text>
              <TouchableOpacity
                activeOpacity={0.6}
                onPress={() => {
                  setIsStartTimeOpen(!isStartTimeOpen);
                }}>
                <TextInput
                  placeholderTextColor={COLORS.DARK_GREY}
                  style={styles.input_style}
                  value={`${addZeroHours(hours)}:${addZeroMinutes(
                    minutes,
                  )} ${amPm.toUpperCase()}`}
                  editable={false}
                />

                <View style={styles.icon_style}>
                  <Image
                    source={theme.dark ? clockDark : clock}
                    style={styles.input_img_style}
                  />
                </View>
              </TouchableOpacity>
            </View>
            <View style={styles.set_remainder_con}>
              <Text style={styles.email_text}>Duration</Text>
              <View>
                {taskDuration.map(item => {
                  return (
                    <View>
                      <TouchableOpacity
                        style={styles.remainder_flex}
                        activeOpacity={0.9}
                        onPress={() => {
                          dispatch(setDuration(item));
                        }}>
                        <Image
                          // source={
                          //   selectCreateTaskData.duration == item
                          //     ? selectedIcon
                          //     : unSelectedIcon
                          // }
                          source={
                            selectCreateTaskData.duration == item && theme.dark
                              ? selectedIcon
                              : selectCreateTaskData.duration !== item &&
                                theme.dark
                              ? unSelectedIconDark
                              : selectCreateTaskData.duration == item &&
                                !theme.dark
                              ? selectedIcon
                              : unSelectedIcon
                          }
                          style={styles.selected_icon}
                        />

                        <Text key={item} style={styles.remainder_text}>
                          {item}
                        </Text>
                      </TouchableOpacity>
                    </View>
                  );
                })}
              </View>
            </View>

            {isStartTimeOpen && (
              <DateTimePicker
                mode="time"
                value={new Date(0, 0, 0, parseInt(hours), parseInt(minutes))}
                is24Hour={false}
                onChange={(event, selectedTime) =>
                  fromTimeChange(event, selectedTime)
                }
              />
            )}

            <Button
              _onPress={() => {
                // addStartTimeData();
                setIsAddStartTimeOpen(false);
              }}
              _text={'Save'}
              _bgColor={COLORS.LIGHT_BLUE}
              _fontSize={FONTSIZE.FONT_SIZE_16}
              _color={COLORS.WHITE}
              _bColor={'transparent'}
            />
          </View>
        </View>
      </View>
    </>
  );
};

export default AddStartTimePopup;
