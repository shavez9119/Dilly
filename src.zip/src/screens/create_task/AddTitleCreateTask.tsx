import {
  FlatList,
  Image,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useEffect, useRef, useState} from 'react';
import {
  arrowLeft,
  arrowLeftDark,
  caretDown,
  caretDownDark,
  caretUp,
} from '../../assets/images/Index';
import {useNavigation} from '@react-navigation/native';
import {COLORS, FONTFAMILY, FONTSIZE} from '../../theme/Theme';
import Button from '../../components/Button';
import {RFPercentage} from 'react-native-responsive-fontsize';
import {
  responsiveHeight,
  responsiveScreenHeight,
} from 'react-native-responsive-dimensions';

import {useDispatch, useSelector} from 'react-redux';
import {
  setTitleInput,
  // setCategoryInput,
  addCategory,
  setTaskTypeInput,
  selectCreateTask,
  setTaskDescriptionInput,
  setTaskNotesInput,
  setTaskPriorityInput,
} from '../../redux/slices/create_task_slices/CreateTaskSlices';
import {selectTheme} from '../../redux/slices/ThemeSlice';
const AddTitleCreateTask = ({
  step,
  setStep,
}: {
  step: number;
  setStep: React.Dispatch<React.SetStateAction<number>>;
}) => {
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const [isTaskTypeOpen, setIsTaskTypeOpen] = useState(false);
  const [isPriorityOpen, setIsPriorityOpen] = useState(false);

  const [titleMessage, setTitleMessage] = useState('');
  const [taskTypeMessage, setTaskTypeMessage] = useState('');
  const [priorityMessage, setPriorityMessage] = useState('');
  const theme = useSelector(selectTheme);

  const scrollViewRef = useRef(null);
  const inputRef1 = useRef(null);
  const inputRef2 = useRef(null);

  const createTask = useSelector(state => selectCreateTask(state));
  console.log('create Task:', createTask);

  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('');
  const [categoryArray, setCatogryArray] = useState([]);
  const [taskTypeArray, setTaskTypeArray] = useState(['Personal', 'Business']);
  const [taskType, setTaskType] = useState('');
  const [description, setDescription] = useState('');
  const [taskPriority, setTaskPriority] = useState('');
  const [taskPriorityArray, setTaskPriorityArray] = useState([
    'Low',
    'Medium',
    'High',
    'ASAP',
  ]);

  const [notes, setNotes] = useState('');
  const [showDropdown, setShowDropdown] = useState(false);

  const handleCreateTask = () => {
    if (title === '') {
      setTitleMessage('Please enter Title');
      setTaskTypeMessage('');
      setPriorityMessage('');
      scrollViewRef.current?.scrollTo({x: 0, y: 0, animated: true});
    } else if (taskType.length === 0) {
      setTitleMessage('');
      setTaskTypeMessage('Please select Task Type');
      console.log('2');
      setPriorityMessage('');
      inputRef2.current.measure((y, _, height) => {
        scrollViewRef.current?.scrollTo({x: 0, y, animated: true});
      });
    } else if (taskPriority.length === 0) {
      setTitleMessage('');
      setTaskTypeMessage('');
      setPriorityMessage('Please select Priority');
      console.log('5');
    } else {
      setTitleMessage('');
      setPriorityMessage('');
      setTaskTypeMessage('');
      dispatch(setTitleInput(title));
      dispatch(setTaskTypeInput(taskType));
      dispatch(setTaskDescriptionInput(description));
      dispatch(setTaskPriorityInput(taskPriority));
      dispatch(setTaskNotesInput(notes));
      const lowercasedCategory = category.toLowerCase();
      if (
        !createTask.categoryArray.some(
          category => category.toLowerCase() === lowercasedCategory,
        )
      ) {
        dispatch(addCategory(category));
      }
      setShowDropdown(false);
      setStep(step + 1);
    }
  };

  const handleTitle = (value: string) => {
    const formattedText = value.slice(0, 24);
    const oneSpaceText = formattedText.replace(/\s+/g, ' ');
    setTitle(oneSpaceText);
  };

  const handleCategory = (value: string) => {
    // STOP USER TYPE AFTER 24 CHAR
    const formattedText = value.slice(0, 24);
    // REMOVE SPACES MORE THAN ONE
    const oneSpaceText = formattedText.replace(/\s+/g, ' ');

    const matchingCategories = createTask.categoryArray?.filter(category =>
      category.toLowerCase().includes(oneSpaceText.toLowerCase()),
    );

    setShowDropdown(oneSpaceText !== '' && matchingCategories.length > 0);
    setCategory(oneSpaceText);
  };

  const handleDescription = (value: string) => {
    const formattedText = value.slice(0, 256);
    const oneSpaceText = formattedText.replace(/\s+/g, ' ');
    setDescription(oneSpaceText);
  };

  const handleNotes = (value: string) => {
    const formattedText = value.slice(0, 256);
    const oneSpaceText = formattedText.replace(/\s+/g, ' ');
    setNotes(oneSpaceText);
  };

  // RESCTRICT USER TO ENTER BLANK SPACE IF VALUE IS ZERO
  useEffect(() => {
    if (title == ' ') {
      setTitle('');
    }
    if (category == ' ') {
      setCategory('');
    }
    if (description == ' ') {
      setDescription('');
    }
    if (notes == ' ') {
      setNotes('');
    }
  }, [title, category, description]);
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
      paddingBottom: 10,
      paddingHorizontal: 23,
      zIndex: -20,
      paddingTop: 10,
    },
    back_arrow: {
      paddingLeft: 0,
      paddingRight: 50,
      paddingBottom: 10,
      paddingTop: 10,
      width: '15%',
    },
    email_text: {
      marginBottom: 10,
      fontSize: RFPercentage(1.8),
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    input_style: {
      borderRadius: 10,
      borderColor: theme.dark ? COLORS.LIGHT_BLUE : COLORS.LIGHT_GREY,
      borderWidth: 1,
      paddingLeft: 20,
      fontSize: RFPercentage(1.7),
      paddingVertical: responsiveHeight(1.3),
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    input_style_text_area: {
      borderRadius: 10,
      borderColor: theme.dark ? COLORS.LIGHT_BLUE : COLORS.LIGHT_GREY,
      borderWidth: 1,
      paddingLeft: 20,
      fontSize: RFPercentage(2),
      paddingVertical: 9,
      fontFamily: FONTFAMILY.REGULAR,
      height: responsiveScreenHeight(20),
      textAlignVertical: 'top',
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    input_gap: {
      marginVertical: '4%',
    },
    icon_style: {
      position: 'absolute',
      right: 20,
      top: 14,
    },
    dropdown_con: {
      padding: responsiveHeight(1.3),
      backgroundColor: 'red',
      position: 'relative',
      // borderRadius: 3,
      width: '99%',
      alignSelf: 'center',
      zIndex: 1,

      ...Platform.select({
        ios: {
          shadowColor: '#000',
          shadowOffset: {width: 0, height: 2},
          shadowOpacity: 0.3,
          shadowRadius: 6,
        },
        android: {
          elevation: 3,
          backgroundColor: theme.dark ? COLORS.LIGHT_BLACK : COLORS.WHITE,
          borderRadius: 12,
        },
      }),
    },
    dropdown_text: {
      marginBottom: 10,
      fontSize: RFPercentage(1.8),
      fontFamily: FONTFAMILY.BOLD,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      paddingVertical: 3,
      width: '20%',
    },
    progress_outer: {
      marginVertical: '3%',
      height: responsiveHeight(1),
      borderRadius: 10,
      backgroundColor: theme.dark ? COLORS.LIGHT_BLACK : COLORS.LIGHT_GREY,
    },
    progress_inner: {
      position: 'absolute',
      backgroundColor: COLORS.LIGHT_BLUE,
      width: '50%',
      height: responsiveHeight(1),
      borderRadius: 10,
    },
    text: {
      textAlign: 'center',
      fontSize: RFPercentage(2.2),
      bottom: 20,
      fontFamily: FONTFAMILY.BOLD,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      marginTop: -13,
    },
    caret_img_style: {
      aspectRatio: 1,
      resizeMode: 'contain',
      height: responsiveHeight(3),
    },
    valid_msg: {
      fontFamily: FONTFAMILY.MEDIUM,
      color: COLORS.RED,
      marginLeft: '1%',
      fontSize: RFPercentage(1.8),
    },
    back_img: {
      aspectRatio: 1,
      resizeMode: 'cover',
      width: responsiveHeight(2),
      height: responsiveHeight(3.2),
    },
  });
  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={{
          position: 'relative',
          top: 0,
          marginTop: responsiveHeight(1.6),
          width: '15%',
          zIndex: 999,
        }}
        onPress={() => {
          // setTitle('');
          // setTaskTypeArray([]);
          // setTaskType('');
          // setDescription('');
          // setTaskPriorityArray([]);
          // setNotes('');
          navigation.goBack();
        }}>
        <Image
          source={theme.dark ? arrowLeftDark : arrowLeft}
          style={styles.back_img}
        />
      </TouchableOpacity>
      <Text style={styles.text}>Create Task</Text>
      <View style={styles.progress_outer}>
        <View style={styles.progress_inner}></View>
      </View>
      <TouchableOpacity
        style={{flex: 1}}
        activeOpacity={1}
        onPress={() => {
          if (isPriorityOpen || isTaskTypeOpen) {
            setIsPriorityOpen(false);
            setIsTaskTypeOpen(false);
          }
        }}>
        <ScrollView
          ref={scrollViewRef}
          nestedScrollEnabled={true}
          showsVerticalScrollIndicator={false}>
          <View style={styles.input_gap} ref={inputRef1}>
            <Text style={styles.email_text}>Title*</Text>

            <TextInput
              placeholderTextColor={COLORS.DARK_GREY}
              style={styles.input_style}
              value={title}
              onChangeText={value => {
                handleTitle(value);
              }}
            />
          </View>
          <Text style={styles.valid_msg}>{titleMessage}</Text>
          <View style={styles.input_gap}>
            <Text style={styles.email_text}>Category</Text>

            <TextInput
              placeholderTextColor={COLORS.DARK_GREY}
              style={styles.input_style}
              value={category}
              onChangeText={value => {
                handleCategory(value);
              }}
            />
            {showDropdown && (
              <View style={styles.dropdown_con}>
                {createTask.categoryArray
                  ?.filter(category =>
                    category.toLowerCase().includes(category.toLowerCase()),
                  )
                  .map(categoryItem => (
                    <Text
                      style={styles.dropdown_text}
                      key={categoryItem}
                      onPress={() => {
                        setCategory(categoryItem);
                        setShowDropdown(false);
                      }}>
                      {categoryItem}
                    </Text>
                  ))}
              </View>
            )}
          </View>
          <View style={styles.input_gap} ref={inputRef2}>
            <Text style={styles.email_text}>Task Type*</Text>
            <TouchableOpacity
              activeOpacity={0.6}
              onPress={value => {
                setIsTaskTypeOpen(!isTaskTypeOpen);
                setIsPriorityOpen(false);
                setTaskType(value);
              }}>
              <TextInput
                placeholderTextColor={COLORS.DARK_GREY}
                style={styles.input_style}
                value={taskType}
                editable={false}
              />

              <View style={styles.icon_style}>
                <Image
                  source={
                    isTaskTypeOpen && theme.dark
                      ? caretUp
                      : !isTaskTypeOpen && !theme.dark
                      ? caretDown
                      : isTaskTypeOpen && !theme.dark
                      ? caretUp
                      : theme.dark && !isTaskTypeOpen
                      ? caretDownDark
                      : ''
                  }
                  style={styles.caret_img_style}
                />
              </View>
            </TouchableOpacity>
            {isTaskTypeOpen && (
              <FlatList
                nestedScrollEnabled={true}
                style={styles.dropdown_con}
                data={taskTypeArray}
                keyExtractor={() => new Date().toString()}
                renderItem={({item}: any) => {
                  return (
                    <Text
                      style={styles.dropdown_text}
                      onPress={() => {
                        setTaskType(item);
                        setIsTaskTypeOpen(!isTaskTypeOpen);
                      }}>
                      {item}
                    </Text>
                  );
                }}
              />
            )}
          </View>
          <Text style={styles.valid_msg}>{taskTypeMessage}</Text>
          <View style={styles.input_gap}>
            <Text style={styles.email_text}>Task Description</Text>

            <TextInput
              placeholderTextColor={COLORS.DARK_GREY}
              style={styles.input_style_text_area}
              multiline={true}
              value={description}
              onChangeText={value => {
                handleDescription(value);
              }}
            />
          </View>

          <View style={styles.input_gap}>
            <Text style={styles.email_text}>Priority*</Text>
            <TouchableOpacity
              activeOpacity={0.6}
              onPress={() => {
                setIsPriorityOpen(!isPriorityOpen);
                setIsTaskTypeOpen(false);
              }}>
              <TextInput
                placeholderTextColor={COLORS.DARK_GREY}
                style={styles.input_style}
                value={taskPriority}
                editable={false}
              />

              <View style={styles.icon_style}>
                <Image
                  source={
                    isPriorityOpen && theme.dark
                      ? caretUp
                      : !isPriorityOpen && !theme.dark
                      ? caretDown
                      : isPriorityOpen && !theme.dark
                      ? caretUp
                      : theme.dark && !isPriorityOpen
                      ? caretDownDark
                      : ''
                  }
                  style={styles.caret_img_style}
                />
              </View>
            </TouchableOpacity>
            {isPriorityOpen && (
              <FlatList
                nestedScrollEnabled={true}
                style={styles.dropdown_con}
                data={taskPriorityArray}
                keyExtractor={() => new Date().toString()}
                renderItem={({item}: any) => {
                  return (
                    <Text
                      style={styles.dropdown_text}
                      onPress={() => {
                        setTaskPriority(item);
                        setIsPriorityOpen(!isPriorityOpen);
                      }}>
                      {item}
                    </Text>
                  );
                }}
              />
            )}
          </View>
          <Text style={styles.valid_msg}>{priorityMessage}</Text>

          <View style={styles.input_gap}>
            <Text style={styles.email_text}>Notes</Text>

            <TextInput
              placeholderTextColor={COLORS.DARK_GREY}
              style={styles.input_style_text_area}
              multiline={true}
              value={notes}
              onChangeText={value => {
                handleNotes(value);
              }}
            />
          </View>

          <Button
            _onPress={() => {
              handleCreateTask();
            }}
            _text={'Next'}
            _bgColor={COLORS.LIGHT_BLUE}
            _fontSize={FONTSIZE.FONT_SIZE_16}
            _color={COLORS.WHITE}
            _bColor={'transparent'}
          />
        </ScrollView>
      </TouchableOpacity>
    </View>
  );
};

export default AddTitleCreateTask;
