import {
  Image,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useState} from 'react';
import {COLORS, FONTFAMILY, FONTSIZE} from '../../theme/Theme';
import {
  arrowLeft,
  arrowLeftDark,
  calendar,
  calendarDark,
  close,
  closeDark,
  plus,
  selectedIcon,
  unSelectedIcon,
  unSelectedIconDark,
} from '../../assets/images/Index';
import {RFPercentage} from 'react-native-responsive-fontsize';
import DateTimePicker from '@react-native-community/datetimepicker';
import {
  responsiveHeight,
  responsiveWidth,
} from 'react-native-responsive-dimensions';
import Button from '../../components/Button';
import {AddStartTimePopup} from '../../components/Index';
import {useDispatch, useSelector} from 'react-redux';
import {
  setReminder,
  selectCreateTask,
  setStartDate,
} from '../../redux/slices/create_task_slices/CreateTaskSlices';
import {selectTheme} from '../../redux/slices/ThemeSlice';

const StartDateTime = ({
  step,
  setStep,
}: {
  step: number;
  setStep: React.Dispatch<React.SetStateAction<number>>;
}) => {
  const [isStartDateOpen, setIsStartDateOpen] = useState(false);
  const dispatch = useDispatch();
  const selStartDate = useSelector(selectCreateTask);
  const [reminderData, setReminderData] = useState([
    '5 mins prior start time',
    '10 mins prior start time',
    '15 mins prior start time',
  ]);

  const theme = useSelector(selectTheme);
  //   "ADD START TIME POP-UP"
  const [isAddStartTimeOpen, setIsAddStartTimeOpen] = useState(false);

  console.log('selStartDate:', selStartDate.startDate);

  // const [day, month, date, year] = selStartDate.startDat.split(' ');

  // WHEN USER SELECT START DATE
  const onChangeStartDate = (event: any, selectedDate: any) => {
    dispatch(setStartDate(selectedDate));

    console.log('selectedDate>>>>:', selectedDate);
    setIsStartDateOpen(false);
  };

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
      paddingBottom: 10,
      paddingHorizontal: 23,
      zIndex: -20,
      paddingTop: responsiveHeight(1.4),
    },
    back_arrow: {
      paddingLeft: 0,
      paddingRight: 50,
      paddingBottom: 10,
      paddingTop: 10,
      width: '15%',
    },
    progress_outer: {
      marginTop: '3%',
      marginBottom: '9%',
      height: responsiveHeight(1),
      borderRadius: 10,
      backgroundColor: theme.dark ? COLORS.LIGHT_BLACK : COLORS.LIGHT_GREY,
    },
    progress_inner: {
      position: 'absolute',
      backgroundColor: COLORS.LIGHT_BLUE,
      width: '98%',
      height: responsiveHeight(1),
      borderRadius: 10,
    },
    text: {
      textAlign: 'center',
      fontSize: RFPercentage(2.2),
      bottom: 20,
      fontFamily: FONTFAMILY.BOLD,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      marginTop: -13,
    },
    email_text: {
      marginBottom: 10,
      fontSize: RFPercentage(1.8),
      fontFamily: FONTFAMILY.BOLD,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    input_style: {
      borderRadius: 10,
      borderColor: COLORS.LIGHT_GREY,
      borderWidth: 1,
      paddingLeft: 20,
      fontSize: RFPercentage(1.7),
      paddingVertical: 9,
      fontFamily: FONTFAMILY.BOLD,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      height: responsiveHeight(6),
    },
    icon_style: {
      position: 'absolute',
      right: 20,
      top: responsiveHeight(2.1),
    },
    plus_icon: {
      height: responsiveHeight(3),
      width: responsiveWidth(6),
    },
    input_gap: {
      marginVertical: '4%',
    },
    flex: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      paddingRight: responsiveHeight(2),
    },
    time_box: {
      borderRadius: responsiveHeight(1),
      borderWidth: 1,
      borderColor: COLORS.LIGHT_GREY,
      paddingHorizontal: responsiveHeight(1.3),
      paddingVertical: responsiveWidth(2.8),
      width: responsiveWidth(42.5),
    },
    time_text: {
      fontFamily: FONTFAMILY.MEDIUM,
      fontSize: RFPercentage(1.6),
      color: theme.dark ? COLORS.MEDIUM_GREY : COLORS.LIGHT_BLACK,
    },
    close_icon: {
      position: 'absolute',
      right: -11,
      top: -11,
      height: responsiveHeight(3.2),
      width: responsiveWidth(6.2),
    },
    red_text: {
      color: COLORS.RED,
      fontFamily: FONTFAMILY.MEDIUM,
      marginTop: '1%',
      fontSize: RFPercentage(1.7),
    },
    set_reminder_con: {
      marginTop: '6%',
      height: responsiveHeight(33),
    },
    reminder_flex: {
      flexDirection: 'row',
      alignItems: 'center',
      marginTop: '3%',
    },
    reminder_text: {
      marginLeft: '2%',
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
      fontSize: RFPercentage(1.8),
    },
    selected_icon: {
      height: responsiveHeight(3.3),
      aspectRatio: 1,
      width: responsiveWidth(6.1),
    },

    title_close_con: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
    },
    input_img_style: {
      aspectRatio: 1,
      resizeMode: 'contain',
      height: responsiveHeight(2.4),
      width: responsiveWidth(3),
      bottom: '12%',
    },
    back_img: {
      aspectRatio: 1,
      resizeMode: 'cover',
      width: responsiveHeight(2),
      height: responsiveHeight(3.2),
    },
  });
  return (
    <>
      <View style={styles.container}>
        <TouchableOpacity
          style={{
            position: 'relative',
            top: 0,
            marginTop: responsiveHeight(1.6),
            width: '15%',
            zIndex: 999,
          }}
          onPress={() => {
            setStep(step - 1);
          }}>
          <Image
            source={theme.dark ? arrowLeftDark : arrowLeft}
            style={styles.back_img}
          />
        </TouchableOpacity>
        <Text style={styles.text}>Create Task</Text>
        <View style={styles.progress_outer}>
          <View style={styles.progress_inner}></View>
        </View>

        <Text style={styles.email_text}>Start Date</Text>
        <TouchableOpacity
          activeOpacity={0.6}
          onPress={() => {
            setIsStartDateOpen(!isStartDateOpen);
          }}>
          <TextInput
            placeholderTextColor={COLORS.DARK_GREY}
            style={styles.input_style}
            // value={'sdkhkjlk'}
            editable={false}
          />

          <View style={styles.icon_style}>
            <Image
              source={theme.dark ? calendarDark : calendar}
              style={styles.input_img_style}
            />
          </View>
        </TouchableOpacity>

        <View style={styles.input_gap}>
          <View style={styles.flex}>
            <Text style={styles.email_text}>Start Time</Text>
            <TouchableOpacity
              activeOpacity={0.7}
              onPress={() => {
                setIsAddStartTimeOpen(!isAddStartTimeOpen);
              }}>
              <Image source={plus} style={styles.plus_icon} />
            </TouchableOpacity>
          </View>
          <Text style={styles.red_text}>
            **You can select upto 3 start times.
          </Text>
          <View>
            <View
              style={{
                flexDirection: 'row',
                flexWrap: 'wrap',
                gap: responsiveHeight(1.5),
                marginTop: '5%',
              }}>
              <View style={styles.time_box}>
                <Image
                  source={theme.dark ? closeDark : close}
                  style={styles.close_icon}
                />
                <Text style={styles.email_text}>Meeting with Marcus</Text>
                <Text style={styles.time_text}>12:00 PM - 1:00 PM</Text>
              </View>
              <View style={styles.time_box}>
                <Image
                  source={theme.dark ? closeDark : close}
                  style={styles.close_icon}
                />
                <Text style={styles.email_text}>Meeting with Marcus</Text>
                <Text style={styles.time_text}>2:00 PM - 3:00 PM</Text>
              </View>
              <View style={styles.time_box}>
                <Image
                  source={theme.dark ? closeDark : close}
                  style={styles.close_icon}
                />
                <Text style={styles.email_text}>Meeting with Marcus</Text>
                <Text style={styles.time_text}>2:00 PM - 3:00 PM</Text>
              </View>
            </View>
          </View>

          <View style={styles.set_reminder_con}>
            <Text style={styles.email_text}>Set Reminder</Text>
            <View>
              {reminderData.map(item => {
                return (
                  <View>
                    <TouchableOpacity
                      style={styles.reminder_flex}
                      activeOpacity={0.9}
                      onPress={() => {
                        dispatch(setReminder(item));
                      }}>
                      <Image
                        source={
                          selStartDate.reminder == item && theme.dark
                            ? selectedIcon
                            : selStartDate.reminder !== item && theme.dark
                            ? unSelectedIconDark
                            : selStartDate.reminder == item && !theme.dark
                            ? selectedIcon
                            : unSelectedIcon
                        }
                        style={styles.selected_icon}
                      />

                      <Text key={item} style={styles.reminder_text}>
                        {item}
                      </Text>
                    </TouchableOpacity>
                  </View>
                );
              })}
            </View>
          </View>

          <Button
            _onPress={() => {}}
            _text={'Create Task'}
            _bgColor={COLORS.LIGHT_BLUE}
            _fontSize={FONTSIZE.FONT_SIZE_16}
            _color={COLORS.WHITE}
            _bColor={'transparent'}
          />
        </View>
      </View>

      {/* DATE PICKER */}
      {isStartDateOpen && (
        <DateTimePicker
          mode="date"
          value={new Date(selStartDate.startDate)}
          is24Hour={false}
          onChange={onChangeStartDate}
        />
      )}

      {/* ADD START TIME POP-UP */}
      {isAddStartTimeOpen && (
        <AddStartTimePopup
          isAddStartTimeOpen={isAddStartTimeOpen}
          setIsAddStartTimeOpen={setIsAddStartTimeOpen}
        />
      )}
    </>
  );
};

export default StartDateTime;
