import {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  TextInput,
  Alert,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {COLORS, FONTFAMILY, FONTSIZE} from '../theme/Theme';
import {RFPercentage} from 'react-native-responsive-fontsize';
import {useNavigation} from '@react-navigation/native';
import {
  arrowLeft,
  arrowLeftDark,
  eyeClose,
  eyeCloseDark,
  eyeOpen,
  eyeOpenDark,
} from '../assets/images/Index';

import {
  responsiveHeight,
  responsiveWidth,
} from 'react-native-responsive-dimensions';
import Button from '../components/Button';
import {selectTheme} from '../redux/slices/ThemeSlice';
import {selectCreateAccount} from '../redux/slices/create_account_slice/CreateAccountSlices';
import {useSelector} from 'react-redux';

const Login = () => {
  const [isFirstEyeOpen, setIsFirstEyeOpen] = useState(true);
  const [loginEmailInput, setLoginEmailInput] = useState('');
  const [loginPassInput, setLoginPassInput] = useState('');
  const [emailMsg, setEmailMsg] = useState('');
  const [passMsg, setPassMsg] = useState('');
  const [isEmailValid, setIsEmailValid] = useState(false);
  const [isPassValid, setIsPassValid] = useState(false);
  const navigation = useNavigation();
  const theme = useSelector(selectTheme);
  const account = useSelector(selectCreateAccount);
  console.log('account:', account);

  // useEffect(() => {}, [loginEmailInput, isPassValid, loginPassInput]);

  const validateProfile = () => {
    const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;

    if (loginEmailInput === '') {
      setEmailMsg('Please enter email');
      setIsEmailValid(false);
    } else if (!emailRegex.test(loginEmailInput)) {
      setEmailMsg('Please enter valid email');
      setIsEmailValid(false);
      setPassMsg('');
      setIsPassValid(true);
    } else if (loginPassInput === '') {
      setPassMsg('Please enter password');
      setIsPassValid(false);
      setEmailMsg('');
      setIsEmailValid(true);
    } else if (loginPassInput !== account.pass) {
      setPassMsg('Please enter correct password');
      setIsPassValid(false);
      setEmailMsg('');
      setIsEmailValid(true);
    } else {
      Alert.alert('Success');
      setEmailMsg('');
      setPassMsg('');
    }
  };

  const handleEmail = (value: string) => {
    let formattedText = value.replace(/\s+/, '');
    setLoginEmailInput(formattedText);
  };
  const handlePass = (value: string) => {
    // let formattedText = value.replace(/\s+/, '');
    setLoginPassInput(value);
  };

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.dark ? COLORS.DARK : COLORS.WHITE,
      padding: 23,
    },
    heading: {
      fontSize: RFPercentage(2.8),
      fontFamily: FONTFAMILY.BLACK,
      marginTop: responsiveHeight(2.8),
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    sub_heading: {
      fontSize: RFPercentage(1.5),
      marginTop: 10,
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.MEDIUM_GREY : COLORS.LIGHT_BLACK,
    },
    input_container: {
      marginTop: '3%',
    },
    input_style: {
      borderRadius: 10,
      borderColor: COLORS.LIGHT_BLUE,
      borderWidth: 1,
      paddingLeft: responsiveHeight(2),
      fontSize: RFPercentage(1.8),
      height: responsiveHeight(5.8),
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    email_text: {
      marginBottom: 10,
      fontSize: RFPercentage(1.8),
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    parent_input_container: {
      height: responsiveHeight(66.5),
    },
    input_icon_con: {},
    icon_style: {
      position: 'absolute',
      right: 20,
      top: 14,
    },
    link_text: {
      color: COLORS.LIGHT_BLUE,
      fontFamily: FONTFAMILY.BOLD,
      textDecorationLine: 'underline',
      textAlign: 'right',
      marginTop: '2%',
      fontSize: RFPercentage(1.4),
    },
    link_text_another: {
      color: COLORS.LIGHT_BLUE,
      fontFamily: FONTFAMILY.BOLD,
      textDecorationLine: 'underline',
      textAlign: 'right',
      fontSize: RFPercentage(1.5),
    },
    bottom_text: {
      textAlign: 'center',
      marginTop: 14,
      fontSize: RFPercentage(1.5),
      fontFamily: FONTFAMILY.MEDIUM,
      color: theme.dark ? COLORS.WHITE : COLORS.BLACK,
    },
    input_img_style: {
      aspectRatio: 1,
      resizeMode: 'contain',
      height: responsiveHeight(2.7),
      width: responsiveWidth(2.7),
    },
    valid_msg: {
      fontFamily: FONTFAMILY.MEDIUM,
      color: COLORS.RED,
      // marginTop: '1%',
      top: '0.8%',
      fontSize: RFPercentage(1.8),
    },
    back_img: {
      aspectRatio: 1,
      resizeMode: 'cover',
      width: responsiveHeight(2),
      height: responsiveHeight(3.2),
    },
  });

  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={{
          paddingLeft: 0,
          paddingRight: 50,
          paddingBottom: 10,
          width: '15%',
        }}
        onPress={() => {
          navigation.navigate('WELCOME');
        }}>
        <Image
          source={theme.dark ? arrowLeftDark : arrowLeft}
          style={styles.back_img}
        />
      </TouchableOpacity>

      <View style={{height: responsiveHeight(13)}}>
        <Text style={styles.heading}>Login</Text>
        <Text style={styles.sub_heading}>
          Login to your Dillydally Calendar account,
        </Text>
      </View>

      <View style={styles.parent_input_container}>
        <View style={styles.input_container}>
          <Text style={styles.email_text}>Email Address</Text>
          <View style={styles.input_icon_con}>
            <TextInput
              placeholderTextColor={COLORS.DARK_GREY}
              style={styles.input_style}
              placeholder="Enter Email"
              value={loginEmailInput}
              onChangeText={value => {
                // setLoginEmailInput(value);
                handleEmail(value);
              }}
            />
          </View>
        </View>
        <Text style={styles.valid_msg}>{emailMsg}</Text>
        <View style={styles.input_container}>
          <Text style={styles.email_text}>Password</Text>
          <View style={styles.input_icon_con}>
            <TextInput
              placeholderTextColor={COLORS.DARK_GREY}
              style={styles.input_style}
              secureTextEntry={isFirstEyeOpen ? true : false}
              placeholder="Enter Password"
              value={loginPassInput}
              onChangeText={value => {
                handlePass(value);
              }}
            />
            <TouchableOpacity
              activeOpacity={0.7}
              style={styles.icon_style}
              onPress={() => {
                setIsFirstEyeOpen(!isFirstEyeOpen);
              }}>
              <Image
                source={
                  isFirstEyeOpen && theme.dark
                    ? eyeOpenDark
                    : !isFirstEyeOpen && !theme.dark
                    ? eyeClose
                    : isFirstEyeOpen && !theme.dark
                    ? eyeOpen
                    : theme.dark && !isFirstEyeOpen
                    ? eyeCloseDark
                    : ''
                }
                style={styles.input_img_style}
              />
            </TouchableOpacity>
          </View>
        </View>
        <Text style={styles.valid_msg}>{passMsg}</Text>
        <Text
          style={styles.link_text_another}
          onPress={() => {
            navigation.navigate('FORGOTPASSWORD');
          }}>
          Forgot Password?
        </Text>
      </View>
      <Button
        _onPress={() => {
          validateProfile();
        }}
        _text={'Login'}
        _bgColor={COLORS.LIGHT_BLUE}
        _fontSize={FONTSIZE.FONT_SIZE_16}
        _color={COLORS.WHITE}
        _bColor={'transparent'}
      />
      <Text
        style={styles.bottom_text}
        onPress={() => {
          navigation.navigate('CREATEACCOUNT');
        }}>
        Don’t have an account?{' '}
        <Text style={styles.link_text}>Create an Account</Text>
      </Text>
    </View>
  );
};

export default Login;
