import {welcomeBg, welcomeBg2, welcomeBg3} from '../assets/images/Index';
const imgSliderData = [
  {
    id: 1,
    img: welcomeBg,
    title: 'Manage all your tasks with Dillydally Calendar',
    description:
      'The Dillydally Calendar assists in keeping your Google, Microsoft, and Apple Calendars synced in one place.',
  },
  {
    id: 2,
    img: welcomeBg2,
    title: 'Track all your daily tasks with Dillydally Calendar',
    description:
      'Effortlessly track your daily tasks with fewer clicks using the Dillydally Calendar.',
  },
  {
    id: 3,
    img: welcomeBg3,
    title: 'Time and Work Management never been so easy',
    description:
      'Efficiently manage your business or personal tasks type using the Dillydally Calendar.',
  },
];

export {imgSliderData};
